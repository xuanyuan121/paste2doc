# -*- coding: utf-8 -*-
"""把内容直贴的本地组件注册成 Chrome / Edge 的 Native Messaging 宿主。

全部写在 HKCU 下，不需要管理员权限。装完刷新一下扩展页即可。

为什么要扫浏览器：开发者模式装的扩展靠 manifest 里的 key 固定 ID，但**商店版
的 ID 由商店分配**，和开发者版不一样。宿主清单里的 allowed_origins 只要对不上，
扩展就连不上本地组件 —— 表现是「WPS 粘出来是纯文本」，而 Word 那条路正常，
排查起来很费劲。所以这里在安装时自己扫一遍浏览器，把实际装着的 ID 全放行。

    python install_host.py            # 安装 / 重新安装
    python install_host.py --allow <扩展ID>   # 手动补一个（排障用）
"""
import json
import os
import sys
import winreg

HOST_NAME = 'com.paste2doc.host'
EXT_ID = 'cpjmadcbfhaghodkkihjnbhjohgdaggm'
BROWSERS = [
    ('Chrome', r'Software\Google\Chrome\NativeMessagingHosts'),
    ('Edge', r'Software\Microsoft\Edge\NativeMessagingHosts'),
    ('Chromium', r'Software\Chromium\NativeMessagingHosts'),
]
# 商店版 / 自编译版的 ID 都可能不同，这几个 profile 根目录下扫一遍
PROFILE_ROOTS = [
    os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Microsoft\Edge\User Data'),
    os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Google\Chrome\User Data'),
    os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Chromium\User Data'),
]
MARK = '内容直贴'          # 在我们的 _locales 里找这个标记，认得出就是本扩展

HERE = os.path.dirname(os.path.abspath(__file__))
ENTRY = os.path.join(HERE, 'paste2doc_host.py')


def looks_like_us(path):
    """这个目录是不是「内容直贴」的一个版本目录（商店版也会落成这个样子）。"""
    if not path or not os.path.isdir(path):
        return False
    for loc in ('zh_CN', 'en'):
        p = os.path.join(path, '_locales', loc, 'messages.json')
        if not os.path.isfile(p):
            continue
        try:
            with open(p, encoding='utf-8') as f:
                txt = f.read()
        except OSError:
            continue
        if MARK in txt or 'Paste2Doc' in txt or 'paste2doc' in txt.lower():
            return True
    return False


def read_json(path):
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def ids_from_profiles():
    """扫各浏览器 profile，把「装载着的本扩展」的 ID 找出来。"""
    found = []
    for root in PROFILE_ROOTS:
        if not os.path.isdir(root):
            continue
        try:
            names = os.listdir(root)
        except OSError:
            continue
        for name in names:
            prof = os.path.join(root, name)
            if not os.path.isdir(prof):
                continue
            if name != 'Default' and not name.startswith('Profile'):
                continue

            # 1) 已装扩展登记在 Preferences / Secure Preferences 里
            for fname in ('Preferences', 'Secure Preferences'):
                data = read_json(os.path.join(prof, fname))
                if not isinstance(data, dict):
                    continue
                settings = (data.get('extensions') or {}).get('settings') or {}
                if not isinstance(settings, dict):
                    continue
                for ext_id, info in settings.items():
                    if not isinstance(info, dict):
                        continue
                    path = info.get('path') or ''
                    if 'paste2doc' in path.lower() or looks_like_us(path):
                        if ext_id not in found:
                            found.append(ext_id)

            # 2) 商店版的实体在 Extensions\<id>\<version>，直接按目录认
            ext_root = os.path.join(prof, 'Extensions')
            if not os.path.isdir(ext_root):
                continue
            try:
                ids = os.listdir(ext_root)
            except OSError:
                continue
            for ext_id in ids:
                base = os.path.join(ext_root, ext_id)
                if not os.path.isdir(base):
                    continue
                try:
                    versions = os.listdir(base)
                except OSError:
                    continue
                for ver in versions:
                    if looks_like_us(os.path.join(base, ver)):
                        if ext_id not in found:
                            found.append(ext_id)
                        break
    return found


def extra_ids(manual=()):
    """开发者版 ID + 扫出来的商店版 ID + allowed_ids.txt + 命令行补的。"""
    ids = [EXT_ID]
    path = os.path.join(HERE, 'allowed_ids.txt')
    if os.path.exists(path):
        with open(path, encoding='utf-8') as f:
            lines = f.readlines()
    else:
        lines = []
    lines = list(lines) + list(manual)
    for line in lines:
        s = str(line).split('#')[0].strip().replace('chrome-extension://', '').strip('/ ')
        if len(s) == 32 and all('a' <= c <= 'p' for c in s) and s not in ids:
            ids.append(s)
    return ids


def write_bat(python, script, bat):
    """浏览器拉起宿主时没有工作目录，也没有 PATH 保证，路径全部写死。

    另外要挡住 __pycache__：宿主脚本就在扩展目录里，一旦生成这个目录，
    Chrome 下次启动会以「名字以下划线开头」为由拒绝加载整个扩展。
    """
    content = ('@echo off\r\n'
               'rem keep __pycache__ out of the extension folder\r\n'
               'set PYTHONDONTWRITEBYTECODE=1\r\n'
               '"%s" "%s" --host %%*\r\n' % (python, script))
    with open(bat, 'w', encoding='gbk' if os.name == 'nt' else 'utf-8') as f:
        f.write(content)


def main():
    if not os.path.exists(ENTRY):
        print('找不到 paste2doc_host.py，安装中止：', ENTRY)
        return 1

    manual = []
    argv = sys.argv[1:]
    for i, a in enumerate(argv):
        if a == '--allow' and i + 1 < len(argv):
            manual.append(argv[i + 1])
        elif a.startswith('--allow='):
            manual.append(a.split('=', 1)[1])

    bat = os.path.join(HERE, 'host.bat')
    write_bat(sys.executable, ENTRY, bat)
    print('已写入启动脚本：', bat)

    scanned = ids_from_profiles()
    print('扫到浏览器里装着的扩展 ID：%s' % ('、'.join(scanned) if scanned else '（没找到，可能还没装扩展）'))
    ids = extra_ids(list(scanned) + manual)

    manifest = {
        'name': HOST_NAME,
        'description': 'Paste2Doc native host',
        'path': bat,
        'type': 'stdio',
        'allowed_origins': ['chrome-extension://%s/' % i for i in ids],
    }
    manifest_path = os.path.join(HERE, HOST_NAME + '.json')
    with open(manifest_path, 'w', encoding='utf-8') as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    print('已写入宿主清单：', manifest_path)
    print('放行的扩展 ID：')
    for i in ids:
        print('   ', i)

    ok = 0
    for label, key in BROWSERS:
        try:
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key + '\\' + HOST_NAME) as k:
                winreg.SetValueEx(k, '', 0, winreg.REG_SZ, manifest_path)
            print('已注册到 %s' % label)
            ok += 1
        except Exception as e:
            print('%s 注册失败：%s' % (label, e))

    if ok:
        print('\n完成。到扩展管理页点一下“重新加载”，然后回网页复制即可。')
        if not scanned:
            print('提示：如果扩展是刚装的，装完再双击一次本文件，让扫描把它的 ID 收进来。')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
