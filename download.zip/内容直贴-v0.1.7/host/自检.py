# -*- coding: utf-8 -*-
"""内容直贴 · 本地组件自检。

这一步和浏览器、和网页都无关：只检查「浏览器点一下之后，真正动手写剪贴板的那一半」
是不是通的。

    python 自检.py            只检查，不动剪贴板
    python 自检.py --sample   检查完再把一份自检样例写进剪贴板

--sample 之后到 WPS 文字 / Word 里 Ctrl+V，看到的东西全对，就说明本地组件没问题，
剩下的问题一定在网页那一侧（提取、按钮、通信）。
"""
import base64
import hashlib
import json
import os
import re
import sys
import winreg

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
HOST_NAME = 'com.paste2doc.host'
EXT_ID = 'cpjmadcbfhaghodkkihjnbhjohgdaggm'
BROWSERS = [
    ('Chrome', r'Software\Google\Chrome\NativeMessagingHosts'),
    ('Edge', r'Software\Microsoft\Edge\NativeMessagingHosts'),
    ('Chromium', r'Software\Chromium\NativeMessagingHosts'),
]
MODULES = ['p2d_docx.py', 'p2d_rtf.py', 'p2d_math.py', 'p2d_escape.py', 'paste2doc_host.py']

OK, NG, WARN = '✔', '✘', '!'
rows = []          # (标签, 值, 状态)
fatal = 0


def add(label, value, state=OK):
    rows.append((label, value, state))


def ext_id_of(key_b64):
    """Chrome 的扩展 ID：公钥 DER 的 SHA-256 前 16 字节，每个半字节映射到 a-p。"""
    h = hashlib.sha256(base64.b64decode(key_b64)).hexdigest()[:32]
    return ''.join(chr(ord('a') + int(c, 16)) for c in h)


def check_python():
    v = '%d.%d.%d' % sys.version_info[:3]
    if sys.version_info < (3, 8):
        add('Python', v + '（需要 3.8 以上）', NG)
        return
    add('Python', v, OK)


def check_files():
    missing = [m for m in MODULES if not os.path.exists(os.path.join(HERE, m))]
    if missing:
        add('组件文件', '缺少 ' + '、'.join(missing), NG)
        return
    add('组件文件', '%d 个模块齐全' % len(MODULES), OK)

    # 真 import 一次，能发现语法错误、缺库
    sys.path.insert(0, HERE)
    try:
        import paste2doc_host  # noqa: F401
        add('模块加载', 'docx / rtf / math 均可导入', OK)
    except Exception as e:
        add('模块加载', '%s: %s' % (type(e).__name__, e), NG)


def check_bat():
    bat = os.path.join(HERE, 'host.bat')
    if not os.path.exists(bat):
        add('启动脚本', 'host.bat 不存在', NG)
        return
    try:
        with open(bat, encoding='gbk', errors='replace') as f:
            content = f.read()
    except OSError as e:
        add('启动脚本', '读不出来：%s' % e, NG)
        return
    # host.bat 是两行：@echo off，然后 "python.exe" "脚本" --host %*
    quoted = re.findall(r'"([^"]+)"', content)
    py = quoted[0] if quoted else ''
    if not py:
        add('启动脚本', 'host.bat 内容异常', NG)
    elif not os.path.exists(py):
        add('启动脚本', '写的 python 已经不存在：%s' % py, NG)
    else:
        add('启动脚本', 'host.bat → python 路径有效', OK)


def check_manifest():
    path = os.path.join(HERE, HOST_NAME + '.json')
    if not os.path.exists(path):
        add('宿主清单', '还没生成（双击「安装到浏览器.bat」）', NG)
        return
    try:
        with open(path, encoding='utf-8') as f:
            mf = json.load(f)
    except Exception as e:
        add('宿主清单', 'JSON 解析失败：%s' % e, NG)
        return

    target = mf.get('path', '')
    if not target or not os.path.exists(target):
        add('宿主清单', 'path 指向的文件不存在：%s' % target, NG)
    else:
        add('宿主清单', 'path 存在', OK)

    ids = [o.replace('chrome-extension://', '').strip('/')
           for o in (mf.get('allowed_origins') or [])]
    if not ids:
        add('允许来源', 'allowed_origins 是空的', NG)
    elif EXT_ID in ids:
        add('允许来源', '%s…%s（本扩展）' % (EXT_ID[:4], EXT_ID[-4:]), OK)
    else:
        add('允许来源', '不含本扩展 ID，浏览器会拒绝连接', NG)


def check_registry():
    hit = []
    bad = []
    for label, key in BROWSERS:
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key + '\\' + HOST_NAME) as k:
                val, _ = winreg.QueryValueEx(k, '')
        except FileNotFoundError:
            continue
        except OSError:
            bad.append(label)
            continue
        (hit if os.path.exists(val) else bad).append(label)
    if hit:
        add('注册表', '、'.join(hit) + ' 已注册', OK)
        if bad:
            add('注册表', '、'.join(bad) + ' 的登记路径已失效', WARN)
    elif bad:
        add('注册表', '登记存在但指向的文件不见了', NG)
    else:
        add('注册表', 'Chrome / Edge 都没注册', NG)


def check_extension():
    mf_path = os.path.join(ROOT, 'manifest.json')
    if not os.path.exists(mf_path):
        add('扩展目录', '母目录里没有 manifest.json', WARN)
        return
    try:
        with open(mf_path, encoding='utf-8') as f:
            mf = json.load(f)
    except Exception as e:
        add('扩展目录', 'manifest.json 解析失败：%s' % e, NG)
        return
    key = mf.get('key')
    if not key:
        add('扩展目录', 'manifest 没写 key，ID 会随机', WARN)
        return
    try:
        got = ext_id_of(key)
    except Exception as e:
        add('扩展目录', 'key 解析失败：%s' % e, NG)
        return
    if got == EXT_ID and mf.get('version'):
        add('扩展目录', 'v%s，ID 与宿主一致' % mf['version'], OK)
    else:
        add('扩展目录', 'ID 是 %s，与宿主登记的 %s 不一致' % (got, EXT_ID), NG)


def print_report():
    width = max(len(r[0]) for r in rows) if rows else 8
    print()
    for label, value, state in rows:
        print('  %s %s  %s' % (state, label.ljust(width + 2), value))
    print()


def sample_model():
    M = 'http://www.w3.org/1998/Math/MathML'

    def math(inner, display=False):
        return '<math xmlns="%s"%s>%s</math>' % (
            M, ' display="block"' if display else '', inner)

    T = lambda s, **kw: dict({'t': 'text', 'v': s}, **kw)
    MI = lambda s: {'t': 'math', 'mathml': math(s)}

    blocks = [
        {'t': 'h', 'level': 1, 'inl': [T('内容直贴 · 自检样例')]},
        {'t': 'p', 'inl': [
            T('如果你在 WPS 或 Word 里看到的这一段是'),
            T('宋体五号、首行缩进两字、单倍行距', b=True),
            T('，说明正文排版正常。行内公式 '),
            MI('<mi>Δ</mi><mo>=</mo><mn>1.5</mn><msub><mi>k</mi><mi>B</mi></msub>'
               '<msub><mi>T</mi><mi>c</mi></msub>'),
            T(' 和上标 '), T('x'), T('2', sup=True),
            T('、下标 '), T('H'), T('2', sub=True), T('O 也一起检查了。'),
        ]},
        {'t': 'h', 'level': 2, 'inl': [T('一、自动编号')]},
        {'t': 'list', 'ordered': True, 'start': 1, 'items': [
            {'lvl': 0, 'inl': [T('这一行应该是自动编号「1.」，不是手打的数字')]},
            {'lvl': 0, 'inl': [T('在它末尾回车，应该接着出现「2.」')]},
            {'lvl': 1, 'inl': [T('这一行应该缩进一级，编号是「(1)」')]},
            {'lvl': 0, 'inl': [T('回到这一级，应该是「3.」')]},
        ]},
        {'t': 'list', 'ordered': False, 'items': [
            {'lvl': 0, 'inl': [T('项目符号也应该是自动的')]},
            {'lvl': 0, 'inl': [T('回车之后仍然有圆点')]},
        ]},
        {'t': 'h', 'level': 2, 'inl': [T('二、表格与代码')]},
        {'t': 'table', 'header': True, 'rows': [
            [[T('项目')], [T('温度 (°C)')], [T('说明')]],
            [[T('S1')], [T('550')], [T('8 × 10⁻⁷ Torr')]],
            [[T('S2')], [T('600')], [T('高 Se 压')]],
        ]},
        {'t': 'p', 'inl': [T('下面应该是一个代码块，等宽字体、灰底、不缩进：')]},
        {'t': 'code', 'lang': 'python', 'text':
            'def gap(T, Tc=9.0):\n'
            '    """BCS 能隙的近似温度依赖"""\n'
            '    if T >= Tc:\n'
            '        return 0.0\n'
            '    return 1.76 * Tc * (1 - (T / Tc) ** 3) ** 0.5\n\n'
            'print(gap(4.2))'},
        {'t': 'h', 'level': 2, 'inl': [T('三、原生公式')]},
        {'t': 'p', 'inl': [T('下面这个公式应该能双击进入公式编辑，不是图片、也不是 LaTeX 源码：')]},
        {'t': 'math', 'mathml': math(
            '<mi>H</mi><mo>=</mo><munderover><mo>∑</mo>'
            '<mrow><mi>k</mi><mo>,</mo><mi>σ</mi></mrow>'
            '<mrow><msub><mi>ξ</mi><mi>k</mi></msub></mrow></munderover>'
            '<msubsup><mi>c</mi><mrow><mi>k</mi><mi>σ</mi></mrow><mo>†</mo></msubsup>'
            '<msub><mi>c</mi><mrow><mi>k</mi><mi>σ</mi></mrow></msub>'
            '<mo>+</mo><mfrac><mn>1</mn><mn>2</mn></mfrac>'
            '<msqrt><mrow><msup><mi>a</mi><mn>2</mn></msup><mo>+</mo>'
            '<msup><mi>b</mi><mn>2</mn></msup></mrow></msqrt>', True)},
        {'t': 'p', 'q': True, 'inl': [T('这一句应该是引用：左边有一条竖线，左右各缩进两字。')]},
    ]
    return {'version': 1, 'opt': {'size': 21, 'line': 240, 'indent': True},
            'plain': '（纯文本占位：这条样式不对时，粘出来的是这一行字）',
            'blocks': blocks}


def main():
    args = sys.argv[1:]
    print('\n内容直贴 · 本地组件自检')
    print('─' * 46)

    check_python()
    check_files()
    check_bat()
    check_manifest()
    check_registry()
    check_extension()
    print_report()

    bad = [r for r in rows if r[2] == NG]
    if bad:
        print('  结论：还不能用。先处理上面标 ✘ 的项。')
        if any(r[0] == '宿主清单' for r in bad) or any(r[0] == '注册表' for r in bad):
            print('  最省事的路子：双击 host\\安装到浏览器.bat，然后回扩展页点「重新加载」。')
        print()
        return 1

    print('  结论：本地组件已就绪，剪贴板这一段是通的。')
    if '--sample' not in args:
        print('  想确认粘出来的样子：python 自检.py --sample')
        print()
        return 0

    print()
    print('  正在把自检样例写进剪贴板…')
    sys.path.insert(0, HERE)
    from paste2doc_host import copy_document
    n1, n2 = copy_document(sample_model())
    print('  已写入：docx %.1f KB / rtf %.1f KB' % (n1 / 1024.0, n2 / 1024.0))
    print()
    print('  现在打开 WPS 文字或 Word，新建空白文档，Ctrl+V。核对这五条：')
    print('    1. 「内容直贴 · 自检样例」是标题样式（导航窗格里能看到）')
    print('    2. 正文宋体五号、首行缩进两字、没有空行分隔')
    print('    3. 编号是自动的，「2.」后面回车会接着编二级是「(1)」')
    print('    4. 表格有表头底纹和框线，代码块是等宽灰底')
    print('    5. 大公式能双击进入公式编辑')
    print()
    print('  全对 → 本地没问题，剩下的都在网页那一侧。')
    print('  有不对 → 把这一屏输出和粘贴结果的截图一起发我，注明是 WPS 还是 Word。')
    print()
    return 0


if __name__ == '__main__':
    sys.exit(main())
