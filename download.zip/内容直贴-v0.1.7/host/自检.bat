@echo off
chcp 65001 >nul
set PYTHONDONTWRITEBYTECODE=1
cd /d "%~dp0"
echo.
echo   内容直贴 · 本地组件自检
echo   只检查，不改任何设置。
echo.
python "%~dp0自检.py" --sample
if errorlevel 1 (
  py -3 "%~dp0自检.py" --sample
)
echo.
pause
