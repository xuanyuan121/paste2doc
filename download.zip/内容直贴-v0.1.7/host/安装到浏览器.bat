@echo off
chcp 65001 >nul
set PYTHONDONTWRITEBYTECODE=1
cd /d "%~dp0"
echo.
echo   内容直贴 · 安装本地组件
echo   ------------------------------------
echo   它只做一件事：把网页内容写成 WPS / Word 能直接粘的格式。
echo   安装位置在当前用户下，不需要管理员权限。
echo.
python "%~dp0install_host.py"
if errorlevel 1 (
  rem PATH 里没有 python 的话，再试一下 Windows 自带的 py 启动器
  py -3 "%~dp0install_host.py"
)
if errorlevel 1 (
  echo.
  echo   安装失败。请先装 Python 3（安装时勾选 Add to PATH），再双击本文件。
)
echo.
pause
