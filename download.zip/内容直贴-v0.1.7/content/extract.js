/* 网页内容 -> 文档模型
 *
 * 目标：把「一条回答」里的排版语义原样取出来 —— 标题就是标题，列表就是列表，
 * 表格就是表格，公式就是公式 —— 而不是把 DOM 的视觉样式抄下来。
 *
 * 做法：先克隆一份节点（不动页面），把公式换成占位节点，剥掉复制按钮/图标这类
 * 噪音，然后按块级语义递归。页面改版只要还能找到「内容根」，提取就不会崩。
 */
(() => {
  'use strict';
  const NS = window.__p2d;
  if (!NS) return;

  /* ------------------------------------------------------------ 站点适配
   * 只写「内容根在哪」。拿不到就退到通用规则，不为了某个站点的改版去硬编码。
   */
  const SITES = [
    {
      id: 'chatgpt',
      host: /(^|\.)(chatgpt\.com|chat\.openai\.com)$/,
      answer: '[data-message-author-role="assistant"]',
      content: '.markdown, [class*="markdown"]',
      user: '[data-message-author-role="user"]'
    },
    {
      id: 'claude',
      host: /(^|\.)claude\.ai$/,
      answer: '[data-testid="chat-message"], .font-claude-message',
      content: '.font-claude-message, .prose, [data-testid="message-content"]',
      user: '[data-testid="user-message"]'
    },
    {
      id: 'deepseek',
      host: /(^|\.)deepseek\.com$/,
      /* 一轮 = 一个 .ds-message（里面挂着 .ds-think-content 思考 + .ds-markdown 正文）。
         以前 answer 直接写 .ds-markdown，于是「思考正文」本身也被当成一条回答 ——
         指上去就有蓝框、复制也是思考。必须往上认到 .ds-message 这一层。 */
      answer: '.ds-message, .ds-markdown, [class*="markdown"]',
      content: '.ds-markdown',
      user: '.fbb737a4'
    },
    {
      id: 'gemini',
      host: /(^|\.)gemini\.google\.com$/,
      answer: 'model-response, message-content, .model-response-text',
      content: '.markdown, message-content'
    },
    {
      id: 'kimi',
      host: /(^|\.)kimi\.(moonshot\.cn|com)$/,
      answer: '[class*="segment-content"], [class*="markdown"]',
      content: '[class*="markdown"]'
    },
    {
      id: 'doubao',
      host: /(^|\.)doubao\.com$/,
      answer: '[data-testid="message-content"], [class*="flow-markdown-body"]',
      content: '[class*="flow-markdown-body"], .markdown'
    },
    {
      id: 'yuanbao',
      host: /(^|\.)yuanbao\.tencent\.com$/,
      answer: '[class*="hyc-content-md"], [class*="agent-chat__bubble__content"]',
      content: '[class*="hyc-content-md"], [class*="bubble__content"]'
    },
    {
      id: 'qwen',
      host: /(^|\.)(tongyi\.aliyun\.com|chat\.qwen\.ai|qianwen\.com)$/,
      answer: '[class*="markdown"], [class*="answer"]',
      content: '[class*="markdown"]'
    },
    {
      id: 'zhipu',
      host: /(^|\.)(chatglm\.cn|zhipuai\.cn|bigmodel\.cn)$/,
      answer: '[class*="markdown"], [class*="answer"]',
      content: '[class*="markdown"]'
    },
    {
      id: 'perplexity',
      host: /(^|\.)perplexity\.ai$/,
      answer: '[class*="prose"]',
      content: '[class*="prose"]'
    },
    {
      id: 'copilot',
      host: /(^|\.)(copilot\.microsoft\.com|bing\.com)$/,
      answer: '[data-content="ai-message"], [class*="ai-message"]',
      content: '[class*="markdown"], .ac-textBlock'
    },
    {
      id: 'grok',
      host: /(^|\.)(grok\.com|x\.ai)$/,
      answer: '[class*="message-bubble"], [class*="response-content"]',
      content: '[class*="markdown"]'
    },
    {
      id: 'poe',
      host: /(^|\.)poe\.com$/,
      answer: '[class*="Message_botMessageBubble"], [class*="markdown"]',
      content: '[class*="markdown"]'
    },
    {
      id: 'mistral',
      host: /(^|\.)chat\.mistral\.ai$/,
      answer: '[class*="prose"]',
      content: '[class*="prose"]'
    }
  ];

  /* 通用兜底：几乎所有 AI 页面都用这些标记回答区 */
  const GENERIC_ANSWER = [
    '[data-message-author-role="assistant"]',
    '[data-role="assistant"]',
    '[data-testid*="assistant"]',
    '[data-message-role="assistant"]',
    '.markdown-body',
    '.markdown',
    '.prose'
  ].join(',');

  function siteOf(loc) {
    const host = loc.hostname;
    for (const s of SITES) {
      if (s.host.test(host)) return s;
    }
    return null;
  }

  /* -------------------------------------------------------------- 常量 */

  const BLOCK_TAGS = new Set([
    'p', 'div', 'section', 'article', 'main', 'aside', 'header', 'footer',
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'li', 'table', 'thead',
    'tbody', 'tfoot', 'tr', 'td', 'th', 'pre', 'blockquote', 'figure',
    'figcaption', 'dl', 'dt', 'dd', 'hr', 'form', 'fieldset', 'details',
    'summary', 'address', 'center', 'caption', 'video', 'audio', 'canvas'
  ]);

  const NOISE_TAGS = new Set([
    'button', 'svg', 'script', 'style', 'noscript', 'template', 'iframe',
    'input', 'textarea', 'select', 'option', 'nav', 'form', 'label',
    'canvas', 'video', 'audio', 'img', 'picture', 'source', 'object', 'embed',
    'math'   // 公式已经换成占位节点，剩下的 math 是噪音
  ]);

  const NOISE_SELECTOR = [
    '[data-p2d-skip]', '[aria-hidden="true"]', '.sr-only', '.katex-html',
    '[class*="copy-button"]', '[class*="copyBtn"]', '[data-testid*="copy"]',
    '[class*="toolbar"]', '[class*="action-bar"]', '[class*="feedback"]',
    '[class*="token-count"]', '[class*="message-actions"]'
  ].join(',');

  const INLINE_TAGS = new Set([
    'span', 'a', 'strong', 'b', 'em', 'i', 'u', 's', 'del', 'ins', 'mark',
    'small', 'big', 'sub', 'sup', 'code', 'kbd', 'samp', 'var', 'abbr',
    'cite', 'q', 'time', 'font', 'label', 'br', 'bdi', 'bdo', 'ruby', 'rt'
  ]);

  /* 列表项取文字时要跳过的：嵌套列表由 listOf 自己往下走 */
  const LIST_SKIP = new Set(['ul', 'ol']);

  /* -------------------------------------------------------- 公式处理 */

  const MATH_ROOTS = '.katex, mjx-container, math, [data-latex], [data-tex]';

  /* 点到公式身上时，从任意子节点往上找这个盒子 */
  const MATH_BOX = '.katex-display, mjx-container, math, .katex, [data-latex], [data-tex]';

  function mathBox(el) {
    if (!el || el.nodeType !== 1) return null;
    try { return el.closest(MATH_BOX); } catch (e) { return null; }
  }

  /** 公式的可见文字：KaTeX 的 .katex-html 才是看得见的那份 */
  function visibleMathText(el) {
    const c = el.cloneNode(true);
    c.querySelectorAll('.katex-mathml, mjx-assistive-mml, annotation, annotation-xml, .sr-only, [aria-hidden="true"]')
      .forEach((n) => n.remove());
    let t = (c.textContent || '').replace(/\s+/g, ' ').trim();
    if (!t) t = (el.textContent || '').replace(/\s+/g, ' ').trim();
    return t;
  }

  /** alt / aria-label 里像不像一段 LaTeX（给「公式画成图片」的站点用） */
  function looksLikeLatex(s) {
    const t = String(s || '').trim();
    if (!t || t.length > 500) return false;
    return /\\[a-zA-Z]+|[a-zA-Z0-9)\]}]\s*[_^]\s*[\w{(]/.test(t);
  }

  /** 公式 -> 行内节点。取不回 MathML 又取不回 LaTeX 时，退成斜体文字，绝不整块丢掉。 */
  function mathRun(m, display) {
    if (!m) return null;
    if (m.mathml) return { t: 'math', mathml: m.mathml, latex: m.latex || null, display: !!display };
    if (m.latex) return { t: 'math', mathml: null, latex: m.latex, display: !!display };
    if (m.text) return { t: 'text', v: m.text, i: 1, math: 1 };
    return null;
  }

  function isDisplayMath(el) {
    if (!el) return false;
    if (el.closest('.katex-display, mjx-container[display="true"], .math-display, .math-block')) {
      return true;
    }
    const m = el.tagName.toLowerCase() === 'math' ? el : el.querySelector('math');
    return !!m && m.getAttribute('display') === 'block';
  }

  function cleanMathML(m) {
    const copy = m.cloneNode(true);
    copy.querySelectorAll('annotation, annotation-xml').forEach((n) => n.remove());
    copy.querySelectorAll('semantics').forEach((sem) => {
      const first = sem.firstElementChild;
      if (first) sem.replaceWith(first);
    });
    copy.querySelectorAll('[class],[style],[id]').forEach((n) => {
      n.removeAttribute('class');
      n.removeAttribute('style');
      n.removeAttribute('id');
    });
    let html = copy.outerHTML;
    /* 浏览器把不换行空格序列化成 &nbsp;，XML 解析器不认这个实体 —— 一句 &nbsp;
     * 就能让整条公式变成空白。统一换成数字引用。 */
    html = html.replace(/&nbsp;/g, '&#160;').replace(/&minus;/g, '&#8722;');
    if (!/^<math[^>]*\sxmlns=/.test(html)) {
      html = html.replace('<math', '<math xmlns="http://www.w3.org/1998/Math/MathML"');
    }
    return html;
  }

  function pickLatex(el) {
    const ann = el.querySelector('annotation[encoding="application/x-tex"], annotation[encoding="TeX"]');
    if (ann && ann.textContent.trim()) return ann.textContent.trim();
    for (const a of ['data-latex', 'data-tex', 'data-math', 'data-formula']) {
      const v = el.getAttribute && el.getAttribute(a);
      if (v && v.trim()) return v.trim();
      const inner = el.querySelector('[' + a + ']');
      if (inner) {
        const w = inner.getAttribute(a);
        if (w && w.trim()) return w.trim();
      }
    }
    const scr = el.querySelector('script[type^="math/tex"]');
    if (scr && scr.textContent.trim()) return scr.textContent.trim();
    return null;
  }

  /** LaTeX -> MathML。只有页面自己没提供 MathML 时才用到，需要 KaTeX 在场。 */
  function latexToMathML(latex, display) {
    if (!window.katex || typeof window.katex.renderToString !== 'function') return null;
    try {
      const html = window.katex.renderToString(latex, {
        displayMode: !!display, output: 'mathml', throwOnError: true, strict: 'ignore'
      });
      const tpl = document.createElement('template');
      tpl.innerHTML = html;
      const m = tpl.content.querySelector('math');
      return m ? cleanMathML(m) : null;
    } catch (e) {
      return null;
    }
  }

  /* KaTeX 不再跟着内容脚本一起注入：272KB 摊到每个网页太重。
     真遇到「只剩 LaTeX」的页面，再让后台把它注进同一个隔离世界。 */
  let katexLoading = null;

  function ensureKatex() {
    if (window.katex) return Promise.resolve(true);
    if (katexLoading) return katexLoading;
    katexLoading = new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type: 'inject-katex' }, () => {
          void chrome.runtime.lastError;
          resolve(!!window.katex);
        });
      } catch (e) {
        resolve(false);
      }
    });
    return katexLoading;
  }

  /** 把克隆节点里的每个公式换成占位 span，并登记 LaTeX / MathML */
  function prepareMath(clone) {
    const map = new Map();
    const nodes = Array.from(clone.querySelectorAll(MATH_ROOTS));

    const handled = new Set();
    for (const el of nodes) {
      // 一个公式可能同时命中 .katex / math：(取最外层)
      const outer = (el.closest && el.closest('.katex, mjx-container')) || el;
      if (handled.has(outer) || handled.has(el)) continue;
      // 注意：HTML 里的 MathML 是“外来元素”，tagName 是小写的 math，不能用 'MATH' 比
      let mathEl = outer.tagName.toLowerCase() === 'math' ? outer : outer.querySelector('math');
      if (!mathEl && outer !== el && el.tagName.toLowerCase() === 'math') mathEl = el;
      const latex = pickLatex(outer) || pickLatex(el);
      handled.add(outer);
      handled.add(el);

      if (!mathEl && !latex) {
        /* 站点把 KaTeX 关成「只输出 HTML」、又不留 annotation 的情况：
         * 拿不回公式结构，但看得见的那份文字还在。宁可退成斜体文字，
         * 也不能让一段公式凭空消失（这是用户最直观的「公式丢了」）。 */
        const txt = visibleMathText(outer.tagName.toLowerCase() === 'math' ? outer : el);
        if (!txt) continue;
        const ph = document.createElement('p2d-math');
        outer.replaceWith(ph);
        map.set(ph, { mathml: null, latex: null, text: txt, display: isDisplayMath(outer) });
        continue;
      }

      map.set(outer, {
        mathml: mathEl ? cleanMathML(mathEl) : null,
        latex,
        display: isDisplayMath(outer)
      });
      /* 占位节点只靠标签名识别：不能再挂 data-p2d-skip，否则会被 stripNoise 当成噪音删掉 */
      const ph = document.createElement('p2d-math');
      outer.replaceWith(ph);
      map.set(ph, map.get(outer));
    }

    /* 有些站点把公式画成图片，只把 LaTeX 塞在 alt 里 */
    for (const img of Array.from(clone.querySelectorAll('img[alt], img[aria-label]'))) {
      const raw = (img.getAttribute('alt') || img.getAttribute('aria-label') || '').trim();
      const latexTxt = raw.replace(/^\$+|\$+$/g, '').trim();
      if (!looksLikeLatex(latexTxt)) continue;
      const ph = document.createElement('p2d-math');
      img.replaceWith(ph);
      map.set(ph, { mathml: null, latex: latexTxt, display: false });
    }
    return map;
  }

  function stripNoise(root) {
    root.querySelectorAll(NOISE_SELECTOR).forEach((n) => n.remove());
    root.querySelectorAll(Array.from(NOISE_TAGS).join(',')).forEach((n) => n.remove());
  }

  /* ---------------------------------------------------------- 思考过程
   * 推理模型的「思考」面板和正文是并列的两块，但它也算在回答容器里，
   * 不主动剔除就会一起粘进文档。
   *
   * 两条路：先按站点惯用的类名删；类名是哈希认不出来的，就按面板标题文字找
   * ——「已深度思考（用时 12 秒）」这种句子结构很稳定。
   * 删除前有一个比例保护：一次删掉的文字超过全文 70% 就不删，
   * 宁可留下思考，也不能把整条回答吃掉。
   */
  const THINK_SEL = [
    '[data-testid*="thinking"]', '[data-testid*="thought"]', '[data-testid*="reasoning"]',
    '[class*="think"]', '[class*="reasoning"]', '[class*="thought"]',
    '[class*="chain-of-thought"]'
  ].join(',');

  /* 抬头只认结构稳定的那几种。**刻意不写「思考」两个字开头就匹配** ——
     正文里的「思考题」「思考片刻后我们可以……」会被整段误杀。 */
  const THINK_HEAD = /^(已深度思考|已思考|深度思考|思考中|思考完成|思考完毕|思考过程|思考内容|思考了\s*[0-9]|已完成思考|完成思考|正在思考|深入思考|推理中|推理过程|推理完成|已推理|已分析|分析中|Thought(\s+for)?|Thinking|Reasoning|Reasoned|Analy[sz]ed|Show thinking|Hide thinking)/i;

  /**
   * 这一行文字是不是「思考面板的抬头」。
   *
   * 光看开头不够：「Thinking about it, ...」也是 Thinking 开头，那却是正文。
   * 所以还要求抬头之后只剩「时长 / 括号 / 箭头 / 省略号」这类装饰 ——
   * 「已思考（用时 16 秒）」「Thought for 12 seconds」「思考完成」都过，
   * 「Thinking about it」被挡下。
   */
  /** 纯文字版的抬头判定（克隆体、临时节点也能用） */
  function thinkHeaderOf(text) {
    // 抬头前面常常挂着一个箭头 / 图标字符：「›已思考（用时 16 秒）」
    const raw = String(text || '')
      .replace(/^[›»><＞〉》·•|｜\-–—\s…]+/, '')
      .replace(/\s+/g, ' ')
      .trim();
    if (!raw || raw.length > 60) return '';
    const m = raw.match(THINK_HEAD);
    if (!m) return '';
    const rest = raw.slice(m[0].length).replace(/[（()）[\]【】{}<>＞»›·.…:：,，、\s]/g, '');
    if (rest && !/^(用时|耗时|时间|已完成|完成|完毕|中|过程|内容|for|in)?([0-9]+(秒|s|sec|seconds?|分|min|minutes?)?)*(过程|内容|中|完成|完毕)?$/i.test(rest)) {
      return '';
    }
    return raw;
  }

  function thinkHeaderText(el) {
    if (!el || el.nodeType !== 1) return '';
    if (el.childElementCount > 6) return '';      // 抬头是一行字，不是一坨东西
    /* 里面装着段落 / 列表 / 表格的，一定是正文，别去读它的 textContent
       （这一步同时是性能保护：正文块动辄几千字，不该在指针移动时反复量） */
    try {
      if (el.querySelector('p,ul,ol,pre,table,blockquote,h1,h2,h3,h4,h5,h6')) return '';
    } catch (e) { /* 选择器不合法就算了 */ }
    return thinkHeaderOf(el.textContent);
  }

  /** 整页 / 整个对话区：里面装着输入框，或者装着两条以上消息 —— 那不是思考面板 */
  function isAppShell(el) {
    if (!el || el.nodeType !== 1) return false;
    try {
      /* 复选框不算输入框：Markdown 的任务列表就长成 <input type="checkbox">，
         把它当「这里有输入框」会让整条回答彻底消失。 */
      if (el.querySelector('textarea, select, form, [contenteditable="true"],'
        + ' [role="textbox"], input:not([type="checkbox"]):not([type="radio"])')) return true;
    } catch (e) {
      return true;
    }
    let n = 0;
    try {
      for (const m of el.querySelectorAll('[data-message-id], [data-message-author-role], .ds-message')) {
        if (++n > 1) return true;
      }
    } catch (e) { /* 选择器不合法就算了 */ }
    return false;
  }

  /** 里面有没有按钮、输入框这类「操作控件」—— 有就说明这块不只是正文 */
  function hasControls(el) {
    if (!el || el.nodeType !== 1) return false;
    try {
      return !!el.querySelector('button, textarea, input, select, [contenteditable="true"], [role="button"], [role="textbox"]');
    } catch (e) {
      return true;
    }
  }

  /**
   * 这个内容块前面是不是单独挂着一行「思考抬头」。
   *
   * 是的话它就是思考正文 —— 类名全是哈希、抬头又不在同一个壳里的站点，
   * 靠这一条也能认出来。要求前面那一块「整块就是那行抬头」（≤60 字），
   * 所以「一块面板里装着抬头 + 正文」的结构不会被误判成「后面那块是思考」。
   */
  function afterThinkHead(root, el) {
    let cur = el;
    /* 不设层数上限：思考正文外面套十几层 div 很常见，卡在第 8 层就漏了。
       每一层只看「紧挨着的前两三个兄弟」，而要求那一块整块就是一行抬头，
       所以爬到消息列表那一层也不会把别的消息认成抬头。 */
    for (let i = 0; i < 40 && cur && cur !== root; i++) {
      let sib = cur.previousElementSibling;
      for (let k = 0; sib && k < 3; k++) {
        if (thinkHeaderText(sib)) return true;
        sib = sib.previousElementSibling;
      }
      cur = cur.parentElement;
    }
    return false;
  }

  /* 点选时会反复问「这块是不是思考」，认出来的答案列表顺手缓存一下；
     元素级别的判定也缓存（同一个元素在指针移动时会被问到几十次）。 */
  let thinkMemo = new WeakMap();
  function refreshThink() {
    rootsCache = { at: 0, list: [] };
    thinkMemo = new WeakMap();
  }

  function stripThinking(root) {
    const total = Math.max(1, (root.textContent || '').length);
    const tooBig = (el) => (el.textContent || '').length > total * 0.7;
    // 注意：这里操作的是克隆体，它不在文档里，isConnected 永远是 false，
    // 只能用「还在不在 root 这棵树里」来判断是否已被连带删除。
    const alive = (el) => root.contains(el);

    // 1) 类名 / 属性（.ds-think-content 这类）
    root.querySelectorAll(THINK_SEL).forEach((n) => {
      if (!alive(n) || tooBig(n)) return;
      n.remove();
    });

    // 2) 抬头文字：往上收拢到「装这一小块的容器」再删
    const heads = [];
    root.querySelectorAll('*').forEach((el) => {
      if (el.children.length > 3) return;
      if (!thinkHeaderText(el)) return;
      heads.push(el);
    });

    for (const el of heads) {
      if (!alive(el)) continue;
      let box = el;
      // 最多上收三层，且只在「兄弟很少」的窄容器里上收 ——
      // 这样停在思考面板的壳上，不会一路吃到答案容器
      for (let i = 0; i < 3; i++) {
        const up = box.parentElement;
        if (!up || up === root) break;
        if (up.children.length > 2) break;
        box = up;
      }
      if (box === root || !alive(box)) continue;
      if (tooBig(box)) continue;
      box.remove();
    }

    // 2b) 抬头单独成行、紧跟着的那块就是思考正文（类名全是哈希的站点）
    const kids = Array.from(root.children);
    for (let i = 1; i < kids.length; i++) {
      const head = kids[i - 1];
      const body = kids[i];
      if (!alive(head) || !alive(body)) continue;
      if (!thinkHeaderText(head)) continue;
      if (tooBig(body)) continue;
      head.remove();
      body.remove();
    }

    // 3) 兜底：类名是哈希、抬头又被塞进按钮里，只能看「开头第一块」。
    //    抬头后面必须带着「用时 / 秒 / for」这类时间词，否则不动手。
    for (const k of Array.from(root.children).slice(0, 3)) {
      if (!alive(k) || tooBig(k)) break;
      const txt = (k.textContent || '').trim();
      if (!txt) continue;
      const head = txt.slice(0, 40);
      if (!thinkHeaderOf(head)) break;
      if (txt.length > 40 && !/[0-9]\s*秒|用时|for\s+[0-9]/i.test(head)) break;
      k.remove();
      break;
    }
  }

  /* ------------------------------------------------------------ 文本处理 */

  function normSpace(s) {
    return String(s || '').replace(/[\u200b\u200c\u200d\ufeff]/g, '').replace(/\s+/g, ' ');
  }

  function sameMarks(a, b) {
    return a.b === b.b && a.i === b.i && a.st === b.st && a.code === b.code
      && a.sup === b.sup && a.sub === b.sub && a.link === b.link;
  }

  /** 合并相邻同格式文字，去掉首尾空格和空节点 */
  function tidyInline(list) {
    const out = [];
    for (let node of list) {
      if (node.t === 'text') {
        node = Object.assign({}, node, { v: normSpace(node.v) });
        if (!node.v) continue;
        const prev = out[out.length - 1];
        if (prev && prev.t === 'text' && sameMarks(prev, node)) {
          prev.v += node.v;
          continue;
        }
        const copy = { t: 'text', v: node.v };
        ['b', 'i', 'st', 'code', 'sup', 'sub', 'link'].forEach((k) => {
          if (node[k]) copy[k] = node[k];
        });
        out.push(copy);
      } else if (node.t === 'math' || node.t === 'br') {
        out.push(node);
      }
    }
    // 段落首尾的空白不需要
    if (out.length && out[0].t === 'text') out[0].v = out[0].v.replace(/^ +/, '');
    const last = out[out.length - 1];
    if (last && last.t === 'text') last.v = last.v.replace(/ +$/, '');
    return out.filter((n) => !(n.t === 'text' && !n.v));
  }

  /* ------------------------------------------------------------ 行内 */

  function inlineOf(el, mathMap, marks, skip) {
    const out = [];
    marks = marks || {};

    for (const node of el.childNodes) {
      if (node.nodeType === 3) {
        out.push(Object.assign({ t: 'text', v: node.nodeValue }, marks));
        continue;
      }
      if (node.nodeType !== 1) continue;

      if (mathMap && mathMap.has(node)) {
        const m = mathMap.get(node);
        const run = mathRun(m, m.display);
        if (run) out.push(run);
        continue;
      }

      const tag = node.tagName.toLowerCase();
      if (skip && skip.has(tag)) continue;
      if (tag === 'br') { out.push({ t: 'br' }); continue; }
      if (NOISE_TAGS.has(tag) || node.hasAttribute('data-p2d-skip') && !mathMap.has(node)) continue;
      if (node.getAttribute('aria-hidden') === 'true') continue;
      if (tag === 'p2d-math') continue;

      const m = Object.assign({}, marks);
      if (tag === 'strong' || tag === 'b') m.b = 1;
      if (tag === 'em' || tag === 'i' || tag === 'cite' || tag === 'var') m.i = 1;
      if (tag === 'del' || tag === 's' || tag === 'strike') m.st = 1;
      if (tag === 'sup') m.sup = 1;
      if (tag === 'sub') m.sub = 1;
      if (tag === 'code' || tag === 'kbd' || tag === 'samp') m.code = 1;
      if (tag === 'a' && node.getAttribute('href')) {
        const href = node.getAttribute('href');
        if (href && !href.startsWith('#') && !href.startsWith('javascript:')) {
          try { m.link = new URL(href, location.href).href; } catch (e) { /* 忽略 */ }
        }
      }
      out.push(...inlineOf(node, mathMap, m, skip));
    }
    return out;
  }

  /* ------------------------------------------------------------ 块级 */

  function hasBlockChild(el) {
    for (const c of el.children) {
      const t = c.tagName.toLowerCase();
      if (BLOCK_TAGS.has(t) && t !== 'li') return true;
      if (c.tagName.toLowerCase() === 'p2d-math') return true;
    }
    return false;
  }

  /* ------------------------------------------------------- 块级枚举
   * 「自由选择」要在页面上给每个能整块复制的元素挂一个点。
   * 这份枚举必须和 convertBlocks 的粒度对齐：一个 <ul> 算一块（不是每个 <li>），
   * 只有内联内容的 <div> 也算一块，外层套壳则继续往里走。
   */
  const PICK_TAGS = new Set([
    'p', 'pre', 'table', 'blockquote', 'ul', 'ol', 'dl', 'figure', 'details',
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p2d-math'
  ]);

  function isMathBlock(el) {
    const t = el.tagName.toLowerCase();
    return t === 'math' || t === 'mjx-container' || t === 'p2d-math'
      || el.classList.contains('katex-display')
      || el.classList.contains('katex')
      || el.hasAttribute('data-latex') || el.hasAttribute('data-tex');
  }

  function blockEls(root) {
    const out = [];
    const walk = (parent) => {
      const before = out.length;
      for (const c of parent.children) {
        const tag = c.tagName.toLowerCase();
        if (isMathBlock(c)) { out.push(c); continue; }   // math 在 NOISE_TAGS 里，先拦下
        if (NOISE_TAGS.has(tag)) continue;
        if (c.getAttribute('aria-hidden') === 'true') continue;
        if (tag === 'li') continue;                 // 列表项归它的 ul/ol
        if (isThinkBox(c)) continue;                // 思考面板不参与选择
        try {
          if (c.matches(NOISE_SELECTOR)) continue;  // 工具栏、复制按钮那一类
        } catch (e) { /* 选择器不合法就算了 */ }
        /* 列表按「一条分点」切：顶层每个 li 各算一块。
           以前整个 <ul> 算一块，一个三条的分点列表点哪儿都是整块，
           想单独复制其中一条根本做不到。li 里套的嵌套列表仍归这条 li。 */
        if (tag === 'ul' || tag === 'ol') {
          const items = [];
          for (const li of c.children) {
            if (li.tagName.toLowerCase() !== 'li') continue;
            if (!(li.textContent || '').trim()) continue;
            if (isThinkBox(li)) continue;
            items.push(li);
          }
          if (items.length) { out.push(...items); continue; }
          out.push(c); continue;
        }
        if (PICK_TAGS.has(tag)) { out.push(c); continue; }
        if (hasBlockChild(c)) { walk(c); continue; }
        // 只有块级元素才算一块。内联元素（span / a / b …）永远不是「一段」——
        // 以前这里只要有文字就 push，于是 <div><span>一句话</span><span>几个字</span></div>
        // 被切成好几块，「一句话也算一段」就是这么来的。
        if (BLOCK_TAGS.has(tag) && (c.textContent || '').trim()) { out.push(c); continue; }
      }
      // 这一层全是内联内容：整层就是一段，块落在容器上，不落在 span 上
      if (out.length === before && (parent.textContent || '').trim()) out.push(parent);
    };
    walk(root);
    return out;
  }

  /** 从任意元素向上收敛到「一个可整块复制的块」，用于鼠标点选 */
  function blockFrom(el) {
    if (!el || el.nodeType !== 1) return null;

    /* 点到公式身上：独立公式就选它自己（含 .katex-display 那层壳），
       夹在文字中间的，选它所在的那一段 —— 反正选完都是这一段。 */
    const mb = mathBox(el);
    if (mb) {
      const host = mb.closest('p, h1, h2, h3, h4, h5, h6, li, td, th, blockquote');
      if (!host) return mb.closest('.katex-display') || mb;
      const t = host.tagName.toLowerCase();
      if (t === 'li') return host.closest('ul, ol') || host;
      return host;
    }

    let cur = el;
    for (let i = 0; i < 20 && cur && cur !== document.body; i++) {
      const tag = cur.tagName.toLowerCase();
      if (tag === 'li') {
        const box = cur.closest('ul, ol');
        return box || cur;
      }
      if (PICK_TAGS.has(tag)) return cur;
      if ((tag === 'div' || tag === 'section' || tag === 'article')
          && !hasBlockChild(cur) && (cur.textContent || '').trim()) {
        return cur;
      }
      cur = cur.parentElement;
    }
    return null;
  }

  /** 两个块的最小公共祖先；同一个块就取它的父级 */
  function commonBox(a, b) {
    if (!a || !b) return null;
    if (a === b) return a.parentElement || a;
    if (a.contains(b)) return a;
    if (b.contains(a)) return b;
    let cur = a.parentElement;
    while (cur && cur !== document.body && !cur.contains(b)) cur = cur.parentElement;
    return cur;
  }

  /** 块在「容器块列表」里的下标（li 会归到它的 ul 上） */
  function indexAmong(els, el, box) {
    let cur = el;
    for (let i = 0; i < 20 && cur && cur !== box; i++) {
      const k = els.indexOf(cur);
      if (k >= 0) return k;
      cur = cur.parentElement;
    }
    return -1;
  }

  /**
   * 点选锚点：把「鼠标下面的元素」换成 { box, els, i, el }。
   *
   * 关键是要和复制共用同一份块列表：els 就是 box 里那份 blockEls，
   * i 是 el 在里面的下标，复制时按同一个下标切（modelFromRange），
   * 画高亮也按同一份 els 画 —— 看到多大就复制多大。
   * 以前是「画框用一套元素、复制时再重新数一遍」，两边对不上，
   * 才会出现点了小段却复制出大段（或者反过来只复制到一小截）。
   */
  /* ------------------------------------------ 指针 -> 块（只看几何，不爬祖先）
   *
   * 三个模式共用一份「块表」——blockEls 的扁平列表，和 modelFromRange 切片用
   * 的是同一套下标 —— 但选什么由模式决定：
   *     all          -> 整条回答
   *     para / range -> 块表里的一块，永远是同一粒度
   *
   * 以前是「命中的元素往上收，收到块列表里有它为止」，这条链上任何一层都可能
   * 是容器：指针落在小段上是小段，落在小段之间的空白就升成大段，落在大段之间
   * 的空白再升成全文。三个模式共用它，自然就混成一个样。
   * 现在只比矩形：指针在谁的矩形里就是谁；落在空白里就取上下最近的那块，
   * 绝不升级成外层容器。整条回答则单独由 answerAtPoint 负责。
   */

  function isLeafBlock(el) {
    return !!el && el.nodeType === 1 && PICK_TAGS.has(el.tagName.toLowerCase());
  }

  function displayOf(el) {
    try { return getComputedStyle(el).display || ''; } catch (e) { return ''; }
  }

  /**
   * 这个容器里是不是只有内联内容（一行字、几个 span）。
   *
   * 这是「一段」和「一条回答」的分界线：只有内联内容的容器，最多算一段，
   * 绝不能当成整条回答。真实站点把一条回答拆成一堆兄弟 fragment 的时候，
   * 每个 fragment 都是这种形状 —— 全文模式出错就是从这里开始的。
   */
  function isInlineOnly(el) {
    if (!el || el.nodeType !== 1) return false;
    const kids = el.children;
    if (!kids.length) return !!(el.textContent || '').trim();
    for (let i = 0; i < kids.length; i++) {
      const c = kids[i];
      const tag = c.tagName.toLowerCase();
      if (tag === 'br') continue;
      if (BLOCK_TAGS.has(tag) || PICK_TAGS.has(tag) || isMathBlock(c)) return false;
    }
    // 剩下的都是内联标签或自定义标签：自定义标签要问一次计算样式
    for (let i = 0; i < kids.length && i < 6; i++) {
      const c = kids[i];
      if (INLINE_TAGS.has(c.tagName.toLowerCase())) continue;
      const d = displayOf(c);
      if (d && !/^(inline|contents|none)/.test(d)) return false;
    }
    return !!(el.textContent || '').trim();
  }

  /* -------------------------------------------- 「一条回答」的形状
   *
   * 一条回答 = 装得下块级内容的容器；一段 = 一个叶子块。这两件事必须各判各的，
   * 混成一个「容器」概念，就会出现用户看到的那对毛病：
   *   单段 → 把段落里的 span 当一块（一句话、几个字也算一段）
   *   全文 → 把一段当一条回答（蓝框只框一段，复制的也只有一段）
   * 所以这里问的只有一件事：它装得下不止一段吗？装不下就往外抬，抬到装得下为止。
   */

  /**
   * 这个容器「像一条回答」吗。
   *
   * 判据只有两条：装得下正文容器，而且不止一块。
   * 只装得下一块的容器一律当「一段」—— 站点把回答拆成碎片时，每个碎片都是这个形状，
   * 认成回答就会出现「全文只框到一段」。
   */
  function answerShaped(el) {
    if (!el || el.nodeType !== 1) return false;
    if (isLeafBlock(el) || isInlineOnly(el)) return false;
    const content = contentOf(el) || el;
    if (isLeafBlock(content) || isInlineOnly(content)) return false;
    return groupCount(content) >= 2;
  }

  const kindOf = (el) => el.tagName + '|'
    + ((el.className && typeof el.className === 'string') ? el.className : '');

  function leafCount(el) {
    return el.querySelectorAll('p, pre, table, blockquote, ul, ol, h1, h2, h3, h4, h5, h6').length;
  }

  /**
   * 「有几块」—— 一个列表整体只算一块。
   *
   * 块表（blockEls）现在按 li 切分，是为了点选粒度；但判断「这一层像不像一条回答」时
   * 不能跟着按 li 数：一个只有三条分点的碎片会被数成 3 块，被误当成完整回答，
   * 全文模式就又会停在半截。所以判形状时用这个按「组」数的版本。
   */
  function groupCount(el) {
    let n = 0;
    for (const b of blockEls(el)) {
      const t = b.tagName.toLowerCase();
      if (t === 'li') {
        // 每个列表只数它第一条
        const prev = b.previousElementSibling;
        if (!prev || prev.tagName.toLowerCase() !== 'li') n++;
        continue;
      }
      n++;
    }
    return n;
  }

  /**
   * 兄弟里有「另一条消息」吗 —— 有就说明这一层是消息列表，再往外抬就是整段对话。
   *
   * 同一股块流里的碎片（同标签同 class、而且只有一块）不算另一条消息：
   * 它们本来就是同一条回答被拆开的那几截。
   */
  function hasOtherMessage(up, cur) {
    const mine = kindOf(cur);
    for (const c of up.children) {
      if (c === cur || c.contains(cur) || cur.contains(c)) continue;
      const tag = c.tagName.toLowerCase();
      if (NOISE_TAGS.has(tag)) continue;
      try {
        if (c.matches(NOISE_SELECTOR)) continue;
      } catch (e) { /* 选择器不合法就算了 */ }
      const r = c.getBoundingClientRect();
      if (!r.height || r.height < 40) continue;
      /* 同标签同 class 的兄弟是「同一股块流的下一块」，不是另一条消息：
         demo 里的 .g1 分组、碎片页的兄弟碎片都属于这种，不能把全文卡在半截 */
      if (kindOf(c) === mine) continue;
      /* 兄弟是「自己那一轮提问」：这一层就是消息列表，再往外抬就是整段对话 */
      if (looksLikeUserTurn(c)) return true;
      if (isLeafBlock(c)) continue;                  // 一张表 / 一段代码是正文，不是消息
      const chars = (c.textContent || '').trim().length;
      // 又长又多块：这才像「另一条完整的消息」；一个浅色分组块（几十个字）不算
      if (groupCount(c) >= 3 && chars > 200) return true;
      if (chars > 400) return true;
    }
    return false;
  }

  /** 「up 里的第一条就是一句提问」—— cur 就是回答的开头，别再往外抬 */
  function startsAnswer(up, cur) {
    const prev = cur.previousElementSibling;
    if (!prev || prev !== up.firstElementChild) return false;
    const tag = prev.tagName.toLowerCase();
    if (NOISE_TAGS.has(tag)) return false;
    if (BLOCK_TAGS.has(tag) && hasBlockChild(prev)) return false;
    const t = (prev.textContent || '').trim();
    if (!t || t.length > 80) return false;
    return /[？?]/.test(t);
  }

  /* 操作条 / 头像这类「消息壳」的标志：它们和正文并排，但不属于正文 */
  const SHELL_HINT = /action|toolbar|footer|avatar|operate|tools|feedback|like|朗读|转发/i;

  /** up 是不是「消息壳」：正文之外还挂着操作条 / 头像 / 朗读那一排按钮 */
  function hasChromeSibling(up, cur) {
    for (const c of up.children) {
      if (c === cur || c.contains(cur)) continue;
      const tag = c.tagName.toLowerCase();
      if (tag === 'button' || tag === 'img' || tag === 'svg') return true;
      try {
        if (c.matches(NOISE_SELECTOR)) return true;
      } catch (e) { /* 选择器不合法就算了 */ }
      const cls = (c.className && typeof c.className === 'string') ? c.className : '';
      const role = c.getAttribute('role') || '';
      if (!SHELL_HINT.test(cls + ' ' + role)) continue;
      const r = c.getBoundingClientRect();
      if (r.height && r.height < 160) return true;     // 矮的一条：按钮条，不是正文块
    }
    return false;
  }

  /**
   * 往上抬到「像一条回答」的那一层。
   *
   * 一路往上抬是必要的：站点把回答拆成碎片时，站得离指针最近的那层只是其中一段。
   * 但抬到这几处必须停：
   *   · 上一条是提问（回答从 cur 开始）
   *   · 兄弟里有别的消息（这一层是消息列表）
   *   · up 是消息壳（正文旁边挂着操作条），cur 就是正文
   *   · 已经占到一屏
   * 落点取「一路遇到的最大的、像回答的那一层」；一层都没有就取最后一个停下的位置。
   */
  function ensureAnswer(el) {
    if (!el) return null;
    let best = answerShaped(el) ? el : null;
    let cur = el;
    for (let i = 0; i < 6; i++) {
      const up = cur.parentElement;
      if (!up || up === document.body || up === document.documentElement) break;
      if (inChrome(up)) break;
      /* 抬到「装着输入框 / 装着好几条消息」的那一层就是整页了：停。
         少了这一条，指着顶栏、输入框、页面空白时都会一路抬到一个大容器，
         然后被当成「一整条回答」框起来 —— 用户看到的就是「整个大页面被识别成全文」。 */
      if (isAppShell(up)) break;
      if (startsAnswer(up, cur)) break;
      if (hasOtherMessage(up, cur)) break;
      if (hasChromeSibling(up, cur)) { best = best || cur; break; }   // up 是壳，cur 是正文
      const r = up.getBoundingClientRect();
      if (!r.height || r.height > window.innerHeight * 0.92) break;
      if (leafCount(up) > 80) break;                 // 块太多：已经是一整段对话了
      cur = up;
      if (answerShaped(up)) best = up;
    }
    return best || cur;
  }

  function visRect(el) {
    if (!el || !el.getBoundingClientRect) return null;
    const b = el.getBoundingClientRect();
    return (b.width > 0 && b.height > 0) ? b : null;
  }

  /**
   * 指针落在哪一块的矩形里。**只认落在块身上的**：指在段与段之间的空白、
   * 正文容器的边距上，一律返回 -1（不拿「最近的一块」凑数）。
   * 这是「空白处不判定」的唯一实现点，单段与区间都走它。
   */
  function indexInside(els, x, y) {
    let best = -1;
    let bestArea = Infinity;
    for (let i = 0; i < els.length; i++) {
      const b = visRect(els[i]);
      if (!b) continue;
      if (x >= b.left && x <= b.right && y >= b.top && y <= b.bottom) {
        const area = b.width * b.height;
        if (area < bestArea) { bestArea = area; best = i; }
      }
    }
    return best;
  }

  /* 回答列表在指针移动时会被反复查：短时间内复用，避免每移动一像素就扫一遍 DOM */
  let rootsCache = { at: 0, list: [] };
  function answerBoxes() {
    const now = Date.now();
    if (now - rootsCache.at < 400) return rootsCache.list;
    const list = [];
    for (const r of NS.answerRoots()) list.push({ root: r, content: contentOf(r) || r });
    rootsCache = { at: now, list };
    return list;
  }

  /**
   * 从任意元素得到「整条回答」。
   *
   * 认出来的元素如果只是「一段」（叶子块、或只包一行内联文字的碎片），
   * 就往外抬到真正装得下正文的那一层 —— 有的站点把一条回答拆成几十个
   * 兄弟 fragment，认出来的每一个都只是其中一段，全文模式会只框到一段。
   */
  /**
   * 短横条：顶栏、工具栏、面包屑这一类的形状。
   *
   * 它们也是 div、也有一行字，但绝不是「正文的一部分」。指到上面不该有任何蓝框 ——
   * 以前指在会话标题上，会顺着祖先链一路抬成一个「全文」框，就是这个原因。
   */
  function isBarLike(el) {
    if (!el || el.nodeType !== 1) return false;
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) return false;
    if (r.height > 72) return false;                        // 一行 / 两行高
    if (r.width < window.innerWidth * 0.3) return false;    // 横贯一条
    /* 里面装着块级内容的不是横条（那是一个窄的正文块） */
    return !hasBlockChild(el);
  }

  function answerRootOf(el) {
    if (!el || el.nodeType !== 1) return null;
    /* 先问「这个元素上面有没有一处像正文」。没有的话，只有它是页面里的一块内容
       （不是顶栏那种短横条）时，才把它自己当作起点往上抬 —— 指在段间空白上仍然要
       能框住整条回答，而指在会话标题、工具栏上则什么都不该给。 */
    const r = findAnswerRoot(el) || (isBarLike(el) ? null : el);
    if (!r) return null;
    const ans = ensureAnswer(r);
    /* 抬到最后还是个「不像回答」的东西（例如消息底部那排按钮所在的 div），
       就当这里不是正文 —— 不然指着「复制 / 重试」也会画一个框出来。 */
    if (!ans || !answerShaped(ans)) return null;
    /* 里面装着输入框 / 两条以上消息：这是整页或者整个对话区，不是一条回答 */
    if (isAppShell(ans)) return null;
    return ans;
  }

  /* 自检：如果框住的这条回答，开头正好是「已思考（用时 16 秒）」这类抬头，
     说明这个站点的思考区没被认出来（结构和我认的不一样）。
     在控制台留一行，用户截图发过来就能照着补规则。 */
  let toldOnce = null;
  function warnIfThinkInside(root) {
    if (!root || root === toldOnce) return;
    let first = null;
    try { first = (contentOf(root) || root).firstElementChild; } catch (e) { return; }
    const head = first ? thinkHeaderText(first) : '';
    if (!head) return;
    toldOnce = root;
    console.warn('[内容直贴] 这条回答的开头是「' + head + '」，看着像思考面板的抬头，'
      + '但没被认成思考区。把下面这个元素连同它的 parentElement 发我：', first);
  }

  /**
   * 指针所在的「整条回答」。
   *
   * 判据是**正文容器矩形**，不是消息容器的矩形 —— 这一条决定了工具栏不会被框进来：
   * 复制 / 重试 / 点赞 / 朗读 / 转发那一排按钮虽然长在这条消息里，但不在正文里，
   * 指针落上去时这里返回 null，既不画框也不复制。
   *
   * 也**不再**「取上下最近的那条回答」：那个兜底会把鼠标指到两条回答之间时
   * 悄悄认成其中一条，正是「复制出后文思考内容」的来源。
   */
  function answerAtPoint(x, y) {
    const under = document.elementFromPoint(x, y);
    if (under && inChrome(under)) return null;

    /* 思考过程、自己提的问题：一律不认。
       这一刀必须切在「按元素兜底」之前 —— 兜底是从指针下面的元素往上摸回答容器的，
       摸到思考块 / 用户气泡时一样会给出一个框，那正是「思考内容也有蓝框」的来源。 */
    if (under && (inThink(under) || userTurnOf(under))) return null;

    let best = null;
    let bestArea = Infinity;
    for (const it of answerBoxes()) {
      const b = visRect(it.content);
      if (!b) continue;
      if (x >= b.left - 4 && x <= b.right + 4 && y >= b.top - 4 && y <= b.bottom + 4) {
        const area = b.width * b.height;
        if (area < bestArea) { bestArea = area; best = it.root; }
      }
    }
    if (best) {
      const ans = ensureAnswer(best);
      if (!ans || isAppShell(ans)) return null;
      warnIfThinkInside(ans);
      return ans;
    }

    // 站点结构没被识别出来（没有 .markdown、没有 role 标记）：退回元素归属，
    // 但同样要求指针真在它的正文矩形里，否则一律不认。
    const own = under ? answerRootOf(under) : null;
    if (own) {
      const b = visRect(contentOf(own) || own);
      if (b && x >= b.left - 8 && x <= b.right + 8 && y >= b.top - 8 && y <= b.bottom + 8) {
        warnIfThinkInside(own);
        return own;
      }
    }
    return null;
  }

  /** 指针所在的「一块」：单段 / 区间用。返回 {root, content, els, i, el} */
  function blockAtPoint(x, y) {
    const root = answerAtPoint(x, y);
    if (!root) return null;
    const content = contentOf(root) || root;
    const els = blockEls(content);
    if (!els.length) return null;
    const i = indexInside(els, x, y);     // 空白处 = -1，不猜
    if (i < 0) return null;
    return { root, content, els, i, el: els[i] };
  }

  /** 元素版锚点：给测试和「按元素问块」用，粒度与 blockAtPoint 完全一致 */
  function anchorOf(el, mode) {
    if (!el || el.nodeType !== 1) return null;
    const root = answerRootOf(el);
    if (mode === 'all') return root ? { root } : null;
    if (!root) return null;
    const content = contentOf(root) || root;
    const els = blockEls(content);
    let cur = el;
    for (let k = 0; k < 20 && cur && cur !== content; k++) {
      const at = els.indexOf(cur);
      if (at >= 0) return { root, content, box: content, els, i: at, el: els[at] };
      cur = cur.parentElement;
    }
    return null;
  }

  /** 这块（或它的祖先）是思考面板吗 —— blockEls 用它把思考内容挡在块表外 */
  function isThinkBox(el) {
    if (!el || el.nodeType !== 1) return false;
    if (inThink(el)) return true;
    // <details><summary>深度思考（用时 8 秒）</summary>…</details> 这种折叠面板
    const first = el.firstElementChild;
    if (first && first.tagName.toLowerCase() === 'summary' && thinkHeaderText(first)) return true;
    // 段落 / 标题 / 列表这些本身就是正文块，只有「整块就是那行抬头」时才当思考
    if (PICK_TAGS.has(el.tagName.toLowerCase())) return false;
    return !!thinkHeaderText(el);
  }

  /**
   * 这一个元素是不是落在「思考过程」里。
   *
   * 两种认法，都不限层数：
   *   1) 类名 / 属性对得上（.ds-think-content 这类设计系统类名最稳）——
   *      用 closest，思考内容埋在十几层 div 里也能抓到（以前只往上找 6 层，深一点就漏）；
   *   2) 前面单独挂着一行「已思考（用时 16 秒）」这类抬头 —— 那块就是思考正文。
   *      类名全是哈希、认不出类名的站点靠这一条。
   */
  function inThink(el) {
    if (!el || el.nodeType !== 1) return null;
    if (thinkMemo.has(el)) return thinkMemo.get(el);
    let box = null;
    try { box = el.closest(THINK_SEL); } catch (e) { box = null; }
    let hit = box ? (isAppShell(box) ? null : box) : null;
    if (!hit && thinkHeaderText(el)) hit = el;          // 指的就是那行抬头
    if (!hit && afterThinkHead(document.body, el)) hit = el;
    thinkMemo.set(el, hit);
    return hit;
  }

  /* 用户提问的类名：按「词」比，不能按子串 —— Tailwind 的 user-select-none
     这类工具类会让一整片界面都被当成提问。 */
  const USER_TOKEN = /^(user|human|question)([-_]?(message|msg|bubble|turn|query|prompt|text|content|row))?$/i;
  const USER_TOKEN_TAIL = /[-_](user|human)([-_](message|msg|bubble|turn|query|prompt|text|content|row))?$/i;

  function userClassOf(el) {
    const cls = (el.className && typeof el.className === 'string') ? el.className : '';
    if (!cls) return false;
    for (const t of cls.split(/\s+/)) {
      if (!t) continue;
      if (USER_TOKEN.test(t) || USER_TOKEN_TAIL.test(t)) return true;
    }
    return false;
  }

  /**
   * 看形状：贴着右边、比自己所在的这一列明显窄的气泡。
   *
   * 这是给「没有任何角色标记」的站点用的（DeepSeek 就是这种：类名是哈希，
   * 用户气泡只靠右对齐 + 圆角底色区分）。回答正文永远是左侧通栏，
   * 所以右对齐的窄块一定是用户自己说的话。
   */
  function rightBubble(el) {
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) return false;
    if (r.height > window.innerHeight * 0.45) return false;
    const p = el.parentElement;
    if (!p) return false;
    const pr = p.getBoundingClientRect();
    if (!pr.width || pr.width < 280) return false;
    const gap = Math.abs(pr.right - r.right);
    if (gap > Math.max(20, pr.width * 0.05)) return false;
    if (r.left - pr.left < pr.width * 0.2) return false;
    return r.width < pr.width * 0.94;      // 通栏的正文不算气泡，剩下都算
  }

  /** 这一整块是不是「自己那一轮」（里面装着一个右侧气泡，或者自己就标着用户） */
  function looksLikeUserTurn(el) {
    if (!el || el.nodeType !== 1) return false;
    if (messageRole(el) === 'user' || userClassOf(el)) return true;
    /* 只看两层：气泡总是这一轮的（直接或隔一层）子元素，往下扫整棵子树既慢又没必要 */
    const kids = el.children;
    for (let i = 0; i < kids.length && i < 8; i++) {
      if (rightBubble(kids[i])) return true;
      const g = kids[i].children;
      for (let j = 0; j < g.length && j < 6; j++) {
        if (rightBubble(g[j])) return true;
      }
    }
    return false;
  }

  /** 这个元素是不是「用户自己说的话」：角色标记 / 类名 / 右侧气泡的形状 */
  function userTurnOf(el) {
    let cur = el;
    for (let i = 0; i < 8 && cur && cur.nodeType === 1 && cur !== document.body; i++) {
      if (messageRole(cur) === 'user') return cur;
      if (userClassOf(cur)) return cur;
      if (rightBubble(cur)) return cur;
      cur = cur.parentElement;
    }
    return null;
  }

  /**
   * 站点拿「整段加粗」冒充小标题的情况（Markdown 里写成 **小标题** 那种）。
   * 判据收紧到：整段只有一个 strong/b、文字就是它的全部、短、不带句末标点。
   * 这样「**结论**：……」这种行内强调不会被当成标题。
   */
  function headingLevelOf(node, inl) {
    if (!/^(P|DIV|SECTION)$/.test(node.tagName)) return 0;
    if (!inl.length || inl.length > 2) return 0;
    let text = '';
    for (const n of inl) {
      if (n.t !== 'text' || !n.v.trim()) return 0;
      if (!n.b) return 0;
      text += n.v;
    }
    text = text.trim();
    if (text.length < 2 || text.length > 24) return 0;
    if (/[。！？；，、：:,.;!?…]$/.test(text)) return 0;
    if (/^[\d\s.、()（）]+$/.test(text)) return 0;
    const kids = Array.from(node.children).filter((c) => (c.textContent || '').trim());
    if (kids.length !== 1) return 0;
    if (!/^(STRONG|B)$/.test(kids[0].tagName)) return 0;
    if ((node.textContent || '').trim() !== (kids[0].textContent || '').trim()) return 0;
    return 3;
  }

  function convertBlocks(root, mathMap, out, opts) {
    out = out || [];
    let buf = [];

    const flush = () => {
      const inl = tidyInline(buf);
      if (inl.length) out.push({ t: 'p', inl });
      buf = [];
    };

    const push = (block) => {
      if (!block) return;
      if (Array.isArray(block)) out.push(...block);
      else out.push(block);
    };

    for (const node of root.childNodes) {
      if (node.nodeType === 3) {
        if (node.nodeValue && node.nodeValue.trim()) buf.push({ t: 'text', v: node.nodeValue });
        continue;
      }
      if (node.nodeType !== 1) continue;

      if (mathMap.has(node)) {
        const m = mathMap.get(node);
        const run = mathRun(m, m.display);
        if (!run) continue;
        if (m.display && !buf.length && run.t === 'math') {
          flush();
          out.push({ t: 'math', mathml: m.mathml, latex: m.latex });
        } else {
          buf.push(run);
        }
        continue;
      }

      const tag = node.tagName.toLowerCase();
      if (NOISE_TAGS.has(tag)) continue;
      if (node.getAttribute('aria-hidden') === 'true') continue;
      if (node.hasAttribute('data-p2d-skip') && tag !== 'p2d-math') continue;

      // 思考面板：类名能认就删，认不出再按「第一行是那句标题」认。兜住
      // stripThinking 因为比例保护而没删掉的那一块。太大的不当面板，
      // 免得把整条回答误判成思考而丢掉。
      if (isThinkBox(node)
          && (node.textContent || '').length <= (root.textContent || '').length * 0.6) {
        continue;
      }

      if (tag === 'p2d-math') continue;

      if (/^h[1-6]$/.test(tag)) {
        flush();
        const inl = tidyInline(inlineOf(node, mathMap));
        if (inl.length) out.push({ t: 'h', level: Number(tag[1]), inl });
        continue;
      }

      if (tag === 'p') {
        flush();
        const inl = tidyInline(inlineOf(node, mathMap));
        if (!inl.length) continue;
        // 段落里只有一个独立公式（KaTeX 常把 .katex-display 塞进 p）：
        // 按独立公式排，不要压成行内
        if (inl.length === 1 && inl[0].t === 'math' && inl[0].display) {
          out.push({ t: 'math', mathml: inl[0].mathml, latex: inl[0].latex });
          continue;
        }
        const hv = headingLevelOf(node, inl);
        if (hv) { out.push({ t: 'h', level: hv, inl }); continue; }
        out.push({ t: 'p', inl });
        continue;
      }

      if (tag === 'ul' || tag === 'ol') {
        flush();
        const list = listOf(node, mathMap, 0);
        if (list) out.push(list);
        continue;
      }

      if (tag === 'pre') {
        flush();
        out.push(codeOf(node));
        continue;
      }

      if (tag === 'table') {
        flush();
        const t = tableOf(node, mathMap, opts);
        if (t) out.push(t);
        continue;
      }

      if (tag === 'blockquote') {
        flush();
        const inner = convertBlocks(node, mathMap, [], opts);
        inner.forEach((b) => {
          if (b.t === 'p') b.q = 1;
        });
        out.push(...inner);
        continue;
      }

      if (tag === 'hr') { flush(); continue; }

      if (tag === 'dl') {
        flush();
        for (const c of node.children) {
          const ct = c.tagName.toLowerCase();
          if (ct === 'dt') {
            const inl = tidyInline(inlineOf(c, mathMap, { b: 1 }));
            if (inl.length) out.push({ t: 'p', inl });
          } else if (ct === 'dd') {
            const inl = tidyInline(inlineOf(c, mathMap, { i: 1 }));
            if (inl.length) out.push({ t: 'p', inl });
          }
        }
        continue;
      }

      if (tag === 'figure' || tag === 'figcaption') {
        // 图不渲染（GUIDE 里明确不做图片），图注当普通段落保留
        if (tag === 'figcaption') {
          flush();
          const inl = tidyInline(inlineOf(node, mathMap));
          if (inl.length) out.push({ t: 'p', inl });
        } else {
          flush();
          out.push(...convertBlocks(node, mathMap, [], opts));
        }
        continue;
      }

      if (tag === 'li') {
        // 没有 ul/ol 包裹的野 li，按段落处理
        flush();
        const inl = tidyInline(inlineOf(node, mathMap, {}, LIST_SKIP));
        if (inl.length) out.push({ t: 'p', inl });
        continue;
      }

      if (BLOCK_TAGS.has(tag)) {
        if (hasBlockChild(node)) {
          flush();
          out.push(...convertBlocks(node, mathMap, [], opts));
        } else {
          // 拿 div 当段落的站点很多（DeepSeek 早期、部分国产页面）：
          // div 本身是块级元素，一个 div 就是一段，不能和后面的同类累积成一段
          flush();
          const inl = tidyInline(inlineOf(node, mathMap));
          if (!inl.length) continue;
          const hv = headingLevelOf(node, inl);
          if (hv) { out.push({ t: 'h', level: hv, inl }); continue; }
          out.push({ t: 'p', inl });
        }
        continue;
      }

      if (INLINE_TAGS.has(tag) || !BLOCK_TAGS.has(tag)) {
        buf.push(...inlineOf(node, mathMap));
        continue;
      }
    }

    flush();
    return out;
  }

  /* ------------------------------------------------------------ 列表 */

  function listOf(el, mathMap, level) {
    const ordered = el.tagName.toLowerCase() === 'ol';
    const start = Math.max(1, parseInt(el.getAttribute('start') || '1', 10) || 1);
    const items = [];

    const walk = (listEl, lvl) => {
      const isOrdered = listEl.tagName.toLowerCase() === 'ol';
      for (const li of listEl.children) {
        if (li.tagName.toLowerCase() !== 'li') continue;

        /* 条目自身的文字，嵌套列表交给下一层。
         * 这里不能 cloneNode：公式是照着「占位节点」的引用认的，
         * 复制一份就再也对不上，整条公式会凭空消失。 */
        const inl = tidyInline(inlineOf(li, mathMap, {}, LIST_SKIP));
        if (inl.length) items.push({ lvl, inl });

        // 嵌套列表可能包在 div/p 里，按“最近一层 li”判断归属
        for (const sub of li.querySelectorAll('ul, ol')) {
          if (sub.closest('li') === li) walk(sub, lvl + 1);
        }
      }
      return isOrdered;
    };

    walk(el, level);
    if (!items.length) return null;
    return { t: 'list', ordered, start, items };
  }

  /* ------------------------------------------------------------ 代码 */

  function codeOf(pre) {
    let text = '';
    const code = pre.querySelector('code');
    text = (code ? code.textContent : pre.textContent) || '';
    text = text.replace(/\u00a0/g, ' ').replace(/\r\n?/g, '\n').replace(/^\n+|\n+$/g, '');

    let lang = '';
    const holder = code || pre;
    const m = /(?:language|lang)-([\w+#.-]+)/i.exec(holder.className || '');
    if (m) lang = m[1];
    if (!lang) lang = holder.getAttribute('data-language') || pre.getAttribute('data-language') || '';
    return { t: 'code', lang: lang.toLowerCase(), text };
  }

  /* ------------------------------------------------------------ 表格 */

  function tableOf(el, mathMap, opts) {
    const trs = Array.from(el.querySelectorAll('tr'));
    if (!trs.length) return null;

    const rows = [];
    let ncol = 0;
    for (const tr of trs) {
      const cells = Array.from(tr.children).filter((c) =>
        ['td', 'th'].includes(c.tagName.toLowerCase()));
      if (!cells.length) continue;
      const row = [];
      for (const c of cells) {
        const inl = tidyInline(inlineOf(c, mathMap));
        row.push(inl);
        const span = Math.min(6, parseInt(c.getAttribute('colspan') || '1', 10) || 1);
        for (let k = 1; k < span; k++) row.push([]);
      }
      ncol = Math.max(ncol, row.length);
      rows.push(row);
    }
    if (!rows.length) return null;

    for (const r of rows) while (r.length < ncol) r.push([]);

    const firstRowTh = trs[0] && Array.from(trs[0].children)
      .some((c) => c.tagName.toLowerCase() === 'th');
    const header = !!(el.tHead || firstRowTh);

    return { t: 'table', header, rows };
  }

  /* ------------------------------------------------------- 定位与入口 */

  /* 纯语义的界面区：导航、页眉页脚、输入框、表单 —— 一定不是正文 */
  const CHROME_SEL = 'nav, header, footer, aside, form, [role="navigation"],'
    + ' [role="complementary"], [role="search"], [role="menu"],'
    + ' [contenteditable="true"]';

  /**
   * 像「旁栏」的容器：窄、高、贴着窗口一侧。
   *
   * 光靠 class 里有没有 sidebar 来判不行 —— 很多站点把侧边栏和正文包在同一个
   * `sidebar-layout` 外壳里，按类名排会把整页都排掉。所以这里量几何：
   * 宽度不到窗口 40%、高度过半屏、并且贴着左/右边缘，才算一列侧栏。
   */
  function isSideCol(el) {
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) return false;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    if (r.width > vw * 0.4 || r.height < vh * 0.45) return false;
    const edge = Math.min(220, vw * 0.22);
    return r.left < edge || r.right > vw - edge;
  }

  /** 侧边栏 / 输入区 / 导航里的东西不算正文 */
  function inChrome(el) {
    if (!el || el.nodeType !== 1) return false;
    try {
      if (el.closest(CHROME_SEL)) return true;
    } catch (e) { /* 选择器不合法就算了 */ }
    let cur = el;
    for (let i = 0; i < 4 && cur && cur !== document.body; i++) {
      if (isSideCol(cur)) return true;
      cur = cur.parentElement;
    }
    return false;
  }

  function findAnswerRoot(target) {
    if (!target || target.nodeType !== 1) return null;
    const site = siteOf(location);

    if (site && site.answer) {
      const hit = target.closest(site.answer);
      if (hit && !inChrome(hit) && !isAppShell(hit)) return hit;
    }
    const generic = target.closest(GENERIC_ANSWER);
    if (generic && !inChrome(generic) && !isAppShell(generic)) return generic;

    /* 通用：往上找第一层「像是内容容器」的祖先。
       取**最近**的那一层（一命中就返回），不取最外层 —— 外层常常是整页外壳
       （class 里带 chat-content / message-list 之类），取它就会把整页当一条回答。 */
    let el = target;
    for (let i = 0; i < 14 && el && el !== document.body; i++) {
      if (inChrome(el)) break;
      if (isAppShell(el)) break;
      const cls = (el.className && typeof el.className === 'string') ? el.className : '';
      if (/markdown|prose|message|answer|response|content-body|chat-content/i.test(cls)
          || el.getAttribute('data-message-id')) {
        return el;
      }
      el = el.parentElement;
    }
    return findBlockRoot(target);
  }

  function findBlockRoot(target) {
    if (!target || target.nodeType !== 1) return null;
    let el = target;
    for (let i = 0; i < 12 && el && el !== document.body; i++) {
      const tag = el.tagName.toLowerCase();
      if (['p', 'li', 'pre', 'table', 'blockquote'].includes(tag)) return el;
      if (/^h[1-6]$/.test(tag)) return el;
      if (tag === 'div' || tag === 'section') {
        /* 「div 当段落」的站点：要求没嵌别的块、而且不是一条操作栏。
           顶栏（标题 + 分享按钮）、输入框外壳（textarea + 两个胶囊）都长成 div，
           以前一律当段落返回，于是它们也能被抬成「一条回答」。 */
        if (el.textContent.trim().length >= 8 && !hasBlockChild(el) && !hasControls(el)) return el;
      }
      if (tag === 'p2d-math') return el;
      el = el.parentElement;
    }
    return null;
  }

  /**
   * 这个候选能不能当「正文容器」。
   *
   * 只做一件事：拒绝「一段」。以前不拒，站点给某个 <p> 挂了个 class 带 markdown /
   * message-content 的类名时，正文容器就会变成那一段 —— 全文模式框一段、
   * 单段模式再往里切到 span，就成了「一句话也算一段」。
   */
  function isContentBox(el, root) {
    if (!el || el.nodeType !== 1) return false;
    if (root && el === root) return false;
    if (isLeafBlock(el) || isInlineOnly(el)) return false;
    if (inChrome(el)) return false;
    if (inThink(el)) return false;          // 思考区里的 markdown 不是正文
    try {
      if (el.matches(NOISE_SELECTOR)) return false;
    } catch (e) { /* 选择器不合法就算了 */ }
    return true;
  }

  /**
   * 去掉思考面板之后的正文字数。
   *
   * 判断「认出来的正文是不是只占这一条消息的一小块」时不能连思考内容一起量：
   * DeepSeek 那种「思考 + 回答」并列的结构里，思考常常比回答还长，
   * 拿总数一比，回答永远像碎片，正文就被退回成外层壳（连思考一起框住）。
   */
  /** 这一块里（浅层）有没有单独一行「思考抬头」—— 有的话它整块都是思考区 */
  function containsThinkHeader(el) {
    if (!el || el.nodeType !== 1) return false;
    let level = [el];
    for (let d = 0; d < 3 && level.length; d++) {
      const next = [];
      for (const n of level) {
        for (const c of n.children) {
          if (c.childElementCount <= 6 && thinkHeaderText(c)) return true;
          next.push(c);
        }
      }
      level = next;
    }
    return false;
  }

  /**
   * 「正文」的字数：**扣掉思考区**再量。
   *
   * 不扣的话，思考比回答还长时（DeepSeek 很常见），回答永远像「只占一小块」，
   * 正文就被退回成外层壳 —— 蓝框和剪贴板双双把思考带上。这就是用户报的
   * 「还是会识别思考内容」。
   */
  function bodyLen(root) {
    let n = (root.textContent || '').length;
    let boxes = [];
    try { boxes = Array.from(root.querySelectorAll(THINK_SEL)); } catch (e) { boxes = []; }
    for (const b of boxes) {
      if (boxes.some((o) => o !== b && o.contains(b))) continue;   // 只减最外层
      n -= (b.textContent || '').length;
    }
    // 类名全是哈希的站点：减掉「装着抬头的那一整块」（抬头 + 思考正文）
    for (const c of root.children) {
      let hit = false;
      try { hit = !!c.closest(THINK_SEL); } catch (e) { hit = false; }
      if (hit) continue;                       // 上面已经减过
      if (!containsThinkHeader(c)) continue;
      if (inThink(c)) continue;
      n -= (c.textContent || '').length;
    }
    return Math.max(0, n);
  }

  /** 内容根 -> 只取正文那一层（避开头像、工具栏） */
  function contentOf(root) {
    const hit = contentHit(root);
    /* 认出来的「正文」如果只占这条消息的一小部分，那它其实是一段碎片
       （站点把一条回答拆成几十个兄弟 fragment 的很常见）：这时候正文就是 root 本身。 */
    let out = root;
    if (hit) {
      const full = bodyLen(root);
      const part = (hit.textContent || '').length;
      out = (full > 0 && part < full * 0.6) ? root : hit;
    }
    /* 最后一道闸：这一层把思考也包进来了就往下退一层。
       少了它，只要有一处认错，蓝框和剪贴板就双双把思考带上。 */
    const shrunk = shrinkPastThink(out);
    return shrunk || out;
  }

  function contentHit(root) {
    const site = siteOf(location);
    const ok = (list) => {
      for (const c of list) {
        if (c === root) continue;
        if (!isContentBox(c, root)) continue;      // 一段不算正文容器
        if (afterThinkHead(root, c)) continue;     // 抬头后面那块是思考正文，不是答案
        return c;
      }
      return null;
    };
    if (site && site.content) {
      let hit = null;
      try { hit = ok(root.querySelectorAll(site.content)); } catch (e) { hit = null; }
      if (hit) return hit;
    }
    // 站点没配，就往里找一层「明确是正文」的容器，避免把头像、按钮带进来
    const SEL = '.markdown, .markdown-body, .prose, article, '
      + '[class*="markdown"], [class*="rich-text"], [class*="message-content"]';
    try {
      const hit = ok(root.querySelectorAll(SEL));
      if (hit) return hit;
    } catch (e) { /* 选择器不合法就算了 */ }

    // 没有可识别的正文容器：只有 root 里确实混着工具栏 / 按钮条时，才退而取
    // 「正文块最多」的那个子容器。正常结构里不能这么干 —— 否则会把一个
    // 普通容器拆成它的某个子块，锚点全部对不上。
    let noisy = false;
    for (const c of root.children) {
      try {
        if (c.matches(NOISE_SELECTOR)) { noisy = true; break; }
      } catch (e) { /* 选择器不合法就算了 */ }
    }
    if (!noisy) return null;

    let best = null;
    let bestN = 0;
    for (const c of root.children) {
      if (inChrome(c)) continue;
      try { if (c.matches(NOISE_SELECTOR)) continue; } catch (e) { continue; }
      const n = blockEls(c).length;
      if (n > bestN) { bestN = n; best = c; }
    }
    return (best && bestN >= 2) ? best : null;
  }

  /**
   * 正文层里混进了思考区 —— 说明这一层壳把思考也包进来了（蓝框会连思考一起框住、
   * 复制也会带上）。退到它里面「不含思考、字数又占大头」的那一层去。
   */
  function shrinkPastThink(box) {
    if (!box || !box.querySelector) return null;
    let thinkKid = null;
    for (const c of box.children) {
      if (inThink(c)) { thinkKid = c; break; }
    }
    if (!thinkKid) return null;
    let best = null;
    let bestN = 0;
    for (const c of box.children) {
      if (c === thinkKid || inThink(c)) continue;
      const n = (c.textContent || '').length;
      if (n > bestN) { bestN = n; best = c; }
    }
    if (!best) return null;
    if (bestN < bodyLen(box) * 0.6) return null;   // 只是零碎的一角，别把结构拆了
    return best;
  }

  function messageRole(el) {
    const attrs = ['data-message-author-role', 'data-role', 'data-message-role'];
    for (const a of attrs) {
      const holder = el.closest('[' + a + ']');
      if (holder) return holder.getAttribute(a);
    }
    /* 按词比类名，不按子串：`user-select-none` 这种工具类会被子串匹配误判成提问，
       一整片界面就都不给框了。 */
    if (userClassOf(el)) return 'user';
    const cls = (el.className && typeof el.className === 'string') ? el.className : '';
    if (/assistant|bot|\bai\b|answer|response/i.test(cls)) return 'assistant';
    return '';
  }

  /** 有没有「只有 LaTeX、没有 MathML」的公式 —— 有才需要加载 KaTeX */
  function needsKatex(blocks) {
    const bad = (inl) => (inl || []).some((n) => n.t === 'math' && !n.mathml && n.latex);
    for (const b of blocks) {
      if ((b.t === 'p' || b.t === 'h') && bad(b.inl)) return true;
      if (b.t === 'math' && !b.mathml && b.latex) return true;
      if (b.t === 'list' && b.items.some((it) => bad(it.inl))) return true;
      if (b.t === 'table' && b.rows.some((r) => r.some((c) => bad(c)))) return true;
    }
    return false;
  }

  /** 没有 MathML 的公式：能用 KaTeX 现场渲染就渲染，不能就把 LaTeX 源码当文字保留 */
  async function fixMath(blocks) {
    if (needsKatex(blocks)) await ensureKatex();
    const fixInline = (inl) => (inl || []).map((n) => {
      if (n.t !== 'math') return n;
      if (!n.mathml && n.latex) {
        const m = latexToMathML(n.latex, n.display);
        if (m) return { t: 'math', mathml: m, display: n.display };
      }
      if (!n.mathml) return { t: 'text', v: n.latex || '', code: 1 };
      return n;
    });
    const out = [];
    for (const b of blocks) {
      if (b.t === 'p' || b.t === 'h') {
        out.push(Object.assign({}, b, { inl: fixInline(b.inl) }));
      } else if (b.t === 'math') {
        if (!b.mathml && b.latex) {
          const m = latexToMathML(b.latex, true);
          if (m) out.push({ t: 'math', mathml: m });
          else out.push({ t: 'p', inl: [{ t: 'text', v: b.latex, code: 1 }] });
        } else if (b.mathml) {
          out.push(b);
        } else if (b.text) {
          out.push({ t: 'p', inl: [{ t: 'text', v: b.text, i: 1 }] });
        }
      } else if (b.t === 'list') {
        out.push(Object.assign({}, b, {
          items: b.items.map((it) => Object.assign({}, it, { inl: fixInline(it.inl) }))
        }));
      } else if (b.t === 'table') {
        out.push(Object.assign({}, b, {
          rows: b.rows.map((r) => r.map((c) => fixInline(c)))
        }));
      } else {
        out.push(b);
      }
    }
    return out;
  }

  /** 把元素转成模型（不改动页面：全部在克隆体上做） */
  NS.modelFrom = async function (root, opts) {
    if (!root) return null;
    const clone = root.cloneNode(true);
    stripThinking(clone);
    const mathMap = prepareMath(clone);
    stripNoise(clone);

    const blocks = await fixMath(convertBlocks(clone, mathMap, [], opts || {}));
    const cleaned = NS.cleanBlocks(blocks);
    return cleaned.length ? { blocks: cleaned } : null;
  };

  /** 只取一块（单段模式）：把元素裹进一个壳里，当成一个文档来转换 */
  NS.modelOf = async function (el) {
    if (!el) return null;
    const wrap = document.createElement('div');
    const src = el.cloneNode(true);
    if (el.tagName.toLowerCase() === 'li') {
      /* 单条分点也要保住项目符号：把它放回一个同款列表里再转换。
         有序列表还要把序号接上，免得第三条分点复制出来变成「1.」。 */
      const parent = el.parentElement;
      const ordered = !!parent && parent.tagName.toLowerCase() === 'ol';
      const list = document.createElement(ordered ? 'ol' : 'ul');
      if (ordered) {
        const base = Math.max(1, parseInt((parent && parent.getAttribute('start')) || '1', 10) || 1);
        const idx = parent ? Array.from(parent.children).indexOf(el) : 0;
        if (idx > 0) list.setAttribute('start', String(base + idx));
      }
      list.appendChild(src);
      wrap.appendChild(list);
    } else {
      wrap.appendChild(src);
    }
    stripThinking(wrap);
    const mathMap = prepareMath(wrap);
    stripNoise(wrap);
    const blocks = await fixMath(convertBlocks(wrap, mathMap, [], {}));
    const cleaned = NS.cleanBlocks(blocks);
    return cleaned.length ? { blocks: cleaned } : null;
  };

  /** 只取某一条回答里第 from..to 块（用于「自由选择」） */
  NS.modelFromRange = async function (root, from, to) {
    if (!root) return null;
    const clone = root.cloneNode(true);
    const els = blockEls(clone);
    els.forEach((el, i) => {
      if (i < from || i > to) el.remove();
    });
    stripThinking(clone);
    const mathMap = prepareMath(clone);
    stripNoise(clone);

    const blocks = await fixMath(convertBlocks(clone, mathMap, [], {}));
    const cleaned = NS.cleanBlocks(blocks);
    return cleaned.length ? { blocks: cleaned } : null;
  };

  /** 跨多条回答选范围：groups = [{root, from, to}]，按顺序拼起来 */
  NS.modelFromBlocks = async function (groups) {
    const out = [];
    for (const g of groups || []) {
      const m = await NS.modelFromRange(g.root, g.from, g.to);
      if (m) out.push(...m.blocks);
    }
    return out.length ? { blocks: out } : null;
  };

  /** 页面上所有「回答」根元素，按文档顺序，去掉嵌套和不可见的 */
  /** 类名带 think 的容器可能是整个对话区：只有它内部不含别的「回答标记」时才当思考面板 */
  function isThinkSafe(box) {
    try {
      return !!box.querySelector('[data-message-author-role], [data-role], [data-message-id]');
    } catch (e) {
      return true;
    }
  }

  NS.answerRoots = function () {
    const site = siteOf(location);
    const sel = (site && site.answer) || GENERIC_ANSWER;
    let list;
    try {
      list = Array.from(document.querySelectorAll(sel));
    } catch (e) {
      return [];
    }
    const out = [];
    for (const el of list) {
      if (inChrome(el)) continue;
      if (!el.getClientRects().length) continue;
      if (isAppShell(el)) continue;                  // 整页 / 整个对话区不是一条回答
      if (out.some((o) => o.contains(el))) continue;
      if ((el.textContent || '').trim().length < 8) continue;
      if (messageRole(el) === 'user') continue;      // 自己提的问题不算「回答」
      if (inThink(el)) continue;                     // 思考过程连框都不给
      /* 抬头后面紧跟着的那块是思考正文，不是回答 —— 类名全是哈希的站点靠这一条
         （它们的思考正文往往也挂着 .markdown，只按类名会被当成一条回答）。 */
      if (afterThinkHead(document.body, el)) continue;
      if (userTurnOf(el)) continue;                  // 右侧气泡（没有角色标记的站点）
      /* 自己那一轮：站点给了用户气泡选择器就按它认。有的站点（DeepSeek）提问和回答
         都是同一个 .ds-message，区别只在里面装的是用户气泡还是正文容器。 */
      if (site && site.user) {
        try {
          if (el.matches(site.user)) continue;
          if (el.querySelector(site.user)
              && !(site.content && el.querySelector(site.content))) continue;
        } catch (e) { /* 选择器不合法就算了 */ }
      }
      // 思考面板里的 markdown 不算「回答」：有些站点把思考过程也写成 .markdown，
      // 认成回答的话，「全文」会框到思考内容上去
      try {
        const box = el.closest(THINK_SEL);
        if (box && box !== el && !isThinkSafe(box)) continue;
      } catch (e) { /* 选择器不合法就算了 */ }
      out.push(el);
    }
    return out;
  };

  NS.blockEls = blockEls;

  /** 整个对话：用户提问当引用，回答按正文 */
  NS.conversationModel = async function () {
    const site = siteOf(location);
    const roots = [];
    const answerSel = (site && site.answer) || GENERIC_ANSWER;

    const convRoot = document.querySelector('main') || document.body;
    const seen = new Set();

    // 按文档顺序收集「回答」和「提问」
    const userSel = (site && site.user) || '[data-message-author-role="user"]';
    const candidates = Array.from(convRoot.querySelectorAll(answerSel + ',' + userSel));
    for (const el of candidates) {
      if (seen.has(el)) continue;
      if (inChrome(el)) continue;              // 旁栏里的「会话摘要」不算
      // 嵌套的情况只保留最外层
      let skip = false;
      for (const s of seen) {
        if (s.contains(el)) { skip = true; break; }
      }
      if (skip) continue;
      seen.add(el);
      roots.push(el);
    }

    if (!roots.length) {
      const single = await NS.modelFrom(convRoot, {});
      return single;
    }

    let blocks = [];
    for (const el of roots) {
      const isUser = messageRole(el) === 'user'
        || el.matches(userSel);
      const m = await NS.modelFrom(contentOf(el) || el, {});
      if (!m) continue;
      if (isUser) {
        m.blocks.forEach((b) => {
          if (b.t === 'p') b.q = 1;
          else if (b.t === 'list') b.items.forEach((it) => { it.q = 1; });
        });
      }
      blocks.push(...m.blocks);
    }
    blocks = await fixMath(blocks);
    const cleaned = NS.cleanBlocks(blocks);
    return cleaned.length ? { blocks: cleaned } : null;
  };

  NS.findAnswerRoot = findAnswerRoot;
  NS.findBlockRoot = findBlockRoot;
  NS.blockFrom = blockFrom;
  NS.anchorOf = anchorOf;
  NS.blockAtPoint = blockAtPoint;
  NS.answerAtPoint = answerAtPoint;
  NS.commonBox = commonBox;
  NS.indexAmong = indexAmong;
  NS.inChrome = inChrome;
  NS.contentOf = contentOf;
  NS.messageRole = messageRole;
  NS.refreshThink = refreshThink;
  NS.inThink = inThink;
  NS.thinkHeaderText = thinkHeaderText;
  NS.pickLatex = pickLatex;
  NS.cleanMathML = cleanMathML;
  NS._latexToMathML = latexToMathML;
  NS._siteOf = siteOf;
  NS._stripThinking = stripThinking;
})();
