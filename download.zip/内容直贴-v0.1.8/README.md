# 内容直贴 · Paste2Doc

在 AI 对话页面打开侧边栏，选一种方式，在页面上点一下（或点两下），切到 WPS 文字或 Word，
`Ctrl+V` —— 文档已经在里面，而且已经排好版。页面上不挂任何按钮。

判据只有一条：**粘完之后一个字都不用调。**

## 装

1. 打开 `chrome://extensions`（Edge 是 `edge://extensions`），打开右上角「开发者模式」。
2. 点「加载已解压的扩展程序」，选中本文件夹。
3. 双击 `host/安装本地组件.bat`。它把本地组件注册到当前用户下，不需要管理员权限。
4. 回到扩展页点一下「重新加载」，打开任意 AI 页面即可。

第 3 步本机要是没有 Python 3，安装程序会先问你要从哪个源下载（华为云 / npmmirror / 官方），
然后带进度条下个官方安装包装好，再继续注册。不装本地组件也能用，但只能复制纯文本。

侧边栏右上角显示「未安装」时，下面会出现一块卡片，里面有个「下载本地组件」按钮 ——
点一下直接把本地组件包下载下来（不跳转、不开新标签页），解压双击安装程序就行。
这正是发给同学以后他们唯一的入口，所以那个地址必须国内能开（见「分发与上架」）。

装完先双击 `host\自检.bat`：它检查本地组件并在剪贴板里放一份自检样例，粘到 WPS 里
一眼就能看出是不是通的。完整的分层自测步骤见 `自测清单.md`。

## 用

入口只有一个：工具栏图标打开的侧边栏。**默认是关的** —— 打开侧边栏点「开始使用」才接管鼠标，
按钮随即变成「关闭扩展」，再点一下就退出。页面上不挂任何按钮。

关着的时候页面完全不受影响；开着的时候只有指到回答正文的点击会被接管（点了就复制），
其它点击照常 —— 左侧历史、输入框、页面自己的按钮都能正常用。

| 怎么做 | 结果 |
| --- | --- |
| 侧边栏「开始使用」→「全文」→ 在这条回答的任意位置点一下 | 整条回答，排好版；思考过程不会带进来 |
| 「单段」→ 页面上点一块 | 只要指到的那一块：一个段落、一条分点、一张表、一个公式 |
| 「区间」→ 页面上点两下 | 第一下开头、第二下结尾，点完立刻进剪贴板，只出中间那几块 |
| 「只复制纯文本」开关 | 上面三种都只出文字，不带格式 |
| 侧边栏「关闭扩展」（或按 `Esc`） | 页面完全不响应，也不挂高亮框 |

三个模式各管一层，互不越界，这是它们的区别所在：

- **全文**：蓝框永远是整条回答。指在段落上、指在段与段之间的空白、指在这条回答的边距上，
  框都不变 —— 不用瞄准，落在这一条里点一下就完事。消息底部那排「复制 / 重试 / 点赞 / 朗读 /
  转发」不算正文：指上去不画框，也不会被复制。
  **页面框架也不算正文**：顶栏（会话标题、分享按钮）、输入框、输入框外面的空白、
  页面左右的空白、底部「内容由 AI 生成…」那一行，一律不画框 —— 一条回答里绝不会装着
  输入框或者第二条消息，这条判据一卡，就不会再把整页当成「一条回答」。
- **单段 / 区间**：蓝框永远只是一块（标题、段落、一条分点、表格、代码、公式各算一块）。
  分点列表按「条」切，点第二条就只复制第二条。
  **指在空白上什么都不框** —— 段与段之间的缝、容器边距都不猜，不拿「最近的一块」凑数。

**思考过程和自己提的问题**既不画框也不复制：指上去什么都不发生，连高亮都没有。
思考区三种认法，命中一种就算：类名（`.ds-think-content` 这类）、那行抬头
（「已深度思考（用时 1 分 12 秒）」/「Thought for 12s」）、以及「抬头下面紧跟着的那一块」。
抬头认的是**整块文字**，所以正文里「思考这件事…」这种句子不会被误删；
判归属用 `closest` 往上找，**不限层数**，埋多深都算。自己的提问按角色标记认，
没有标记的站点（例如 DeepSeek）按「贴着右边、比正文窄的气泡」这个形状认。

圈住的范围和复制出去的范围来自同一份块列表、同一个下标，看到多大就复制多大。

**复制完不会退出**：蓝框留在原地，可以接着指下一条、下一块，连着复制好几条不用回侧边栏。
左边历史栏、页脚、输入框这些地方不算正文，也不会被圈进来。

复制完页面上会闪一句「已复制：结论先行」这种预览 —— 复制到的和你以为的不一样时，一眼就能
看出来，不用粘进 WPS 才发现。

## 默认排版

不做模板，不预设风格，只按中文文档的默认值：

- 中文宋体，西文 Times New Roman，五号字（10.5 磅），单倍行距
- 段落靠首行缩进两字区分，不插空行
- 标题用文档自带的「标题 1–6」样式，不是加粗大字
- 列表是真正的自动编号（`1.` / `(1)` / `•`），回车能接着编
- 表格是真表格（首行加粗、浅灰底纹、有框线）
- 公式是可双击编辑的原生公式，不是图片，也不是 LaTeX 源码
- 模型的思考过程（「已深度思考（用时 12 秒）」那一块）不进文档，只留回答正文

这套排版是**默认**，侧边栏「输出排版」里可以切到「保留原格式」—— 那时网页怎么写就怎么粘，
加粗、斜体、颜色、链接的蓝字下划线都留着。字号、行距、是否首行缩进也能改，改完下一次复制生效。

「统一排版」做的事：在样式层把字体字号行距定死，再把网页带过来的行内装饰（加粗、斜体、
删除线、蓝字下划线）清掉。保留下来的只有结构 —— 标题级别、自动编号、表格、公式、代码块。

## 支持的站点

ChatGPT、Claude、Gemini、DeepSeek、Kimi、豆包、腾讯元宝、通义千问、智谱清言、
Perplexity、Copilot、Grok、Poe、Mistral。其它站点走通用规则（找 `.markdown` /
`.prose` / `data-message-author-role` 这类标记）。认不出这是回答区时，用侧边栏的
「单段」或「区间」直接圈 —— 那条路不依赖站点结构。

## 明确不做

- 不做 PDF 导出
- 不渲染图片和流程图（图注当普通段落保留）
- 不改写、不润色、不摘要
- 不接管整篇文档的排版 —— 只负责把粘进来的这一段排对

## 两条复制路径

WPS 和 Word 认的格式不一样，所以同一份内容写两份：

- **WPS**：剪贴板里放 `Kingsoft WPS 9.0 Format`，里面装一个 docx 包，WPS 从中取 OMML 生成原生公式
- **Word**：放 `Rich Text Format`，公式走 Word 2007+ 的 `\mmath` 数学控制字

两份都在剪贴板里，用户不需要知道自己用的是哪个软件。

## 文件

```
manifest.json          扩展清单（MV3）
background.js          本地组件通信 · 侧边栏动作转发
content/model.js       文档模型、纯文本降级
content/extract.js     网页 -> 模型（含公式、表格、代码、列表）
content/ui.js          三种点选 · 蓝框高亮 · 复制流程
panel/                 侧边栏
lib/katex.min.js       兜底渲染公式用，按需注入
host/                  本地组件（Python，无第三方依赖）
  paste2doc_host.py    Native Messaging 入口 + 写剪贴板
  p2d_docx.py          模型 -> docx（WPS 走这条）
  p2d_rtf.py           模型 -> RTF（Word 走这条）
  p2d_math.py          MathML -> OMML -> RTF 公式
  install_host.py      挑 Python、自检、写清单、注册到注册表
  安装本地组件.bat     安装入口（没有 Python 时给镜像菜单、下载、静默装好）
  卸载本地组件.bat     一键卸载（纯 reg.exe，不依赖 Python）
site/                  下载站（index / host / privacy / 两个 zip）
tools/stage_hosted.py  把两个下载站拼成一个目录，发给内置托管
test/                  端到端测试
```

## 测试

```
host\自检.bat                 # 双击：检查本地组件 + 往剪贴板放一份自检样例
test\打开演示页.bat           # 双击：本地起一个演示页，不用登任何 AI 站点
```

改代码之后跑的回归（需要 Edge + WPS 或 Word）：

```
python test/extract_test.py   # 脏 HTML 的提取（li 套 p、div 当段落、只剩 LaTeX 的公式）
python test/browser_test.py   # 真扩展：点选 -> 剪贴板 -> WPS 粘贴检查
python test/pick_test.py      # 全文/单段/区间 + 锚点一致性 + 开关
python test/ds_test.py        # DeepSeek 式结构：思考/提问不框、页面按钮能点、分点按条切
python test/think_test.py     # 思考区最难认的结构：哈希类名 / 深嵌套 / 比三屏还长
python test/frag_test.py      # 一条回答被拆成碎片时，全文不缩成一段
python test/panel_path_test.py # 侧边栏按钮 -> 后台 -> 页面 这条链路
python test/latex_test.py     # KaTeX 按需注入
```

后三个会真的去粘贴、导 PDF，产物在 `paste2doc-lab/`。逐项的人工核对清单在 `自测清单.md`。

注意：`pick_test` / `browser_test` / `ds_test` / `think_test` / `latex_test` 开头都会调一次
`host/install_host.py`（它们要真写剪贴板），所以**跑完回归等于把本地组件装上了**。
想退回「未安装」的状态做下载测试，双击 `host/卸载本地组件.bat` 输入 Y 就行。

## 分发与上架

| 用途 | 地址 |
| --- | --- |
| 下载页（给人看的那种） | <https://xuanyuan121.github.io/paste2doc/> |
| 只下载本地组件 | <https://xuanyuan121.github.io/paste2doc/host.html> |
| 安装包直链 | <https://xuanyuan121.github.io/paste2doc/download.zip> |
| 本地组件直链（国内可开） | <https://formula2word.app.workbuddy.host/paste2doc/download-host.zip?sharecode=FY5JRY7EVJ> |
| 源码 / 问题反馈 | <https://github.com/xuanyuan121/paste2doc> |
| 备用下载（GitHub Release） | <https://github.com/xuanyuan121/paste2doc/releases/latest> |
| 隐私政策 | <https://xuanyuan121.github.io/paste2doc/privacy.html> |

**内置托管只有一个发布位。** 实测：从这个账号发任何目录，都会覆盖同一个应用
（`wbapp_CuiKfwq02kLchO2GG4DWa0`），并把 `.wbapp_*.genie` 的 localDir 改指过去 ——
所以「公式直贴」的下载页和「内容直贴」的下载页不能各占一个位置。
现在的做法是**一个目录装两个产品**：

```
hosted-site/                 <- 发这一个目录（tools/stage_hosted.py 拼出来）
  index.html privacy.html download helper     公式直贴（根目录，链接不变）
  paste2doc/                                  内容直贴（/paste2doc/ 子路径）
```

站内链接会自动带上 `?sharecode=`（两个模板末尾那段小脚本），所以子目录里的
`download.zip`、`host.html` 点开也对。

三个包，各有各的用途，别混：

```
内容直贴-v<版本>.zip            发给同学的完整包：扩展 + 本地组件 + 使用说明
                                （python 打包.py）
内容直贴-本地组件-v<版本>.zip   只装本地组件的那一包：安装程序 + 卸载 + 说明
                                （python 打包本地组件.py）
dist/paste2doc-extension-<版本>.zip   上传商店的包：只有扩展本体，无 key、无脚本
                                （python 打包上架.py，自带合规自检）
site/download.zip                下载页上那个文件，就是完整包的一份拷贝
site/download-host.zip           侧边栏按钮下的那个文件，就是组件包的一份拷贝
```

改完代码要同步线上时：

```
python 打包.py && python 打包上架.py
python 打包本地组件.py
python tools/store_shots.py        # 截图（真扩展跑出来的）
python tools/build_site.py         # 重建下载页（index.html / host.html / 两个 zip）
python deploy_github.py            # 更新仓库文件 + Release 附件
python deploy_pages.py             # 更新 GitHub Pages
python tools/stage_hosted.py       # 拼 hosted-site/，再用「发布为应用」发这个目录
```

上架逐项填写稿（含可直接粘贴的中英文案、权限理由、审核说明、检查清单）在
`SUBMIT-EDGE.md`；商店素材在 `store/`。
