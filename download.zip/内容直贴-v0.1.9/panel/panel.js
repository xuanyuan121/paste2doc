/* 内容直贴 · 侧边栏
 *
 * 版面从上到下就是用的顺序：
 *   开始使用   —— 唯一的主按钮，也是总开关。默认关着：开着的时候页面上的点击会被接住，
 *                所以必须由人明确打开、明确关掉，不能一进页面就自动接管。
 *   复制方式   —— 全文 / 单段 / 区间；开着之后切换模式立刻生效
 *   输出排版   —— 统一排版 / 保留原格式 + 缩进 / 字号行距 / 纯文本
 *   本地组件   —— 只在没装的时候出现：一个按钮直接把安装包下下来
 *
 * 说明文字只留一行（排版规则），其余靠控件自己说清楚。
 */
(() => {
  'use strict';
  const DEFAULTS = {
    plain: false, mode: 'all',
    size: 21, line: 240, indent: true, unify: true
  };

  const $ = (id) => document.getElementById(id);
  const MODES = ['all', 'para', 'range'];

  const FMT_NOTE = {
    unify: '宋体 / Times New Roman · 五号 · 单倍行距 · 首行缩进',
    raw: '按网页原样保留字体、字号与颜色'
  };

  let state = Object.assign({}, DEFAULTS);
  let active = false;          // 页面当前是否在点选状态

  function normMode(m) {
    return MODES.indexOf(m) >= 0 ? m : 'all';
  }

  function renderRun() {
    const b = $('runBtn');
    b.querySelector('.run-txt').textContent = active ? '关闭扩展' : '开始使用';
    b.classList.toggle('on', active);
    b.setAttribute('aria-pressed', active ? 'true' : 'false');
  }

  function renderMode(mode) {
    document.querySelectorAll('#modeSeg .seg-btn').forEach((b) => {
      const on = b.dataset.mode === mode;
      b.classList.toggle('on', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
    });
  }

  function renderFmt(unify) {
    document.querySelectorAll('#fmtSeg .seg-btn').forEach((b) => {
      const on = (b.dataset.fmt === 'unify') === !!unify;
      b.classList.toggle('on', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    $('fmtNote').textContent = unify ? FMT_NOTE.unify : FMT_NOTE.raw;
  }

  /** 开关之间的联动：纯文本时排版设置无意义；保留原格式时字号行距缩进也管不着 */
  function syncDisabled() {
    const plain = !!state.plain;
    const unify = !!state.unify;

    document.querySelectorAll('#fmtSeg .seg-btn').forEach((b) => { b.disabled = plain; });

    const detailOff = plain || !unify;
    ['indent', 'size', 'line'].forEach((id) => { $(id).disabled = detailOff; });
    $('moreBox').style.opacity = detailOff ? '.5' : '';
    $('indent').parentElement.style.cursor = detailOff ? 'default' : 'pointer';
    $('fmtNote').style.opacity = plain ? '.55' : '';
  }

  function render(s) {
    state = s;
    ['plain', 'indent'].forEach((k) => { $(k).checked = !!s[k]; });
    $('size').value = String(s.size);
    $('line').value = String(s.line);
    renderMode(normMode(s.mode));
    renderFmt(!!s.unify);
    syncDisabled();
    renderRun();
  }

  chrome.storage.sync.get(DEFAULTS, (s) => render(Object.assign({}, DEFAULTS, s)));

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;
    const patch = {};
    for (const k in changes) patch[k] = changes[k].newValue;
    chrome.storage.sync.get(DEFAULTS, (s) => render(Object.assign({}, DEFAULTS, s, patch)));
  });

  ['plain', 'indent'].forEach((k) => {
    $(k).addEventListener('change', (e) => {
      state[k] = e.target.checked;
      chrome.storage.sync.set({ [k]: e.target.checked });
      if (k === 'plain') syncDisabled();
    });
  });

  ['size', 'line'].forEach((k) => {
    $(k).addEventListener('change', (e) => {
      chrome.storage.sync.set({ [k]: Number(e.target.value) });
    });
  });

  /* ------------------------------------------------------------ 动作 */

  let hintTimer = 0;

  /** 只在出错时用：平时这一行不存在，成功与否看主按钮自己的状态 */
  function showError(text) {
    const el = $('runHint');
    clearTimeout(hintTimer);
    if (!text) { el.hidden = true; return; }
    el.textContent = text;
    el.hidden = false;
    hintTimer = setTimeout(() => { el.hidden = true; }, 6000);
  }

  function send(action, mode) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'panel-action', action, mode }, (resp) => {
        const err = chrome.runtime.lastError;
        if (err) { resolve({ ok: false, error: '扩展刚重载过，重开一下侧边栏' }); return; }
        resolve(resp || { ok: false, error: '没有回应' });
      });
    });
  }

  /** 页面上的状态才是准的：Esc 关掉、刷新页面之后，按钮得跟着变回来 */
  async function syncState() {
    const r = await send('state');
    const on = !!(r && r.ok && r.on);
    if (on !== active) { active = on; renderRun(); }
    if (on && r.mode && r.mode !== state.mode) {
      state.mode = normMode(r.mode);
      renderMode(state.mode);
    }
  }

  $('runBtn').addEventListener('click', async () => {
    const want = !active;
    if (!want) {
      await send('stop');
      active = false;
      renderRun();
      showError('');
      return;
    }
    const r = await send('start', state.mode);
    if (r && r.ok) {
      active = true;
      renderRun();
      showError('');
    } else {
      active = false;
      renderRun();
      showError((r && r.error) || '未知原因');
    }
  });

  document.querySelectorAll('#modeSeg .seg-btn').forEach((b) => {
    b.addEventListener('click', async () => {
      const mode = normMode(b.dataset.mode);
      state.mode = mode;
      chrome.storage.sync.set({ mode });
      renderMode(mode);
      if (!active) return;        // 关着的时候只记住选择，不去动页面 —— 默认不接管点击
      const r = await send('start', mode);
      if (!r || !r.ok) showError((r && r.error) || '切换失败');
    });
  });

  document.querySelectorAll('#fmtSeg .seg-btn').forEach((b) => {
    b.addEventListener('click', () => {
      if (b.disabled) return;
      const unify = b.dataset.fmt === 'unify';
      state.unify = unify;
      chrome.storage.sync.set({ unify });
      renderFmt(unify);
      syncDisabled();
    });
  });

  /* 状态轮询：侧边栏不知道页面里按了 Esc，也看不到页面被刷新。
     一秒多问一次很便宜，换来按钮和页面永远说的是同一件事。 */
  syncState();
  setInterval(syncState, 1200);
  window.addEventListener('focus', syncState);

  /* -------------------------------------------------------- 本地组件 */

  const PKG_NAME = '内容直贴-本地组件-v' + chrome.runtime.getManifest().version + '.zip';
  /* 两个地址放的是同一个包：
   *   1. 内置托管 —— 国内直连，走它；末尾的分享码是托管那边要求带的
   *   2. GitHub Pages —— 兜底，托管抽风或者分享码换了还能下 */
  const PKG_MIRRORS = [
    'https://formula2word.app.workbuddy.host/paste2doc/download-host.zip?sharecode=FY5JRY7EVJ',
    'https://xuanyuan121.github.io/paste2doc/download-host.zip'
  ];

  function setHost(ok, text) {
    const dot = $('hostDot');
    dot.classList.toggle('ok', !!ok);
    dot.classList.toggle('bad', !ok);
    $('hostText').textContent = text;
    $('hostBox').hidden = !!ok;          // 装好了这一整块就消失
  }

  function ping() {
    setHost(false, '检测中…');
    let done = false;
    const timer = setTimeout(() => {
      if (done) return;
      done = true;
      setHost(false, '没连上');
    }, 8000);
    chrome.runtime.sendMessage({ type: 'ping-host' }, (resp) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      const err = chrome.runtime.lastError;
      if (err) { setHost(false, '未安装'); return; }
      if (resp && resp.ok) setHost(true, '已连接');
      else setHost(false, '未安装');
    });
  }

  /* 下载：取回来交给浏览器存盘，不跳转、不开新标签页。
   * 侧边栏关掉也没关系，下载已经在浏览器那边排队了。 */
  function saveBlob(blob, name) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }

  async function grab(url) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 20000);
    try {
      const r = await fetch(url, { cache: 'no-store', signal: ctl.signal });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const buf = await r.arrayBuffer();
      if (buf.byteLength < 10000) throw new Error('文件不完整');
      return new Blob([buf], { type: 'application/zip' });
    } finally {
      clearTimeout(timer);
    }
  }

  function pkgMsg(text, bad) {
    const el = $('dlMsg');
    el.textContent = text;
    el.classList.toggle('bad', !!bad);
    el.hidden = false;
  }

  let downloading = false;

  $('dlBtn').addEventListener('click', async () => {
    if (downloading) return;
    downloading = true;
    const btn = $('dlBtn');
    const txt = $('dlTxt');
    const old = txt.textContent;
    btn.disabled = true;
    txt.textContent = '正在下载…';
    $('dlMsg').hidden = true;

    let fail = null;
    for (const url of PKG_MIRRORS) {
      try {
        saveBlob(await grab(url), PKG_NAME);
        fail = null;
        break;
      } catch (e) {
        fail = e;
      }
    }

    downloading = false;
    btn.disabled = false;
    if (!fail) {
      txt.textContent = '重新下载';
      pkgMsg('已存到「下载」文件夹。解压 → 双击 Paste2DocSetup.exe → 下一步到底，'
             + '回来点下面「重新检测」。');
      $('reBtn').classList.add('hot');
    } else {
      txt.textContent = old;
      pkgMsg('下载失败（' + ((fail && fail.message) || '网络不通') +
             '）。换个网络再试，或者到 xuanyuan121.github.io/paste2doc/host.html 手动下。', true);
    }
  });

  $('reBtn').addEventListener('click', ping);
  $('hostChip').addEventListener('click', ping);
  ping();
})();
