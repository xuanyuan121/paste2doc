/* 三种点选方式 · 复制流程
 *
 * 入口只有一个：侧边栏的「开始使用」。点它页面才进点选状态，
 * 再点一次（此时写的是「关闭扩展」）就退出。默认是关的 ——
 * 打开一个网页就自动接管鼠标，会让人连页面上的按钮都点不动。
 *
 *   全文  —— 不管指在这条回答的哪里（正文、段间空白、边距），框的永远是整条回答
 *   单段  —— 永远只框一块（一个段落 / 一张表 / 一条分点），空白处不判定
 *   区间  —— 点第一下定起点，点第二下定终点，第二下即复制
 *
 * 三条路径都从 NS 那边的几何判定取块（answerAtPoint / blockAtPoint），
 * 高亮框和进剪贴板的内容用同一份块列表与下标，不存在「框住小段、复制出大段」。
 */
(() => {
  'use strict';
  const NS = window.__p2d;
  if (!NS || NS.uiReady) return;
  NS.uiReady = true;

  const DEFAULTS = {
    plain: false, mode: 'all',
    size: 21, line: 240, indent: true, unify: true
  };
  let settings = Object.assign({}, DEFAULTS);

  let hostEl = null;
  let shadow = null;
  let toastEl = null;
  let fbEl = null;
  let marksEl = null;
  let toastTimer = 0;

  /* 点选状态
   *   all   -> pick.root：指着的整条回答
   *   para  -> pick.hov：指着的块
   *   range -> pick.a 起点块，pick.hov 鼠标指着的块
   * 块锚点 = { root, content, els, i, el }：
   *   content 是这条回答的正文容器，els 是它的块列表，
   *   i 是 el 在 els 里的下标 —— 复制就按这个下标切片，不会跑偏。
   */
  const pick = { on: false, mode: 'range', a: null, hov: null, root: null, busy: false, pt: null };

  const CSS = `
    :host { all: initial; }
    .toast {
      position: fixed; left: 50%; bottom: 40px; transform: translateX(-50%) translateY(8px);
      z-index: 2147483647; max-width: 80vw;
      padding: 7px 13px; border-radius: 8px;
      font: 500 12.5px/1.4 -apple-system, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
      color: #fff; background: #1b1b1f; box-shadow: 0 4px 16px rgba(0,0,0,.28);
      opacity: 0; pointer-events: none; transition: opacity .14s ease, transform .14s ease;
    }
    .toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }
    .toast.err { background: #a32d2d; }
    .fb {
      position: fixed; right: 16px; bottom: 16px; width: 340px; max-width: calc(100vw - 32px);
      padding: 12px; background: #fff; border: 1px solid rgba(0,0,0,.14);
      border-radius: 10px; box-shadow: 0 8px 28px rgba(0,0,0,.18);
      display: none; z-index: 2147483647;
      font: 400 12px/1.5 -apple-system, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
      color: #1b1b1f;
    }
    .fb.show { display: block; }
    .fb .fb-t { font-weight: 500; margin: 0 0 6px; }
    .fb .fb-d { margin: 0 0 8px; color: #6b6b73; font-size: 11px; }
    .fb textarea {
      width: 100%; height: 76px; box-sizing: border-box; resize: vertical;
      padding: 6px; border: 1px solid rgba(0,0,0,.14); border-radius: 6px;
      font: 11px/1.45 ui-monospace, Consolas, monospace; color: #1b1b1f;
    }
    .fb .fb-close {
      position: absolute; top: 8px; right: 10px; border: 0; background: none;
      font-size: 15px; line-height: 1; color: #888780; cursor: pointer; padding: 2px;
    }

    /* 将要复制的范围 */
    .mark {
      position: fixed; display: block; pointer-events: none; z-index: 2147483645;
      background: rgba(24,95,165,.10); border: 1px solid rgba(24,95,165,.35);
      border-radius: 3px; box-sizing: border-box;
    }
    .mark.hover { background: rgba(24,95,165,.16); border-color: rgba(24,95,165,.75); }
    .mark.act { background: rgba(24,95,165,.18); border-color: rgba(24,95,165,.85); }
    /* 整条回答用更淡的底、更粗的边，看得出是「整块」而不是某一段 */
    .mark.big { background: rgba(24,95,165,.07); border: 2px solid rgba(24,95,165,.55); border-radius: 8px; }
    .mark.big.hover { background: rgba(24,95,165,.10); border-color: rgba(24,95,165,.75); }
  `;

  function ensureUI() {
    if (hostEl) return;
    hostEl = document.createElement('div');
    hostEl.setAttribute('data-p2d', 'host');
    hostEl.style.cssText = 'all:initial;position:fixed;left:0;top:0;width:0;height:0;z-index:2147483647;';

    shadow = hostEl.attachShadow({ mode: 'open' });
    try {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(CSS);
      shadow.adoptedStyleSheets = [sheet];
    } catch (e) {
      const style = document.createElement('style');
      style.textContent = CSS;
      shadow.appendChild(style);
    }

    marksEl = document.createElement('div');
    shadow.appendChild(marksEl);

    toastEl = document.createElement('div');
    toastEl.className = 'toast';
    shadow.appendChild(toastEl);

    fbEl = document.createElement('div');
    fbEl.className = 'fb';
    fbEl.innerHTML = '<button class="fb-close" type="button" title="关闭">\u00d7</button>'
      + '<p class="fb-t">自动复制被浏览器拦住了</p>'
      + '<p class="fb-d">下面这段已选中，按 Ctrl+C 手动复制，再贴到 WPS / Word 里。</p>'
      + '<textarea readonly spellcheck="false"></textarea>';
    shadow.appendChild(fbEl);
    fbEl.querySelector('.fb-close').addEventListener('click', () => fbEl.classList.remove('show'));

    (document.body || document.documentElement).appendChild(hostEl);
  }

  function toast(msg, isError, ms) {
    ensureUI();
    toastEl.textContent = msg;
    toastEl.classList.toggle('err', !!isError);
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), ms || 1400);
  }

  function showFallback(text) {
    ensureUI();
    const ta = fbEl.querySelector('textarea');
    ta.value = text;
    fbEl.classList.add('show');
    ta.focus();
    ta.select();
  }

  /* ------------------------------------------------------------ 剪贴板 */

  function legacyCopyText(text) {
    let lastErr = 'execCommand 未成功';
    const ta = document.createElement('textarea');
    ta.setAttribute('data-p2d', 'clip');
    ta.value = text;
    ta.style.cssText = 'position:fixed;left:-99999px;top:0;width:1px;height:1px;opacity:0;';
    (document.body || document.documentElement).appendChild(ta);
    const sel = window.getSelection();
    const saved = sel.rangeCount ? sel.getRangeAt(0) : null;
    try {
      ta.focus();
      ta.select();
      const ok = document.execCommand('copy');
      if (!ok) lastErr = 'execCommand 返回 false';
      return { ok: !!ok, error: ok ? null : lastErr };
    } catch (e) {
      return { ok: false, error: 'execCommand 抛错：' + (e && e.name) };
    } finally {
      ta.remove();
      if (saved) {
        sel.removeAllRanges();
        sel.addRange(saved);
      }
    }
  }

  async function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      try {
        await navigator.clipboard.writeText(text);
        return { ok: true };
      } catch (e) { /* 被拒，走兜底 */ }
    }
    return legacyCopyText(text);
  }

  /* ------------------------------------------------------- 与后台通信 */

  function sendOnce(payload) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(payload, (resp) => {
          const err = chrome.runtime.lastError;
          if (err) { resolve({ ok: false, error: err.message || '', failed: true }); return; }
          resolve(resp || { ok: false, error: '后台没有回应' });
        });
      } catch (e) {
        resolve({ ok: false, error: String(e), failed: true });
      }
    });
  }

  function isTransient(msg) {
    return /Receiving end does not exist|Could not establish connection|message port closed/i
      .test(String(msg || ''));
  }

  async function sendToBackground(payload) {
    let r = await sendOnce(payload);
    if (r.failed && isTransient(r.error)) {
      await new Promise((res) => setTimeout(res, 250));
      r = await sendOnce(payload);
    }
    if (r.failed) {
      const gone = /context invalidated/i.test(String(r.error));
      return { ok: false, error: r.error, noHost: !gone, stale: gone };
    }
    return r;
  }

  /* ------------------------------------------------------------ 复制 */

  function buildModel(blocks) {
    return {
      version: 1,
      opt: {
        size: settings.size, line: settings.line, indent: settings.indent,
        unify: settings.unify !== false
      },
      blocks
    };
  }

  /** 复制成功后给一句「复制了哪块」，让对象和预期对不上时一眼看得出来 */
  function previewOf(blocks) {
    for (const b of blocks) {
      if (b.t === 'h' || b.t === 'p') {
        const s = NS.toPlain([b]).replace(/\s+/g, ' ').trim();
        if (s) return s.length > 14 ? s.slice(0, 14) + '…' : s;
      }
      if (b.t === 'list' && b.items && b.items.length) {
        const s = NS.toPlain([{ t: 'p', inl: b.items[0].inl }]).trim();
        if (s) return s.length > 14 ? s.slice(0, 14) + '…' : s;
      }
      if (b.t === 'code') return '一段代码';
      if (b.t === 'table') return '一张表格';
      if (b.t === 'math') return '一个公式';
    }
    return '';
  }

  /** 返回 { ok, error, preview }，让侧边栏能把真实结果说清楚 */
  async function copyModel(model, mode) {
    if (!model || !model.blocks || !model.blocks.length) {
      toast('这里没有可复制的内容', true);
      return { ok: false, error: '这里没有可复制的内容' };
    }
    /* 留一份「上次复制了什么」的痕迹，出问题时能在控制台一眼看出
       复制的是哪一块、几个块、走的哪种模式 */
    NS._last = {
      mode: mode || 'doc',
      blocks: model.blocks.length,
      types: model.blocks.map((b) => b.t).join(','),
      at: Date.now()
    };
    const plain = NS.toPlain(model.blocks);
    const preview = previewOf(model.blocks);

    if (mode === 'plain') {
      const r = await copyText(plain);
      if (r.ok) { toast(preview ? ('已复制：' + preview) : '已复制纯文本'); return { ok: true, preview }; }
      toast('复制被拦住了：' + r.error, true);
      showFallback(plain);
      return { ok: false, error: r.error || '复制被拦住' };
    }

    const resp = await sendToBackground({
      type: 'copy-doc',
      model: buildModel(model.blocks),
      plain
    });

    if (resp && resp.ok) {
      toast(preview ? ('已复制：' + preview) : '已复制 · 到 WPS / Word 里 Ctrl+V');
      return { ok: true, preview };
    }

    // 本地组件没装 / 没连上：至少把文字给出去，别让人白点一下
    const r = await copyText(plain);
    if (!r.ok) {
      toast('复制被拦住了：' + (r.error || '未知原因'), true);
      showFallback(plain);
      return { ok: false, error: r.error || '复制被拦住' };
    }
    if (resp && resp.stale) {
      toast('扩展刚更新过，按 F5 刷新本页后再复制', true, 2600);
      return { ok: false, error: '扩展刚更新过，按 F5 刷新本页' };
    }
    toast('本地组件没连上，这次只复制了纯文本', true, 3000);
    return { ok: true, preview, plainOnly: true };
  }

  /** 没有点选上下文时（例如工具栏菜单直接调用）：取屏上占得最多的那条回答 */
  function targetAnswer() {
    const roots = NS.answerRoots();
    if (!roots.length) return null;
    const vh = window.innerHeight;
    const mid = vh / 2;
    let best = null;
    let bestArea = 0;
    let bestD = Infinity;
    for (const r of roots) {
      const b = r.getBoundingClientRect();
      if (b.bottom < 40 || b.top > vh - 40) continue;
      const area = Math.min(b.bottom, vh) - Math.max(b.top, 0);
      if (area <= 0) continue;
      const d = Math.min(Math.abs(b.top - mid), Math.abs(b.bottom - mid));
      if (area > bestArea + 4 || (Math.abs(area - bestArea) <= 4 && d < bestD)) {
        bestArea = area;
        bestD = d;
        best = r;
      }
    }
    return best;
  }

  async function copyAnswer(root, mode) {
    if (!root) {
      return { ok: false, error: '这一页没认出回答正文，换个位置再点' };
    }
    const content = NS.contentOf(root) || root;
    const m = await NS.modelFrom(content, {});
    return copyModel(m, mode);
  }

  /* --------------------------------------------------------- 点选 */

  /**
   * 把鼠标位置换成「该模式下的选择对象」。
   *
   * 分模式各走一条路，这是关键：
   *   全文 -> 只认整条回答（answerAtPoint，按矩形判，不爬 DOM）
   *   单段 / 区间 -> 只认块表里的一块（blockAtPoint，空白处取最近的一块）
   * 两个函数都不做「往上收容器」的动作，所以不会在空白处从小段跳成大段。
   */
  function anchorAt(x, y) {
    const under = document.elementFromPoint(x, y);
    if (under && hostEl && (under === hostEl || hostEl.contains(under))) return null;

    if (pick.mode === 'all') {
      const root = NS.answerAtPoint(x, y);
      return root ? { root } : null;
    }
    return NS.blockAtPoint(x, y);
  }

  /**
   * 起点到终点之间的块。同一份块表就直接切片；
   * 跨回答时按文档顺序各取一段（A 到它那条的尾，B 从它那条的头），
   * 不再退到「公共祖先再重数一遍」——那一步正是把旁栏、其他回答卷进来的地方。
   */
  function rangeOf(A, B) {
    if (!A || !B) return null;
    if (A.content === B.content && A.els === B.els) {
      return [{
        content: A.content,
        els: A.els,
        from: Math.min(A.i, B.i),
        to: Math.max(A.i, B.i)
      }];
    }
    let first = A;
    let second = B;
    const pos = A.content.compareDocumentPosition(B.content);
    if (!(pos & Node.DOCUMENT_POSITION_FOLLOWING)) { first = B; second = A; }
    if (first.content === second.content) {
      const els = first.els;
      return [{
        content: first.content,
        els,
        from: Math.min(first.i, second.i),
        to: Math.max(first.i, second.i)
      }];
    }
    return [
      { content: first.content, els: first.els, from: first.i, to: first.els.length - 1 },
      { content: second.content, els: second.els, from: 0, to: second.i }
    ];
  }

  function drawRect(el, cls) {
    if (!el || !el.getBoundingClientRect) return;
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) return;
    const vh = window.innerHeight;
    const top = Math.max(0, r.top);
    const bottom = Math.min(vh, r.bottom);
    if (bottom <= top) return;
    const box = document.createElement('div');
    box.className = 'mark' + (cls ? ' ' + cls : '');
    box.style.left = r.left + 'px';
    box.style.top = top + 'px';
    box.style.width = Math.max(0, r.width) + 'px';
    box.style.height = (bottom - top) + 'px';
    marksEl.appendChild(box);
  }

  function drawPick() {
    if (!pick.on || !marksEl) return;
    while (marksEl.firstChild) marksEl.removeChild(marksEl.firstChild);

    if (pick.mode === 'all') {
      // 画在正文容器上：消息容器往往还包着底部那排
      // 「复制 / 重试 / 点赞 / 朗读 / 转发」按钮，画它就会把按钮一起框进来
      if (pick.root) drawRect(NS.contentOf(pick.root) || pick.root, 'big hover');
      return;
    }
    if (pick.mode === 'para') {
      if (pick.hov) drawRect(pick.hov.el, 'hover');
      return;
    }
    if (!pick.a) {
      if (pick.hov) drawRect(pick.hov.el, 'hover');
      return;
    }
    const segs = rangeOf(pick.a, pick.hov || pick.a);
    if (!segs) { drawRect(pick.a.el, 'act'); return; }
    for (const s of segs) {
      for (let i = s.from; i <= s.to; i++) {
        const el = s.els[i];
        if (!el) continue;
        const isStart = pick.a.content === s.content && i === pick.a.i;
        drawRect(el, isStart ? 'act' : '');
      }
    }
  }

  function onPickMove(e) {
    if (!pick.on || pick.busy) return;
    const path = e.composedPath ? e.composedPath() : [];
    if (hostEl && path.indexOf(hostEl) !== -1) return;

    pick.pt = { x: e.clientX, y: e.clientY };
    const a = anchorAt(e.clientX, e.clientY);
    if (pick.mode === 'all') {
      if ((a && a.root) === pick.root) return;
      pick.root = a ? a.root : null;
    } else {
      if (a && pick.hov && a.el === pick.hov.el
          && a.i === pick.hov.i && a.content === pick.hov.content) return;
      if (!a && !pick.hov) return;
      pick.hov = a;
    }
    drawPick();
  }

  /**
   * 复制完**不退出**点选状态：蓝框原地还在，可以接着指下一条、下一块。
   *
   * 以前这里是复制前 exitPick、复制后就不管了，所以复制一次之后页面上什么反应都没有，
   * 必须到侧边栏切一次模式（等于重新 enterPick）才又能选 —— 这就是
   * 「复制完之后不能接着复制」的原因。
   */
  function resumePick(mode) {
    const pt = pick.pt;
    const r = enterPick(mode);
    if (!r.ok) return;
    // 用最后停过的位置重新算一次，蓝框立刻回来，不用先动一下鼠标
    if (pt) {
      if (pick.mode === 'all') pick.root = NS.answerAtPoint(pt.x, pt.y);
      else pick.hov = NS.blockAtPoint(pt.x, pt.y);
    }
    drawPick();
  }

  async function doCopyAll(root) {
    if (!root) { toast('这里不是回答正文，换个地方点', true); return; }
    const mode = pick.mode;
    pick.busy = true;
    exitPick(false);
    try {
      await copyAnswer(root, settings.plain ? 'plain' : '');
    } catch (err) {
      console.warn('[内容直贴] 提取失败', err);
      toast('提取失败：' + ((err && err.message) || err), true, 2600);
    } finally {
      resumePick(mode);
    }
  }

  async function doCopyBlock(anchor) {
    if (!anchor || !anchor.el) { toast('这一块没法复制，换个地方点', true); return; }
    const mode = pick.mode;
    pick.busy = true;
    exitPick(false);
    try {
      const m = await NS.modelOf(anchor.el);
      await copyModel(m, settings.plain ? 'plain' : '');
    } catch (err) {
      console.warn('[内容直贴] 单块提取失败', err);
      toast('提取失败：' + ((err && err.message) || err), true, 2600);
    } finally {
      resumePick(mode);
    }
  }

  async function doCopyRange(A, B) {
    const segs = rangeOf(A, B);
    const mode = pick.mode;
    pick.busy = true;
    exitPick(false);
    if (!segs) { toast('这一块没法复制', true); resumePick(mode); return; }
    try {
      const m = await NS.modelFromBlocks(
        segs.map((s) => ({ root: s.content, from: s.from, to: s.to })));
      await copyModel(m, settings.plain ? 'plain' : '');
    } catch (err) {
      console.warn('[内容直贴] 选区提取失败', err);
      toast('提取失败：' + ((err && err.message) || err), true, 2600);
    } finally {
      resumePick(mode);
    }
  }

  function onPickClick(e) {
    if (!pick.on) return;
    const path = e.composedPath ? e.composedPath() : [];
    if (hostEl && path.indexOf(hostEl) !== -1) return;
    if (pick.busy) return;

    pick.pt = { x: e.clientX, y: e.clientY };
    const a = anchorAt(e.clientX, e.clientY);
    if (!a) {
      /* 没命中正文（空白、侧边栏历史、输入框、页面自己的按钮）：
         什么都不做，**也不拦这一下**。
         以前这里无条件 preventDefault + stopPropagation，于是开着扩展的时候
         整页的按钮都点不动 —— 左侧历史点不开就是这个原因。 */
      return;
    }

    // 命中正文才接管这一下：这是「点一下 = 复制」的那一下
    e.preventDefault();
    e.stopPropagation();

    if (pick.mode === 'all') { void doCopyAll(a.root); return; }
    if (pick.mode === 'para') { void doCopyBlock(a); return; }

    if (!pick.a) {
      pick.a = a;
      pick.hov = a;
      drawPick();          // 起点就是那个蓝框，不用再弹一条提示挡着正文
      return;
    }
    void doCopyRange(pick.a, a);
  }

  function onPickKey(e) {
    if (!pick.on) return;
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      exitPick(true);
    }
  }

  function layoutPick() {
    if (pick.on) drawPick();
  }

  function enterPick(mode) {
    ensureUI();
    if (!document.body) return { ok: false, error: '页面还没准备好' };
    exitPick(false);

    // 进来先把「哪些是思考区」标一遍：思考内容不画框、也不复制
    if (NS.refreshThink) { try { NS.refreshThink(); } catch (e) { /* 标不出来就算了 */ } }

    pick.on = true;
    pick.mode = (mode === 'all' || mode === 'para') ? mode : 'range';
    pick.a = null;
    pick.hov = null;
    pick.root = null;
    pick.busy = false;

    document.addEventListener('pointermove', onPickMove, true);
    document.addEventListener('click', onPickClick, true);
    document.addEventListener('keydown', onPickKey, true);
    window.addEventListener('scroll', layoutPick, { passive: true, capture: true });
    window.addEventListener('resize', layoutPick, { passive: true });
    return { ok: true, mode: pick.mode };
  }

  function exitPick(silent) {
    const was = pick.on;
    pick.on = false;
    pick.a = null;
    pick.hov = null;
    pick.root = null;
    document.removeEventListener('pointermove', onPickMove, true);
    document.removeEventListener('click', onPickClick, true);
    document.removeEventListener('keydown', onPickKey, true);
    window.removeEventListener('scroll', layoutPick, true);
    window.removeEventListener('resize', layoutPick);
    if (marksEl) marksEl.textContent = '';
    if (was && silent) toast('已取消', false, 900);
  }

  /* ------------------------------------------------------------ 消息 */

  /* 调试用：出问题时在控制台看一眼当前点选状态 */
  NS._pick = pick;
  NS.pickState = () => ({ on: pick.on, mode: pick.mode });

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.type) return;

    if (msg.type === 'p2d-copy-all') {
      copyAnswer(targetAnswer(), settings.plain ? 'plain' : '')
        .then(sendResponse)
        .catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
      return true;
    }

    if (msg.type === 'p2d-copy-conversation') {
      NS.conversationModel()
        .then((m) => (m ? copyModel(m, settings.plain ? 'plain' : '')
          : { ok: false, error: '没找到对话内容' }))
        .then(sendResponse)
        .catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
      return true;
    }

    if (msg.type === 'p2d-start' || msg.type === 'p2d-pick') {
      sendResponse(enterPick(msg.mode));
      return false;
    }

    if (msg.type === 'p2d-stop' || msg.type === 'p2d-cancel-pick') {
      exitPick(true);
      sendResponse({ ok: true, on: false });
      return false;
    }

    if (msg.type === 'p2d-state') {
      sendResponse({ ok: true, on: pick.on, mode: pick.mode });
      return false;
    }
  });

  /* ------------------------------------------------------------ 事件 */

  const reposition = () => {
    if (pick.on) layoutPick();
  };
  window.addEventListener('scroll', reposition, { passive: true, capture: true });
  window.addEventListener('resize', reposition, { passive: true });

  try {
    chrome.storage.sync.get(DEFAULTS, (s) => {
      settings = Object.assign({}, DEFAULTS, s);
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'sync') return;
      for (const k in changes) {
        if (k in DEFAULTS) settings[k] = changes[k].newValue;
      }
      if (pick.on) drawPick();
    });
  } catch (e) {
    console.warn('[内容直贴] 读取设置失败，使用默认值', e);
  }
})();
