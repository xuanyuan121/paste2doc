/* 文档模型：定义 + 纯文本导出
 *
 * 模型只描述「结构」，不描述外观：
 *   块   {t:'h'|'p'|'list'|'code'|'table'|'math', ...}
 *   行内 {t:'text'|'math'|'br', v, b, i, st, code, sup, sub, link}
 * 具体排成什么样（宋体/Times、五号、单倍行距、首行缩进）由本地组件按固定规则写进样式里。
 */
(() => {
  'use strict';
  const NS = (window.__p2d = window.__p2d || {});

  NS.OPT = { size: 21, line: 240, indent: true };

  /* MathML -> 可读文本，只给「复制为纯文本」用 */
  function mathText(node) {
    if (!node) return '';
    if (node.nodeType === 3) return node.nodeValue;
    const tag = (node.localName || '').toLowerCase();
    const kids = (n) => Array.from(n.childNodes).map(mathText).join('');
    const first = (name) => {
      for (const c of node.children) {
        if ((c.localName || '').toLowerCase() === name) return mathText(c);
      }
      return '';
    };
    switch (tag) {
      case 'math': return kids(node).trim();
      case 'mfrac': return '(' + first('num') + ')/(' + first('den') + ')';
      case 'msup': return kids(node.children[0] || node) + '^' + (mathText(node.children[1]) || '');
      case 'msub': return (mathText(node.children[0]) || '') + '_' + (mathText(node.children[1]) || '');
      case 'msubsup':
        return (mathText(node.children[0]) || '') + '_' + (mathText(node.children[1]) || '')
          + '^' + (mathText(node.children[2]) || '');
      case 'msqrt': return '√(' + kids(node) + ')';
      case 'mroot': return 'root(' + kids(node) + ')';
      case 'mtable':
        return Array.from(node.children).map((tr) =>
          Array.from(tr.children).map((td) => mathText(td)).join('\t')).join('; ');
      case 'mtext': return kids(node);
      case 'annotation': return '';
      case 'mspace': return ' ';
      default: return kids(node);
    }
  }

  NS.mathToText = function (mathml) {
    if (!mathml) return '';
    // XML 解析器不认 &nbsp; 这类 HTML 实体，先换成数字引用，否则整条公式变空
    const clean = String(mathml).replace(/&nbsp;/g, '&#160;');
    try {
      const doc = new DOMParser().parseFromString(clean, 'application/xml');
      return mathText(doc.documentElement).replace(/\s+/g, ' ').trim();
    } catch (e) {
      return '';
    }
  };

  function inlineText(inl) {
    let s = '';
    for (const n of inl || []) {
      if (n.t === 'text') s += n.v;
      else if (n.t === 'br') s += '\n';
      else if (n.t === 'math') s += NS.mathToText(n.mathml) || '';
    }
    return s;
  }
  NS.inlineText = inlineText;

  /** 模型 -> 纯文本。保留层级感，但不用任何富文本。 */
  NS.toPlain = function (blocks) {
    const out = [];
    const blank = () => {
      if (out.length && out[out.length - 1] !== '') out.push('');
    };
    for (const b of blocks || []) {
      if (b.t === 'h') {
        blank();
        out.push(inlineText(b.inl));
        blank();
      } else if (b.t === 'p') {
        out.push((b.q ? '> ' : '') + inlineText(b.inl));
        blank();
      } else if (b.t === 'list') {
        let n = b.start || 1;
        for (const it of b.items || []) {
          const indent = '  '.repeat(it.lvl || 0);
          const mark = b.ordered ? (n++) + '. ' : '• ';
          out.push(indent + mark + inlineText(it.inl));
        }
        blank();
      } else if (b.t === 'code') {
        out.push(b.text || '');
        blank();
      } else if (b.t === 'table') {
        for (const row of b.rows || []) {
          out.push((row || []).map((c) => inlineText(c).replace(/\s+/g, ' ').trim()).join('\t'));
        }
        blank();
      } else if (b.t === 'math') {
        out.push(NS.mathToText(b.mathml));
        blank();
      }
    }
    while (out.length && out[out.length - 1] === '') out.pop();
    return out.join('\n');
  };

  /** 去空块、去空行内 —— 保证模型里没有空段落 */
  NS.cleanBlocks = function (blocks) {
    const out = [];
    for (const b of blocks || []) {
      if (b.t === 'p' || b.t === 'h') {
        const inl = (b.inl || []).filter((n) =>
          (n.t === 'text' && n.v.trim()) || n.t === 'math' || n.t === 'br');
        if (!inl.length) continue;
        out.push(Object.assign({}, b, { inl }));
      } else if (b.t === 'list') {
        const items = (b.items || []).filter((it) => (it.inl || []).length);
        if (!items.length) continue;
        out.push(Object.assign({}, b, { items }));
      } else if (b.t === 'code') {
        if (!(b.text || '').trim()) continue;
        out.push(b);
      } else if (b.t === 'table') {
        const rows = (b.rows || []).filter((r) => (r || []).some((c) => (c || []).length));
        if (!rows.length) continue;
        out.push(Object.assign({}, b, { rows }));
      } else if (b.t === 'math') {
        if (b.mathml) out.push(b);
      }
    }
    return out;
  };
})();
