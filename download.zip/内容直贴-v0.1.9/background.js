/* 后台：和本地组件通信 + 侧边栏动作转发
 *
 * 浏览器扩展只能往剪贴板写文字和 HTML，写不了 WPS 的私有格式，也写不了 Word 认的
 * RTF。所以「复制成排好版的文档」这最后一步交给本地组件（Native Messaging），
 * 由浏览器按需拉起，用完即退。
 */
const HOST = 'com.paste2doc.host';
const DEFAULTS = {
  plain: false, mode: 'all',
  size: 21, line: 240, indent: true, unify: true
};

/* ------------------------------------------------------------ 侧边栏 */

function enableSidePanel() {
  if (!chrome.sidePanel || !chrome.sidePanel.setPanelBehavior) return;
  try {
    const r = chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
    if (r && typeof r.catch === 'function') r.catch(() => {});
  } catch (e) { /* 老版本忽略 */ }
}

chrome.action.onClicked.addListener((tab) => {
  if (!chrome.sidePanel || !chrome.sidePanel.open || !tab) return;
  try {
    const r = chrome.sidePanel.open({ windowId: tab.windowId });
    if (r && typeof r.catch === 'function') r.catch(() => {});
  } catch (e) { /* 忽略 */ }
});

/* ------------------------------------------------------- 侧边栏的入口
 * 侧边栏是独立页面，自己没有标签页上下文，所以动作统一在这里转发到当前页。
 * 内容脚本会回一个 { ok, error }，这里原样带回给侧边栏，让人看到真实结果。
 */
function activeTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
      if (tabs && tabs[0]) { resolve(tabs[0]); return; }
      // 侧边栏不是标签页，某些情况下按窗口查不到，退一步再找一次
      chrome.tabs.query({ active: true }, (all) => resolve((all && all[0]) || null));
    });
  });
}

function sendToActiveTab(msg) {
  return new Promise((resolve) => {
    activeTab().then((tab) => {
      if (!tab || tab.id == null) { resolve({ ok: false, error: '没有找到活动标签页' }); return; }
      if (/^(chrome|edge|about|chrome-extension|edge-extension):/i.test(tab.url || '')) {
        resolve({ ok: false, error: '浏览器自己的页面不能复制，切到 AI 对话页再试' });
        return;
      }
      chrome.tabs.sendMessage(tab.id, msg, (resp) => {
        const err = chrome.runtime.lastError;
        if (err) {
          // 最常见的原因：扩展刚更新过，页面里跑的还是旧的内容脚本
          resolve({ ok: false, error: '这个页面还没加载新版扩展，按 F5 刷新一下再试' });
          return;
        }
        resolve(resp || { ok: false, error: '页面没有回应' });
      });
    });
  });
}

/* 服务进程每次被唤醒都重新登记一次：浏览器可能会忘掉「点图标开侧边栏」这个设置，
 * 只在 onInstalled 里设一次不够稳。 */
enableSidePanel();

chrome.runtime.onInstalled.addListener(() => {
  enableSidePanel();
  chrome.storage.sync.get(DEFAULTS, (cur) => {
    chrome.storage.sync.set(Object.assign({}, DEFAULTS, cur));
  });
});

chrome.runtime.onStartup.addListener(() => {
  enableSidePanel();
});

/* ------------------------------------------------------- 本地组件连接
 *
 * 用长连接而不是一次性消息：宿主是 Python 程序，冷启动要初始化运行时，
 * 连着复用后连续复制只要几十毫秒。空闲 60 秒宿主自己退出，端口随之断开。
 */
let port = null;
const queue = [];
let inflight = null;

function ensurePort() {
  if (port) return port;
  try {
    port = chrome.runtime.connectNative(HOST);
  } catch (e) {
    port = null;
    return null;
  }
  port.onMessage.addListener((msg) => {
    if (inflight) {
      const job = inflight;
      inflight = null;
      clearTimeout(job.timer);
      job.resolve(msg || { ok: false, error: '本地组件没有回应' });
    }
    pump();
  });
  port.onDisconnect.addListener(() => {
    const err = chrome.runtime.lastError;
    const text = (err && err.message) || '本地组件已退出';
    port = null;
    if (inflight) {
      const job = inflight;
      inflight = null;
      clearTimeout(job.timer);
      job.resolve({ ok: false, error: text, noHost: true });
    }
    pump();
  });
  return port;
}

function pump() {
  if (inflight) return;
  const job = queue.shift();
  if (!job) return;

  const p = ensurePort();
  if (!p) {
    job.resolve({ ok: false, error: '本地组件未安装', noHost: true });
    pump();
    return;
  }

  inflight = job;
  job.timer = setTimeout(() => {
    if (inflight !== job) return;
    inflight = null;
    job.resolve({ ok: false, error: '本地组件超时' });
    try { if (port) port.disconnect(); } catch (e) { /* 忽略 */ }
    pump();
  }, 20000);

  try {
    p.postMessage(job.payload);
  } catch (e) {
    clearTimeout(job.timer);
    inflight = null;
    job.resolve({ ok: false, error: String(e), noHost: true });
    pump();
  }
}

function callHost(payload) {
  return new Promise((resolve) => {
    queue.push({ payload, resolve, timer: null });
    pump();
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  if (msg.type === 'panel-action') {
    /* 侧边栏只有三个动作：
     *   state -> 问页面现在是不是在点选（按钮该显示「开始使用」还是「关闭扩展」）
     *   stop  -> 关掉点选，蓝框立刻消失
     *   其余  -> 开始 / 切换模式，页面进入对应的点选状态，点完自己复制
     * 以前是「点某个模式就自动进点选」，所以一打开侧边栏想去点历史都会先被拦一下；
     * 现在默认关着，开了才接管点击。 */
    const action = msg.action || 'start';
    if (action === 'state') {
      sendToActiveTab({ type: 'p2d-state' }).then(sendResponse);
      return true;
    }
    if (action === 'stop') {
      sendToActiveTab({ type: 'p2d-stop' }).then(sendResponse);
      return true;
    }
    sendToActiveTab({ type: 'p2d-start', mode: msg.mode || 'all' }).then(sendResponse);
    return true;
  }

  if (msg.type === 'copy-doc') {
    callHost({ action: 'copy-doc', model: msg.model, plain: msg.plain })
      .then(sendResponse);
    return true;
  }

  if (msg.type === 'ping-host') {
    callHost({ action: 'ping' }).then(sendResponse);
    return true;
  }

  // 只有页面里出现「只剩 LaTeX、没有 MathML」的公式时才需要 KaTeX。
  // 按需注入到扩展自己的隔离世界（和内容脚本同一个 world），
  // 不然 272KB 的解析要摊到每个网页上。
  if (msg.type === 'inject-katex') {
    const tabId = sender.tab && sender.tab.id;
    if (tabId == null) { sendResponse({ ok: false }); return true; }
    chrome.scripting.executeScript({
      target: { tabId, frameIds: [sender.frameId || 0] },
      files: ['lib/katex.min.js']
    }).then(() => sendResponse({ ok: true }))
      .catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true;
  }
});
