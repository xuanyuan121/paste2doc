# -*- coding: utf-8 -*-
"""内容直贴 · 本地组件的安装内核。

被「安装程序」和「卸载程序」共用（它们其实是同一个 exe 的两种模式）：

    Paste2DocSetup.exe                 打开安装向导
    Paste2DocSetup.exe --uninstall     打开卸载界面
    Paste2DocSetup.exe --install --dir <路径> --silent   静默安装（自动化测试用）
    Paste2DocSetup.exe --uninstall --silent              静默卸载

装的是什么：一个 Paste2DocHost.exe（宿主，浏览器按需拉起，往剪贴板写 WPS 格式），
加一份原生消息清单，再往 HKCU 登记三条浏览器路径和一个「设置 → 应用」里的卸载项。

    全部落在 HKCU 和 %LOCALAPPDATA% 下，不需要管理员权限。
    宿主是自带运行时的单文件程序，**不需要用户装 Python**。
"""
import json
import os
import shutil
import subprocess
import sys
import winreg

APP_NAME = '内容直贴 · 本地组件'
APP_ID = 'Paste2Doc'
HOST_NAME = 'com.paste2doc.host'
HOST_EXE = 'Paste2DocHost.exe'
HOST_SUB = 'Paste2DocHost'      # 宿主是 onedir 打包：一个文件夹，启动才快
SETUP_EXE = 'Paste2DocSetup.exe'
EXT_ID = 'cpjmadcbfhaghodkkihjnbhjohgdaggm'      # 开发者模式加载时固定的 ID

BROWSERS = [
    ('Chrome', r'Software\Google\Chrome\NativeMessagingHosts'),
    ('Edge', r'Software\Microsoft\Edge\NativeMessagingHosts'),
    ('Chromium', r'Software\Chromium\NativeMessagingHosts'),
]
UNINSTALL_KEY = r'Software\Microsoft\Windows\CurrentVersion\Uninstall\%s' % APP_ID

PROFILE_ROOTS = [
    os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Microsoft\Edge\User Data'),
    os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Google\Chrome\User Data'),
    os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Chromium\User Data'),
]
MARK = '内容直贴'          # 我们的 _locales 里有这个标记，认得出就是本扩展

CREATE_NO_WINDOW = 0x08000000
DETACHED_PROCESS = 0x00000008


# ----------------------------------------------------------------- 版本

def version():
    """版本号只有一个来源：manifest.json（打包时一起带上）。"""
    for base in (base_dir(), os.path.dirname(os.path.abspath(__file__))):
        p = os.path.join(base, 'version.txt')
        if os.path.isfile(p):
            with open(p, encoding='utf-8') as f:
                v = f.read().strip()
            if v:
                return v
    return '0.0.0'


def base_dir():
    """打包后是解压出来的临时目录，源码运行时是 host 目录。"""
    if getattr(sys, 'frozen', False):
        return getattr(sys, '_MEIPASS', os.path.dirname(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def default_dir():
    return os.path.join(os.environ.get('LOCALAPPDATA', os.path.expanduser('~')),
                        APP_ID)


def host_exe(dest):
    """宿主 exe 的实际路径：onedir 在子目录里，早期的单文件版在根上。"""
    p = os.path.join(dest, HOST_SUB, HOST_EXE)
    return p if os.path.isfile(p) else os.path.join(dest, HOST_EXE)


def _size_kb(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return max(1, total // 1024)


# ------------------------------------------------------------- 扩展 ID

def _read_json(path):
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _looks_like_us(path):
    """目录里的 _locales 有没有我们的名字 —— 商店版 ID 只能这么认。"""
    if not path or not os.path.isdir(path):
        return False
    for sub in ('_locales', 'locales'):
        base = os.path.join(path, sub)
        if not os.path.isdir(base):
            continue
        try:
            for name in os.listdir(base):
                f = os.path.join(base, name, 'messages.json')
                if not os.path.isfile(f):
                    continue
                blob = _read_json(f)
                if not isinstance(blob, dict):
                    continue
                for key in ('extName', 'appName', 'extDesc', 'appDesc'):
                    v = blob.get(key)
                    text = ''
                    if isinstance(v, dict):
                        text = str(v.get('message') or '')
                    elif isinstance(v, str):
                        text = v
                    if MARK in text:
                        return True
        except OSError:
            pass
    return False


def ids_from_profiles():
    """扫浏览器 profile，把「装着的本扩展」的 ID 找出来。

    开发者版靠 manifest 里的 key 固定了 ID，但**商店版的 ID 由商店分配**。
    只放行开发者版，商店版就连不上宿主 —— 表现是「WPS 粘出来是纯文本」。
    """
    found = []
    for root in PROFILE_ROOTS:
        if not os.path.isdir(root):
            continue
        try:
            names = os.listdir(root)
        except OSError:
            continue
        for name in names:
            prof = os.path.join(root, name)
            if not os.path.isdir(prof):
                continue
            if name != 'Default' and not name.startswith('Profile'):
                continue

            for fname in ('Preferences', 'Secure Preferences'):
                data = _read_json(os.path.join(prof, fname))
                if not isinstance(data, dict):
                    continue
                settings = (data.get('extensions') or {}).get('settings') or {}
                if not isinstance(settings, dict):
                    continue
                for ext_id, info in settings.items():
                    if not isinstance(info, dict):
                        continue
                    path = info.get('path') or ''
                    if 'paste2doc' in path.lower() or _looks_like_us(path):
                        if ext_id not in found:
                            found.append(ext_id)

            ext_root = os.path.join(prof, 'Extensions')
            if not os.path.isdir(ext_root):
                continue
            try:
                ids = os.listdir(ext_root)
            except OSError:
                continue
            for ext_id in ids:
                base = os.path.join(ext_root, ext_id)
                if not os.path.isdir(base):
                    continue
                try:
                    versions = os.listdir(base)
                except OSError:
                    continue
                for ver in versions:
                    if _looks_like_us(os.path.join(base, ver)):
                        if ext_id not in found:
                            found.append(ext_id)
                        break
    return found


def origins(manual=()):
    """开发者版 ID + 扫出来的商店版 ID + allowed_ids.txt + 手动补的。"""
    ids = [EXT_ID]
    extra = []
    path = os.path.join(base_dir(), 'allowed_ids.txt')
    if os.path.isfile(path):
        with open(path, encoding='utf-8') as f:
            extra = f.readlines()
    for line in list(extra) + list(manual):
        s = str(line).split('#')[0].strip()
        s = s.replace('chrome-extension://', '').strip('/ ')
        if len(s) == 32 and all('a' <= c <= 'p' for c in s) and s not in ids:
            ids.append(s)
    return ['chrome-extension://%s/' % i for i in ids]


# --------------------------------------------------------------- 状态

def _reg_get(key, name):
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key) as k:
            return winreg.QueryValueEx(k, name)[0]
    except OSError:
        return None


def installed_dir():
    """已装在哪：先看「设置 → 应用」里的登记，再看宿主清单。"""
    d = _reg_get(UNINSTALL_KEY, 'InstallLocation')
    if d and os.path.isfile(host_exe(d)):
        return d
    for _label, key in BROWSERS:
        p = _reg_get(key + '\\' + HOST_NAME, '')
        if isinstance(p, str) and os.path.isfile(p):
            return os.path.dirname(p)
    return None


def state():
    d = installed_dir()
    return {'installed': bool(d), 'dir': d, 'version': version() if d else None,
            'registered': [label for label, key in BROWSERS
                           if _reg_get(key + '\\' + HOST_NAME, '')]}


# --------------------------------------------------------------- 安装

def _copy_in(src, dest_file):
    """dest_file 是文件路径，不是目录。"""
    parent = os.path.dirname(dest_file)
    if parent:
        os.makedirs(parent, exist_ok=True)
    shutil.copyfile(src, dest_file)


def install(dest, progress=None, manual_ids=(), quiet=False):
    """真装。progress(percent, text) 会被按步骤调。"""
    say = progress or (lambda p, t: None)
    dest = os.path.abspath(dest)
    src = base_dir()

    say(6, '准备安装目录')
    os.makedirs(dest, exist_ok=True)

    say(18, '复制宿主程序')
    host_src = os.path.join(src, HOST_SUB)
    if os.path.isdir(host_src):
        target = os.path.join(dest, HOST_SUB)
        if os.path.abspath(host_src) != os.path.abspath(target):
            shutil.copytree(host_src, target, dirs_exist_ok=True)
    else:
        # 源码目录里跑的时候只有脚本，没有打包好的 exe
        one = os.path.join(src, HOST_EXE)
        if os.path.isfile(one):
            _copy_in(one, os.path.join(dest, HOST_EXE))
        else:
            raise RuntimeError('安装包不完整：缺 %s' % HOST_SUB)

    # 安装程序自己也要留在安装目录里：卸载项指向的就是它。
    # 打包成 exe 跑的时候，它在 sys.executable，不在解压目录里。
    setup_src = os.path.join(src, SETUP_EXE)
    if not os.path.isfile(setup_src) and getattr(sys, 'frozen', False):
        setup_src = sys.executable
    if os.path.isfile(setup_src):
        tgt = os.path.join(dest, SETUP_EXE)
        if os.path.abspath(setup_src) != os.path.abspath(tgt):
            _copy_in(setup_src, tgt)

    for extra in ('version.txt', '说明.txt'):
        s = os.path.join(src, extra)
        if os.path.isfile(s):
            _copy_in(s, os.path.join(dest, extra))

    say(40, '写入宿主清单')
    host_path = host_exe(dest)
    manifest = {
        'name': HOST_NAME,
        'description': 'Paste2Doc native host',
        'path': host_path,
        'type': 'stdio',
        'allowed_origins': origins(manual_ids),
    }
    manifest_path = os.path.join(dest, HOST_NAME + '.json')
    with open(manifest_path, 'w', encoding='utf-8') as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    say(58, '注册到浏览器')
    ok = []
    for label, key in BROWSERS:
        try:
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key + '\\' + HOST_NAME) as k:
                winreg.SetValueEx(k, '', 0, winreg.REG_SZ, manifest_path)
            ok.append(label)
        except OSError:
            pass
    if not ok:
        raise RuntimeError('三个浏览器都没登记成功')

    say(80, '登记到「设置 → 应用」')
    setup_path = os.path.join(dest, SETUP_EXE)
    vals = [
        ('DisplayName', '%s' % APP_NAME),
        ('DisplayVersion', version()),
        ('Publisher', '内容直贴'),
        ('InstallLocation', dest),
        ('DisplayIcon', host_path),
        ('UninstallString', '"%s" --uninstall' % setup_path),
        ('QuietUninstallString', '"%s" --uninstall --silent' % setup_path),
        ('InstallDate', _today()),
        ('NoModify', 1),
        ('NoRepair', 1),
    ]
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY) as k:
        for name, v in vals:
            if isinstance(v, int):
                winreg.SetValueEx(k, name, 0, winreg.REG_DWORD, v)
            else:
                winreg.SetValueEx(k, name, 0, winreg.REG_SZ, v)
        winreg.SetValueEx(k, 'EstimatedSize', 0, winreg.REG_DWORD, _size_kb(dest))
    say(94, '收尾')
    say(100, '完成')
    return {'dir': dest, 'manifest': manifest_path, 'browsers': ok,
            'origins': manifest['allowed_origins']}


def _today():
    import datetime
    return datetime.date.today().strftime('%Y%m%d')


# --------------------------------------------------------------- 卸载

def uninstall(progress=None):
    """删登记、删文件。正在运行的自己删不掉，交给一个延迟的 cmd 收尾。"""
    say = progress or (lambda p, t: None)

    # 先把安装位置记住，等下登记项就被删了
    dest = installed_dir() or default_dir()

    say(10, '清理浏览器登记')
    for _label, key in BROWSERS:
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, key + '\\' + HOST_NAME)
        except OSError:
            pass

    say(30, '清理「设置 → 应用」里的登记')
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY, 0,
                            winreg.KEY_ALL_ACCESS) as k:
            while True:
                try:
                    winreg.DeleteValue(k, winreg.EnumValue(k, 0)[0])
                except OSError:
                    break
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY)
    except OSError:
        pass

    say(55, '删除程序文件')
    removed = []
    if dest and os.path.isdir(dest):
        for name in os.listdir(dest):
            p = os.path.join(dest, name)
            try:
                if os.path.isdir(p):
                    shutil.rmtree(p, ignore_errors=True)
                else:
                    os.remove(p)
                    removed.append(name)
            except OSError:
                pass

    say(90, '收尾')
    # 文件清空了就把空目录也删掉；删不掉（自己正住在里面）就挂一个延迟的 cmd 收尾
    left = False
    if dest and os.path.isdir(dest):
        try:
            os.rmdir(dest)
        except OSError:
            left = True
    if left:
        me = os.path.abspath(sys.executable)
        exe_part = 'del /f /q "%s" >nul 2>nul & ' % me \
            if me.lower().startswith(os.path.abspath(dest).lower()) else ''
        cmd = ('ping -n 3 127.0.0.1 >nul & %srmdir /s /q "%s" >nul 2>nul'
               % (exe_part, dest))
        try:
            subprocess.Popen(['cmd', '/c', cmd],
                             creationflags=CREATE_NO_WINDOW | DETACHED_PROCESS,
                             close_fds=True)
        except OSError:
            pass
    say(100, '完成')
    return {'dir': dest, 'removed': removed}


def open_folder(path):
    try:
        os.startfile(path)          # noqa: S606
    except OSError:
        pass
