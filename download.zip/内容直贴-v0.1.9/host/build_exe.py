# -*- coding: utf-8 -*-
"""把本地组件打成两个 exe（不用装 Python 的那种）。

    python host/build_exe.py            两个都打
    python host/build_exe.py --host     只打宿主
    python host/build_exe.py --setup    只打安装程序

产物：
    host/_build/dist/Paste2DocHost/Paste2DocHost.exe     onedir：启动快，浏览器每次粘贴都要拉它
    host/_build/dist/Paste2DocSetup.exe                  onefile：只跑一次，解压慢点无所谓

宿主用 --onedir 是有意的：onefile 每次启动都要往临时目录解压一遍，
而宿主是「每次粘贴拉一次」的，那点解压时间会变成能感觉到的延迟。
"""
import json
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
BUILD = os.path.join(HERE, '_build')
DIST = os.path.join(BUILD, 'dist')
STAGE = os.path.join(BUILD, 'stage')


def version():
    with open(os.path.join(ROOT, 'manifest.json'), encoding='utf-8') as f:
        return json.load(f)['version']


def make_ico():
    """多尺寸 .ico：任务栏、资源管理器、设置里的图标都从它取。

    这台机器上如果没装 Pillow，用已经生成好的那份就行（tools/make_ico.py 生成）。
    """
    out = os.path.join(STAGE, 'app.ico')
    try:
        from PIL import Image
    except ImportError:
        if os.path.isfile(out):
            return out
        raise SystemExit('缺 Pillow，先在装了 Pillow 的解释器上跑 tools/make_ico.py')
    src = Image.open(os.path.join(ROOT, 'icons', '128.png')).convert('RGBA')
    big = src.resize((256, 256), Image.LANCZOS)
    sizes = [(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
    big.save(out, format='ICO', sizes=sizes)
    return out


def stage_files():
    os.makedirs(STAGE, exist_ok=True)
    make_ico()
    shutil.copyfile(os.path.join(ROOT, 'icons', '48.png'),
                    os.path.join(STAGE, 'icon48.png'))
    with open(os.path.join(STAGE, 'version.txt'), 'w', encoding='utf-8') as f:
        f.write(version())
    src_txt = os.path.join(HERE, '使用说明-本地组件.txt')
    if os.path.isfile(src_txt):
        shutil.copyfile(src_txt, os.path.join(STAGE, '说明.txt'))
    # 宿主用到的模块全拷过去：PyInstaller 以 stage 为工作目录去找依赖，
    # 漏一个就是「装了但一启动就崩」。
    skip = {'build_exe.py', 'install_host.py', '自检.py'}
    for name in os.listdir(HERE):
        if not name.endswith('.py') or name in skip:
            continue
        shutil.copyfile(os.path.join(HERE, name), os.path.join(STAGE, name))


def pyinstaller(args):
    cmd = [sys.executable, '-m', 'PyInstaller', '--noconfirm', '--clean',
           '--distpath', DIST, '--workpath', os.path.join(BUILD, 'work')] + args
    print('>', ' '.join(cmd[2:]))
    r = subprocess.run(cmd, cwd=STAGE)
    if r.returncode != 0:
        raise SystemExit('PyInstaller 失败')


def build_host():
    pyinstaller([
        '--onedir', '--console', '--name', 'Paste2DocHost',
        '--icon', os.path.join(STAGE, 'app.ico'),
        '--exclude-module', 'tkinter',
        '--exclude-module', 'unittest',
        '--exclude-module', 'email',
        '--exclude-module', 'pydoc',
        '--exclude-module', 'PIL',
        # 宿主不联网：把 SSL / 加密库整套挡掉，省 4 MB（libcrypto 一个就 3.3 MB）
        '--exclude-module', 'ssl',
        '--exclude-module', '_ssl',
        '--exclude-module', 'hashlib',
        '--exclude-module', '_hashlib',
        'host_exe.py',
    ])


def build_setup():
    sep = ';' if os.name == 'nt' else ':'
    pyinstaller([
        '--onefile', '--windowed', '--name', 'Paste2DocSetup',
        '--icon', os.path.join(STAGE, 'app.ico'),
        '--add-data', 'app.ico' + sep + '.',
        '--add-data', 'icon48.png' + sep + '.',
        '--add-data', 'version.txt' + sep + '.',
        '--add-data', '说明.txt' + sep + '.',
        '--add-data', os.path.join(DIST, 'Paste2DocHost') + sep + 'Paste2DocHost',
        '--exclude-module', 'unittest',
        '--exclude-module', 'pydoc',
        '--exclude-module', 'ssl',
        '--exclude-module', '_ssl',
        '--exclude-module', 'hashlib',
        '--exclude-module', '_hashlib',
        'setup_gui.py',
    ])


def main():
    argv = sys.argv[1:]
    only_host = '--host' in argv
    only_setup = '--setup' in argv
    stage_files()
    os.makedirs(DIST, exist_ok=True)
    # PyInstaller 自己也会删旧产物，但几百个文件一起删会被安全策略拦下来；
    # 交给 rd/del 一次性清掉，省事。
    for tgt in ([os.path.join(DIST, 'Paste2DocHost')] if not only_setup else []) + \
               ([] if only_host else [os.path.join(DIST, 'Paste2DocSetup.exe')]):
        if os.path.isdir(tgt):
            subprocess.run(['cmd', '/c', 'rd', '/s', '/q', tgt])
        elif os.path.isfile(tgt):
            try:
                os.remove(tgt)
            except OSError:
                pass

    if not only_setup:
        build_host()
    if not only_host:
        if not os.path.isdir(os.path.join(DIST, 'Paste2DocHost')):
            raise SystemExit('先打宿主：python host/build_exe.py --host')
        build_setup()

    print()
    for p in (os.path.join(DIST, 'Paste2DocHost', 'Paste2DocHost.exe'),
              os.path.join(DIST, 'Paste2DocSetup.exe')):
        if os.path.isfile(p):
            print('%-52s %8.1f KB' % (os.path.relpath(p, ROOT), os.path.getsize(p) / 1024.0))


if __name__ == '__main__':
    main()
