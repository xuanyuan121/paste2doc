# -*- coding: utf-8 -*-
"""打包成 exe 后的入口：浏览器按需拉起它，走 stdio 的原生消息协议。

和源码版的两点区别：

  1. 浏览器启动宿主时不带任何参数，这里自己补上 --host；
  2. 有人直接双击它的时候，stdin 不是管道 —— 那就别干等着，
     弹一句「这个程序由浏览器自动调用」然后退出。
"""
import ctypes
import sys

FILE_TYPE_PIPE = 3


def piped_stdin():
    k32 = ctypes.windll.kernel32
    h = k32.GetStdHandle(-10)          # STD_INPUT_HANDLE
    return k32.GetFileType(h) == FILE_TYPE_PIPE


if __name__ == '__main__':
    if '--host' not in sys.argv and not piped_stdin():
        ctypes.windll.user32.MessageBoxW(
            0,
            '这个程序由浏览器自动调用，不需要双击运行。\n\n'
            '要给 WPS 用上排版粘贴，请双击同一文件夹里的「Paste2DocSetup.exe」。',
            '内容直贴 · 本地组件', 0x40)
        sys.exit(0)

    import paste2doc_host

    if '--host' not in sys.argv:
        sys.argv.append('--host')
    sys.exit(paste2doc_host.main() or 0)
