# -*- coding: utf-8 -*-
"""文档模型 -> RTF（给 Word 用）。

WPS 走 docx（私有剪贴板格式里塞一个 docx 包），Word 不认那个格式，
它认的是剪贴板里的 "Rich Text Format"。所以同一份模型还要再写一份 RTF：

  * 标题 -> \\s1..\\s6 + heading 1..6，Word 认名字，直接映射到内置标题样式
  * 列表 -> \\listtable 里的真编号（回车能接续）
  * 表格 -> \\trowd 真表格
  * 公式 -> \\mmath 组（Word 2007+ 的 RTF 数学语法，粘进去是原生公式）

RTF 是字节格式，中文按 GBK（\\ansicpg936）用 \\'hh 转义，字体名也一样；
GBK 里没有的字符退回 \\uN?。
"""
from p2d_escape import rtf_escape
from p2d_math import mathml_to_omml, omml_to_rtf

FONTS = [
    ('Times New Roman', r'\froman\fcharset0'),
    ('宋体', r'\fnil\fcharset134'),
    ('黑体', r'\fnil\fcharset134'),
    ('Consolas', r'\fmodern\fcharset0'),
    ('Cambria Math', r'\froman\fcharset0'),
]

F_BODY, F_SONG, F_HEI, F_CODE, F_MATH = 0, 1, 2, 3, 4






class Rtf:
    def __init__(self):
        self.parts = []
        self.col = 0

    def w(self, s):
        """写字，顺带按 180 字符换行（RTF 读取器对超长行不友好）。"""
        for chunk in s.split('\n'):
            if chunk:
                self.parts.append(chunk)
                self.col += len(chunk)
            if self.col > 180:
                self.parts.append('\n')
                self.col = 0

    def raw(self, s):
        self.parts.append(s)
        self.col = len(s) if '\n' not in s else 0


class RtfBuilder:
    def __init__(self, model):
        self.model = model or {}
        self.opt = self.model.get('opt') or {}
        self.size = int(self.opt.get('size') or 21)
        self.line = int(self.opt.get('line') or 240)
        self.indent = bool(self.opt.get('indent', True))
        # unify=True（默认）：清掉网页带过来的行内格式（加粗 / 斜体 / 删除线 /
        # 链接的蓝字下划线），只留结构（标题级别、编号、表格、公式、代码）。
        # 字体字号行距本来就在样式表里定死了，不受网页影响。
        self.unify = bool(self.opt.get('unify', True))
        self.blocks = self.model.get('blocks') or []
        self.lists = []         # 每个 list 块一条 \list 定义
        self.overrides = []     # 对应的 \listoverride（段落里的 \ls 指的是它）
        self._list_seq = 1

    # ------------------------------------------------------- 字体 / 样式

    def _font_table(self):
        out = [r'{\fonttbl']
        for i, (name, attr) in enumerate(FONTS):
            out.append('{\\f%d%s %s;}' % (i, attr, rtf_escape(name)))
        out.append('}')
        return ''.join(out)

    def _first_line(self):
        return r'\fi420' if self.indent else r'\fi0'

    def _stylesheet(self):
        s = self.size
        q = '\\sl%d\\slmult1\\sb0\\sa0' % self.line
        out = [r'{\stylesheet',
               r'{\s0\snext0\ql%s\fi0\loch\f%d\hich\f%d\dbch\f%d\fs%d Normal;}'
               % (q, F_BODY, F_BODY, F_SONG, s)]
        sizes = [32, 28, 24, 21, 21, 21]
        head_font = F_SONG if self.unify else F_HEI
        for lvl in range(1, 7):
            hs = max(sizes[lvl - 1], s)
            out.append(r'{\s%d\sbasedon0\snext0\outlinelevel%d\keepn%s\fi0\ql\b\fs%d'
                       r'\loch\f%d\hich\f%d\dbch\f%d heading %d;}'
                       % (lvl, lvl - 1, q, hs, F_BODY, F_BODY, head_font, lvl))
        out.append(r'{\s7\sbasedon0\snext0\keepn%s\cbpat4\fi0\ql\fs%d\loch\f%d\hich\f%d\dbch\f%d Code;}'
                   % (q, max(18, s - 3), F_CODE, F_CODE, F_SONG))
        out.append(r'{\s8\sbasedon0\snext0%s\li420\ri420\fi0\ql'
                   r'\brdrl\brdrs\brdrw10\brsp120\brdrcf5'
                   r'\loch\f%d\hich\f%d\dbch\f%d\fs%d Quote;}'
                   % (q, F_BODY, F_BODY, F_SONG, s))
        out.append(r'{\s9\sbasedon0\snext0%s\fi0\ql\loch\f%d\hich\f%d\dbch\f%d\fs%d Table Text;}'
                   % (q, F_BODY, F_BODY, F_SONG, s))
        out.append('}')
        return ''.join(out)

    # ------------------------------------------------------- 编号定义

    def _list_def(self, ordered, start):
        r"""返回 (段落里用的 \ls 序号, \list 定义, \listoverride 定义)。

        Word 的段落只认 \\listoverridetable 里的 \\ls 序号，\listid 不直接出现在段落里。
        漏掉 override 表，编号就会整个失效（肉眼看是“粘进来没有编号”）。
        """
        seq = self._list_seq
        self._list_seq += 1
        lid = 1000 + seq
        out = [r'{\list\listtemplateid%d\listhybrid' % lid]
        for lvl in range(9):
            li = 420 * (lvl + 1)
            st = start if lvl == 0 else 1
            if ordered:
                # 照 Word 自己导出 RTF 的结果抄，三种写法按 1. / (1) / 1) 循环：
                #   \leveltext\'hh...   hh 是文字总长度，串里的 \'0N 是编号占位符
                #                       （N = 本级序号），其余是字面文字
                #   \levelnumbers\'0X   X = 占位符在串里的位置 + 1
                # 例： 1.  -> \leveltext\'02\'00.  \levelnumbers\'01
                #     (1) -> \leveltext\'03(\'01)  \levelnumbers\'02
                #      1) -> \leveltext\'02\'02)   \levelnumbers\'01
                # 写成 Word 认的格式，粘进 Word 就是「1. / (1) / 1)」的真多级编号。
                k = lvl % 3
                if k == 0:
                    ltext, lnum = r"{\leveltext\'02\'0%d.;}" % lvl, 1
                elif k == 1:
                    ltext, lnum = r"{\leveltext\'03(\'0%d);}" % lvl, 2
                else:
                    ltext, lnum = r"{\leveltext\'02\'0%d);}" % lvl, 1
                out.append(
                    r'{\listlevel\levelnfc0\levelnfcn0\leveljc0\leveljcn0\levelfollow0'
                    r'\levelstartat%d\levelspace0\levelindent0%s'
                    r'{\levelnumbers\'0%d;}'
                    r'\fi-420\li%d\lin%d\jclisttab\tx%d}'
                    % (st, ltext, lnum, li, li, li))
            else:
                mark = [r'\u8226?', r'\u9702?', r'\u9642?'][lvl % 3]
                out.append(
                    r'{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0'
                    r'\levelstartat1\levelspace0\levelindent0'
                    r'{\leveltext\'01%s;}{\levelnumbers;}\fi-420\li%d\lin%d\jclisttab\tx%d}'
                    % (mark, li, li, li))
        out.append(r'{\listname ;}\listid%d}' % lid)
        override = r'{\listoverride\listid%d\listoverridecount0\ls%d}' % (lid, seq)
        return seq, ''.join(out), override

    # ------------------------------------------------------- 行内内容

    def _inline(self, inl, bold=False):
        out = []
        for node in (inl or []):
            t = node.get('t')
            if t == 'math':
                try:
                    omml, _ = mathml_to_omml(node.get('mathml') or '')
                    out.append(omml_to_rtf(omml, False))
                except Exception:
                    # 公式转不动也不能让这一段凭空消失：把 LaTeX 当斜体文字留下
                    fb = (node.get('latex') or '').strip()
                    if fb:
                        out.append('{\\i %s}' % rtf_escape(fb))
                continue
            if t == 'br':
                out.append(r'\line ')
                continue
            if t != 'text':
                continue
            text = node.get('v') or ''
            if not text:
                continue
            body = rtf_escape(text)
            mods = ''
            if node.get('code'):
                mods += r'\f%d\fs%d' % (F_CODE, max(18, self.size - 1))
            # 表头 / 标题的加粗来自结构（bold 参数），一定保留；
            # 正文里网页给的加粗斜体删除线，统一排版时一律丢掉
            if bold or (not self.unify and node.get('b')):
                mods += r'\b'
            if not self.unify:
                if node.get('i'):
                    mods += r'\i'
                if node.get('st'):
                    mods += r'\strike'
            if node.get('sup'):
                mods += r'\super'
            elif node.get('sub'):
                mods += r'\sub'
            if node.get('link') and not self.unify:
                out.append(r'{\field{\*\fldinst HYPERLINK "%s"}{\fldrslt {%s%s %s}}}'
                           % (rtf_escape(node['link']), mods, r'\ul\cf2', body))
            elif mods:
                out.append('{%s %s}' % (mods, body))
            else:
                out.append(body)
        return ''.join(out)

    def _para(self, inl, style=0, bold=False, extra='', keep_empty=False):
        body = self._inline(inl, bold=bold)
        if not body and not keep_empty:
            return ''
        head = r'\pard\plain\s%d\loch\f%d\hich\f%d\dbch\f%d' % (
            style, F_BODY, F_BODY, F_SONG)
        if 1 <= style <= 6:
            # 标题：样式给出大纲级别，这里再显式写一遍字体字号，保证视觉一致
            head += r'\keepn\b\fs%d\fi0\ql\dbch\f%d' % (
                max([32, 28, 24, 21, 21, 21][style - 1], self.size),
                F_SONG if self.unify else F_HEI)
        elif style == 8:
            # 引用：左侧竖线。样式表里的边框 Word 粘贴时不认，必须写成段落直接格式
            head += (r'\li420\ri420\fi0\ql\fs%d'
                     r'\brdrl\brdrs\brdrw10\brsp120\brdrcf5' % self.size)
        elif style == 9:
            head += r'\fi0\ql\fs%d' % self.size
        else:
            head += r'\fs%d%s\qj' % (self.size, self._first_line())
        return head + extra + ' ' + body + r'\par' + '\n'

    # ------------------------------------------------------------ 表格

    def _table(self, block):
        rows = block.get('rows') or []
        if not rows:
            return ''
        ncol = max(len(r) for r in rows) or 1
        colw = 8306 // ncol
        header = block.get('header', True)
        out = []
        for i, row in enumerate(rows):
            is_head = header and i == 0
            borders = (r'\clbrdrt\brdrs\brdrw10\clbrdrl\brdrs\brdrw10'
                       r'\clbrdrb\brdrs\brdrw10\clbrdrr\brdrs\brdrw10')
            out.append(r'\trowd\trgaph108\trleft-108\trrh0')
            if is_head:
                out.append(r'\trhdr')
            for c in range(ncol):
                bg = r'\clcbpat3' if is_head else ''
                out.append(r'\clvertalc%s%s\cellx%d' % (borders, bg, colw * (c + 1)))
            out.append('\n')
            for c in range(ncol):
                cell = row[c] if c < len(row) else []
                body = self._inline(cell, bold=is_head)
                out.append(r'\pard\plain\intbl\s9\loch\f%d\hich\f%d\dbch\f%d\fs%d '
                           % (F_BODY, F_BODY, F_SONG, self.size))
                if is_head:
                    out.append(r'\b ')
                out.append(body + r'\cell' + '\n')
            out.append(r'\row' + '\n')
        out.append(r'\pard\plain\s0\loch\f%d\hich\f%d\dbch\f%d\fs%d%s'
                   % (F_BODY, F_BODY, F_SONG, self.size, self._first_line()))
        out.append('\n')
        return ''.join(out)

    # ------------------------------------------------------------ 正文

    def body(self):
        out = []
        for b in self.blocks:
            t = b.get('t')
            if t == 'h':
                lvl = min(6, max(1, int(b.get('level') or 2)))
                out.append(self._para(b.get('inl'), style=lvl))
            elif t == 'p':
                out.append(self._para(b.get('inl'), style=8 if b.get('q') else 0))
            elif t == 'list':
                ordered = bool(b.get('ordered'))
                start = int(b.get('start') or 1)
                ls, definition, override = self._list_def(ordered, start)
                self.lists.append(definition)
                self.overrides.append(override)
                for item in (b.get('items') or []):
                    lvl = min(8, max(0, int(item.get('lvl') or 0)))
                    # 缩进不能只靠 \listlevel 里的 \li —— Word 粘贴时以段落直接格式为准，
                    # 不在这里显式写一遍，所有层级都会顶到同一个左边距（看着像平铺）。
                    li = 420 * (lvl + 1)
                    head = (r'\pard\plain\s0\ls%d\ilvl%d\li%d\fi-420'
                            r'\loch\f%d\hich\f%d\dbch\f%d\fs%d '
                            % (ls, lvl, li, F_BODY, F_BODY, F_SONG, self.size))
                    body = self._inline(item.get('inl'))
                    if body:
                        out.append(head + body + r'\par' + '\n')
            elif t == 'code':
                text = (b.get('text') or '').replace('\r\n', '\n').replace('\r', '\n')
                for line in text.strip('\n').split('\n'):
                    # 左右各留一点缩进：代码块贴着页边看着像排版出错，
                    # 底纹（\cbpat4）会跟着段落缩进一起收进来，仍然是一条整块
                    head = (r'\pard\plain\s7\cbpat4\li210\ri210\loch\f%d\hich\f%d\dbch\f%d\fs%d\fi0 '
                            % (F_CODE, F_CODE, F_SONG, max(18, self.size - 3)))
                    out.append(head + rtf_escape(line.replace('\t', '    '))
                               + r'\par' + '\n')
            elif t == 'table':
                out.append(self._table(b))
            elif t == 'math':
                try:
                    omml, _ = mathml_to_omml(b.get('mathml') or '')
                except Exception:
                    fb = (b.get('latex') or '').strip()
                    if fb:
                        out.append((r'\pard\plain\qc\s0\loch\f%d\hich\f%d\dbch\f%d\fs%d '
                                    % (F_BODY, F_BODY, F_SONG, self.size))
                                   + '{\\i %s}' % rtf_escape(fb) + r'\par' + '\n')
                    continue
                out.append((r'\pard\plain\qc\s0\loch\f%d\hich\f%d\dbch\f%d\fs%d '
                            % (F_BODY, F_BODY, F_SONG, self.size))
                           + omml_to_rtf(omml, True) + r'\par' + '\n')
        return ''.join(out)

    def build(self):
        body = self.body()
        if not body.strip():
            return None
        head = (r'{\rtf1\ansi\ansicpg936\deff0\uc1'
                + self._font_table()
                + r'{\colortbl;\red0\green0\blue0;\red0\green0\blue255;'
                  r'\red242\green242\blue242;\red247\green247\blue248;'
                  r'\red216\green216\blue222;}'
                + self._stylesheet())
        # listtable 必须出现在正文之前
        r = Rtf()
        r.w(head)
        if self.lists:
            r.w(r'{\*\listtable' + ''.join(self.lists) + '}')
            r.w(r'{\*\listoverridetable' + ''.join(self.overrides) + '}')
        r.w(body)
        r.w('}')
        return ''.join(r.parts)
