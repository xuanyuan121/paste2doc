# -*- coding: utf-8 -*-
"""内容直贴的本地桥接程序。

浏览器扩展写不了两种东西：WPS 的私有剪贴板格式，和 Word 认的 RTF 富文本。
所以最后一步交给这个进程：

    扩展把「文档模型」发过来
      -> 打成 docx，塞进 "Kingsoft WPS 9.0 Format"   （WPS 文字认这个）
      -> 写成 RTF，塞进 "Rich Text Format"            （Word 认这个）
      -> 再放一份纯文本                                （任何地方都能粘）
    WPS / Word 里 Ctrl+V，拿到的是一份排好版、结构真实的文档。

浏览器按需拉起，处理完就退出，没有常驻窗口，也没有托盘图标。

命令行（调试用）：
    python paste2doc_host.py --host              被浏览器拉起
    python paste2doc_host.py --model m.json      把模型文件写进剪贴板
    python paste2doc_host.py --render m.json d.docx 只导出文件，不碰剪贴板
"""
import base64
import ctypes
import ctypes.wintypes as wt
import json
import os
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from p2d_docx import DocxBuilder          # noqa: E402
from p2d_rtf import RtfBuilder            # noqa: E402

WPS_FORMAT_NAME = 'Kingsoft WPS 9.0 Format'
RTF_FORMAT_NAME = 'Rich Text Format'

u32 = ctypes.windll.user32
k32 = ctypes.windll.kernel32

CF_UNICODETEXT = 13
GMEM_MOVEABLE = 0x0002

u32.RegisterClipboardFormatW.restype = wt.UINT
u32.OpenClipboard.argtypes = [wt.HWND]
u32.SetClipboardData.argtypes = [wt.UINT, wt.HANDLE]
u32.SetClipboardData.restype = wt.HANDLE
k32.GlobalAlloc.argtypes = [wt.UINT, ctypes.c_size_t]
k32.GlobalAlloc.restype = wt.HANDLE
k32.GlobalLock.argtypes = [wt.HANDLE]
k32.GlobalLock.restype = ctypes.c_void_p
k32.GlobalUnlock.argtypes = [wt.HANDLE]


def write_clipboard(entries):
    """entries: [(格式名 / None 表示纯文本, bytes)]，一次性写入，避免中间态。"""
    for _ in range(8):
        if u32.OpenClipboard(None):
            break
        time.sleep(0.1)
    else:
        raise RuntimeError('剪贴板被其他程序占用')
    try:
        u32.EmptyClipboard()
        for name, payload in entries:
            fmt = CF_UNICODETEXT if name is None else u32.RegisterClipboardFormatW(name)
            h = k32.GlobalAlloc(GMEM_MOVEABLE, len(payload))
            p = k32.GlobalLock(h)
            ctypes.memmove(p, payload, len(payload))
            k32.GlobalUnlock(h)
            if not u32.SetClipboardData(fmt, h):
                raise RuntimeError('SetClipboardData 失败：%s' % (name or 'TEXT'))
    finally:
        u32.CloseClipboard()


def render(model):
    """模型 -> (docx bytes, rtf str)。"""
    docx = DocxBuilder(model).build()
    rtf = RtfBuilder(model).build()
    return docx, rtf


def copy_document(model, plain=''):
    docx, rtf = render(model)
    entries = []
    if docx:
        entries.append((WPS_FORMAT_NAME, docx))
    if rtf:
        entries.append((RTF_FORMAT_NAME, rtf.encode('ascii', 'backslashreplace')))
    text = plain or model.get('plain') or ''
    entries.append((None, text.encode('utf-16-le') + b'\x00\x00'))
    write_clipboard(entries)
    return len(docx or b''), len(rtf or '')


# ------------------------------------------------------- Native Messaging

def _read_exact(stream, n):
    buf = b''
    while len(buf) < n:
        chunk = stream.read(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def read_message(stream):
    head = _read_exact(stream, 4)
    if not head:
        return None
    size = int.from_bytes(head, 'little')
    if size <= 0 or size > 64 * 1024 * 1024:
        return None
    body = _read_exact(stream, size)
    if body is None:
        return None
    return json.loads(body.decode('utf-8'))


def write_message(stream, obj):
    data = json.dumps(obj, ensure_ascii=False).encode('utf-8')
    stream.write(len(data).to_bytes(4, 'little'))
    stream.write(data)
    stream.flush()


def handle(msg):
    action = msg.get('action')
    try:
        if action == 'ping':
            return {'ok': True, 'app': 'paste2doc', 'version': 1}
        if action == 'copy-doc':
            model = msg.get('model') or {}
            blocks = model.get('blocks') or []
            if not blocks:
                return {'ok': False, 'error': '没有可复制的内容'}
            docx_len, rtf_len = copy_document(model, msg.get('plain') or '')
            return {'ok': True, 'docx': docx_len, 'rtf': rtf_len,
                    'blocks': len(blocks)}
        return {'ok': False, 'error': 'unknown action: %s' % action}
    except Exception as e:
        return {'ok': False, 'error': '%s: %s' % (type(e).__name__, e)}


IDLE_EXIT_SECONDS = 60


def run_host():
    inp = sys.stdin.buffer
    out = sys.stdout.buffer
    sys.stdout = sys.stderr           # stdout 是协议通道，不能混进 print
    last = [time.time()]

    def reaper():
        while True:
            time.sleep(5)
            if time.time() - last[0] > IDLE_EXIT_SECONDS:
                os._exit(0)

    threading.Thread(target=reaper, daemon=True).start()

    while True:
        try:
            msg = read_message(inp)
        except Exception as e:
            try:
                write_message(out, {'ok': False, 'error': 'bad message: %s' % e})
            except Exception:
                pass
            return
        if msg is None:
            return
        last[0] = time.time()
        try:
            write_message(out, handle(msg))
        except Exception:
            return
        last[0] = time.time()


def main():
    args = sys.argv[1:]
    if '--host' in args:
        run_host()
        return

    model_path = None
    out_path = None
    for i, a in enumerate(args):
        if a == '--model' and i + 1 < len(args):
            model_path = args[i + 1]
        if a == '--render' and i + 1 < len(args):
            out_path = args[i + 1]

    if not model_path:
        print(__doc__)
        return
    with open(model_path, encoding='utf-8') as f:
        model = json.load(f)

    if out_path:
        docx, rtf = render(model)
        base, ext = os.path.splitext(out_path)
        if docx:
            with open(base + '.docx', 'wb') as f:
                f.write(docx)
        if rtf:
            with open(base + '.rtf', 'wb') as f:
                f.write(rtf.encode('ascii', 'backslashreplace'))
        print('已导出：%s.docx / .rtf' % base)
        return

    n1, n2 = copy_document(model)
    print('已写入剪贴板：docx %d 字节，rtf %d 字符' % (n1, n2))


if __name__ == '__main__':
    main()
