# -*- coding: utf-8 -*-
"""内容直贴 · 本地组件安装程序。

由「安装本地组件.bat」调用；也可以自己跑（python install_host.py）。

三步：

    1. 挑一个 Python 来跑本地组件
       优先 py 启动器 / 官网装的 Python，其次 PATH 里的，
       最后才用便携版（那种随软件一起装、卸载就没了的环境）。
    2. 自检
       真拿挑出来的解释器 import 一次宿主模块，确认它能跑，而不是只看版本号。
    3. 注册
       写启动脚本和宿主清单，登记到 Chrome / Edge / Chromium。

    全部写在 HKCU（当前用户）下，不需要管理员权限。

为什么安装时要扫浏览器：开发者模式装的扩展靠 manifest 里的 key 固定 ID，但**商店版
的 ID 由商店分配**，和开发者版不一样。宿主清单里的 allowed_origins 只要对不上，
扩展就连不上本地组件 —— 表现是「WPS 粘出来是纯文本」，而 Word 那条路正常，
排查起来很费劲。所以这里自己扫一遍浏览器，把实际装着的 ID 全放行。

    python install_host.py                  正常安装
    python install_host.py --dry-run        只检查，不写文件、不动注册表
    python install_host.py --python <路径>   指定用哪个 Python 跑宿主
    python install_host.py --allow <扩展ID>  手动补一个（排障用）
"""
import glob
import json
import os
import subprocess
import sys
import winreg

HOST_NAME = 'com.paste2doc.host'
EXT_ID = 'cpjmadcbfhaghodkkihjnbhjohgdaggm'
MIN_VER = (3, 8)
BROWSERS = [
    ('Chrome', r'Software\Google\Chrome\NativeMessagingHosts'),
    ('Edge', r'Software\Microsoft\Edge\NativeMessagingHosts'),
    ('Chromium', r'Software\Chromium\NativeMessagingHosts'),
]
# 商店版 / 自编译版的 ID 都可能不同，这几个 profile 根目录下扫一遍
PROFILE_ROOTS = [
    os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Microsoft\Edge\User Data'),
    os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Google\Chrome\User Data'),
    os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Chromium\User Data'),
]
MARK = '内容直贴'          # 在我们的 _locales 里找这个标记，认得出就是本扩展

HERE = os.path.dirname(os.path.abspath(__file__))
ENTRY = os.path.join(HERE, 'paste2doc_host.py')

CREATE_NO_WINDOW = 0x08000000

# 中文控制台（cp936）容不下个别符号时别崩，替换掉就是
try:
    sys.stdout.reconfigure(errors='replace')
except (AttributeError, ValueError):
    pass

DASH = '─' * 58


# --------------------------------------------------------------- 小工具

def say(msg=''):
    print(msg)
    sys.stdout.flush()


def head(title):
    say()
    say('  ' + title)
    say('  ' + DASH)


def ok(msg, indent=8):
    say(' ' * indent + '√ ' + msg)


def warn(msg, indent=8):
    say(' ' * indent + '! ' + msg)


def run(cmd, timeout=30, cwd=None):
    """跑个子进程，绝不弹黑框。返回 (returncode, stdout, stderr)。"""
    kwargs = {}
    if os.name == 'nt':
        kwargs['creationflags'] = CREATE_NO_WINDOW
    env = os.environ.copy()
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env.pop('PYTHONPATH', None)
    try:
        p = subprocess.run(cmd, capture_output=True, timeout=timeout, cwd=cwd, env=env,
                           encoding='utf-8', errors='replace', **kwargs)
        return p.returncode, (p.stdout or '').strip(), (p.stderr or '').strip()
    except Exception as e:                      # noqa: BLE001
        return -1, '', str(e)


def probe(cmd):
    """cmd 是 ['py', '-3'] 这种前缀。返回 {exe, ver, how} 或 None。"""
    code, out, _ = run(cmd + ['-c', 'import sys;print("%d|%d|%s" % '
                                     '(sys.version_info[0], sys.version_info[1], sys.executable))'])
    if code != 0 or not out or '|' not in out:
        return None
    parts = out.split('|', 2)
    if len(parts) < 3:
        return None
    try:
        ver = (int(parts[0]), int(parts[1]))
    except ValueError:
        return None
    exe = parts[2].strip()
    if not exe or not os.path.isfile(exe):
        return None
    return {'exe': exe, 'ver': ver}


def sketchy(path):
    """便携版 / 应用商店占位符：装完可能被删，或者根本不是真的解释器。"""
    low = path.lower()
    return ('.workbuddy' in low) or ('windowsapps' in low) or ('\\temp\\' in low)


def candidates(manual=()):
    """把所有找得到的 Python 3 收进来，按「可信度」排好。"""
    found = []
    cmds = [('py 启动器', ['py', '-3']), ('PATH 里的 python', ['python']),
            ('PATH 里的 python3', ['python3'])]
    for path in manual:
        cmds.insert(0, ('手动指定', [path]))

    for how, cmd in cmds:
        got = probe(cmd)
        if got:
            got['how'] = how
            found.append(got)

    pats = [
        os.path.join(os.environ.get('LOCALAPPDATA', ''), r'Programs\Python\Python3*\python.exe'),
        os.path.join(os.environ.get('ProgramFiles', ''), r'Python3*\python.exe'),
        os.path.join(os.environ.get('ProgramFiles(x86)', ''), r'Python3*\python.exe'),
        r'C:\Python3*\python.exe',
    ]
    for pat in pats:
        for exe in sorted(glob.glob(pat), reverse=True):
            got = probe([exe])
            if got:
                got['how'] = '已安装的 Python'
                found.append(got)

    # 最后兜底：正在跑本脚本的这个解释器（便携版也无所谓，能用就行）
    got = probe([sys.executable])
    if got:
        got['how'] = '当前解释器'
        found.append(got)

    out, seen = [], set()
    for c in found:
        key = os.path.normcase(c['exe'])
        if key in seen:
            continue
        seen.add(key)
        c['bad'] = sketchy(c['exe'])
        out.append(c)

    good = [c for c in out if c['ver'] >= MIN_VER]
    good.sort(key=lambda c: (c['bad'], -c['ver'][0], -c['ver'][1]))
    return good


# ------------------------------------------------------------ 宿主清单

def looks_like_us(path):
    """这个目录是不是「内容直贴」的一个版本目录（商店版也会落成这个样子）。"""
    if not path or not os.path.isdir(path):
        return False
    for loc in ('zh_CN', 'en'):
        p = os.path.join(path, '_locales', loc, 'messages.json')
        if not os.path.isfile(p):
            continue
        try:
            with open(p, encoding='utf-8') as f:
                txt = f.read()
        except OSError:
            continue
        if MARK in txt or 'Paste2Doc' in txt or 'paste2doc' in txt.lower():
            return True
    return False


def read_json(path):
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def ids_from_profiles():
    """扫各浏览器 profile，把「装载着的本扩展」的 ID 找出来。"""
    found = []
    for root in PROFILE_ROOTS:
        if not os.path.isdir(root):
            continue
        try:
            names = os.listdir(root)
        except OSError:
            continue
        for name in names:
            prof = os.path.join(root, name)
            if not os.path.isdir(prof):
                continue
            if name != 'Default' and not name.startswith('Profile'):
                continue

            # 1) 已装扩展登记在 Preferences / Secure Preferences 里
            for fname in ('Preferences', 'Secure Preferences'):
                data = read_json(os.path.join(prof, fname))
                if not isinstance(data, dict):
                    continue
                settings = (data.get('extensions') or {}).get('settings') or {}
                if not isinstance(settings, dict):
                    continue
                for ext_id, info in settings.items():
                    if not isinstance(info, dict):
                        continue
                    path = info.get('path') or ''
                    if 'paste2doc' in path.lower() or looks_like_us(path):
                        if ext_id not in found:
                            found.append(ext_id)

            # 2) 商店版的实体在 Extensions\<id>\<version>，直接按目录认
            ext_root = os.path.join(prof, 'Extensions')
            if not os.path.isdir(ext_root):
                continue
            try:
                ids = os.listdir(ext_root)
            except OSError:
                continue
            for ext_id in ids:
                base = os.path.join(ext_root, ext_id)
                if not os.path.isdir(base):
                    continue
                try:
                    versions = os.listdir(base)
                except OSError:
                    continue
                for ver in versions:
                    if looks_like_us(os.path.join(base, ver)):
                        if ext_id not in found:
                            found.append(ext_id)
                        break
    return found


def extra_ids(manual=()):
    """开发者版 ID + 扫出来的商店版 ID + allowed_ids.txt + 命令行补的。"""
    ids = [EXT_ID]
    path = os.path.join(HERE, 'allowed_ids.txt')
    if os.path.exists(path):
        with open(path, encoding='utf-8') as f:
            lines = f.readlines()
    else:
        lines = []
    lines = list(lines) + list(manual)
    for line in lines:
        s = str(line).split('#')[0].strip().replace('chrome-extension://', '').strip('/ ')
        if len(s) == 32 and all('a' <= c <= 'p' for c in s) and s not in ids:
            ids.append(s)
    return ids


def write_bat(python, script, bat):
    """浏览器拉起宿主时没有工作目录，也没有 PATH 保证，所以路径写死。

    但**不写脚本的绝对路径**：安装目录可能带中文（「内容直贴-本地组件」），
    而 .bat 是 cmd 用系统 ANSI 代码页读的，写进去容易变问号。改成先 cd 到
    自己所在的目录、再用相对文件名，就完全绕开了这件事。

    另外要挡住 __pycache__：宿主脚本就在扩展目录里，一旦生成这个目录，
    Chrome 下次启动会以「名字以下划线开头」为由拒绝加载整个扩展。
    """
    content = ('@echo off\r\n'
               'rem keep __pycache__ out of the extension folder\r\n'
               'set PYTHONDONTWRITEBYTECODE=1\r\n'
               'cd /d "%%~dp0"\r\n'
               '"%s" "%s" --host %%*\r\n' % (python, os.path.basename(script)))
    # 解释器路径也可能带中文（用户名是汉字），按系统 ANSI 页写；
    # 万一转不了就退回 UTF-8 —— 那种机器上中文路径本来也得靠 UTF-8 才认得。
    for enc in ('mbcs', 'utf-8'):
        try:
            blob = content.encode(enc)
        except (UnicodeEncodeError, LookupError):
            continue
        with open(bat, 'wb') as f:
            f.write(blob)
        return True
    return False


# ------------------------------------------------------------------ 主流程

def selftest(exe):
    """真跑一次宿主模块：光看版本号不算数，import 不进去照样白装。"""
    code, out, err = run([exe, '-c',
                          'import sys;sys.path.insert(0,%r);'
                          'import paste2doc_host as h;'
                          'print(h.WPS_FORMAT_NAME)' % HERE], timeout=40, cwd=HERE)
    if code == 0 and 'Kingsoft WPS' in out:
        return True, ''
    return False, (err or out or '未知错误').splitlines()[-1][:160]


def main():
    argv = sys.argv[1:]
    dry = '--dry-run' in argv
    manual, allow = [], []
    for i, a in enumerate(argv):
        if a == '--python' and i + 1 < len(argv):
            manual.append(argv[i + 1])
        elif a.startswith('--python='):
            manual.append(a.split('=', 1)[1])
        elif a == '--allow' and i + 1 < len(argv):
            allow.append(argv[i + 1])
        elif a.startswith('--allow='):
            allow.append(a.split('=', 1)[1])

    head('内容直贴 · 安装本地组件')
    say('  它只做一件事：让浏览器能把回答写成 WPS 文字 / Word 认得的')
    say('  剪贴板格式。全部装在你自己的账户下，不需要管理员权限。')
    if dry:
        warn('试运行模式：只检查，不写任何文件、不改注册表', indent=2)

    if not os.path.exists(ENTRY):
        say()
        warn('找不到 paste2doc_host.py，安装中止。', indent=2)
        say('     这个文件必须和本安装程序放在同一个文件夹里。')
        return 1

    # ---- 1/3 解释器 ----------------------------------------------------
    head('[1/3] 选一个 Python 来跑它')
    cands = candidates(manual)
    if not cands:
        warn('没找到可用的 Python 3（需要 3.8 或更新）。', indent=2)
        say('     请重新双击「安装本地组件.bat」，让它帮你下一个。')
        return 1
    pick = cands[0]
    ok('Python %d.%d' % pick['ver'])
    say(' ' * 10 + pick['exe'])
    say(' ' * 10 + '（%s）' % pick['how'])
    if pick['bad']:
        warn('这是便携版环境，装这类软件换了地方它可能就没了；'
             '想稳一点就装一个官网的 Python。')
    if len(cands) > 1:
        others = '、'.join('Python %d.%d' % c['ver'] for c in cands[1:3])
        say(' ' * 10 + '（另外还看到 %s）' % others)

    # ---- 2/3 自检 ------------------------------------------------------
    head('[2/3] 自检')
    good, err = selftest(pick['exe'])
    if not good:
        warn('这个 Python 跑不起来本地组件：' + err, indent=2)
        for c in cands[1:]:
            say(' ' * 6 + '换个试试：' + c['exe'])
            g2, e2 = selftest(c['exe'])
            if g2:
                pick = c
                good = True
                ok('换成了 Python %d.%d' % c['ver'])
                break
            say(' ' * 10 + '同样不行：' + e2)
        if not good:
            say()
            warn('这台机器上的 Python 都跑不起来，安装中止。', indent=2)
            return 1
    ok('宿主程序能正常启动')
    ok('剪贴板格式名可用')

    # ---- 3/3 注册 ------------------------------------------------------
    head('[3/3] 注册到浏览器')
    bat = os.path.join(HERE, 'host.bat')
    manifest_path = os.path.join(HERE, HOST_NAME + '.json')

    scanned = ids_from_profiles()
    ids = extra_ids(list(scanned) + allow)
    if scanned:
        say('       扫到浏览器里装着的扩展：%s' % '、'.join(scanned))
    else:
        say('       浏览器里还没装这个扩展（装完再跑一次本程序即可）')

    manifest = {
        'name': HOST_NAME,
        'description': 'Paste2Doc native host',
        'path': bat,
        'type': 'stdio',
        'allowed_origins': ['chrome-extension://%s/' % i for i in ids],
    }

    if dry:
        say()
        say('   （试运行）会写：%s' % bat)
        say('   （试运行）会写：%s' % manifest_path)
        say('   （试运行）会注册：Chrome / Edge / Chromium')
        say('   （试运行）放行的扩展 ID：%s' % '、'.join(ids))
        say()
        say('  试运行结束，什么都没改。')
        return 0

    write_bat(pick['exe'], ENTRY, bat)
    ok('启动脚本  host.bat')
    with open(manifest_path, 'w', encoding='utf-8') as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    ok('宿主清单  %s.json' % HOST_NAME)

    names = []
    for label, key in BROWSERS:
        try:
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key + '\\' + HOST_NAME) as k:
                winreg.SetValueEx(k, '', 0, winreg.REG_SZ, manifest_path)
            names.append(label)
        except OSError as e:
            warn('%s 注册失败：%s' % (label, e))
    if not names:
        say()
        warn('一个浏览器都没注册成功，安装没完成。', indent=2)
        return 1
    ok('已登记到 ' + ' / '.join(names))

    # ---- 收尾 ----------------------------------------------------------
    say()
    say('  ' + DASH)
    say('  装好了。回到扩展的侧边栏，点一下右上角的「未安装」，')
    say('  等它变成「已连接」就能用了。')
    say()
    say('  · 扩展还没装？先去浏览器扩展页「加载已解压的扩展程序」，')
    say('    装完再双击一次本程序 —— 那一步会把新扩展的 ID 收进白名单。')
    say('  · 想卸载本地组件：双击同一个文件夹里的「卸载本地组件.bat」。')
    say('  · 想确认好不好使：双击「自检.bat」，它会往剪贴板放一份样例。')
    say()
    return 0


if __name__ == '__main__':
    sys.exit(main())
