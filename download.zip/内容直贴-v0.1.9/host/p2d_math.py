# -*- coding: utf-8 -*-
"""MathML -> OMML -> （可选）RTF 公式控制字。

网页里的公式在扩展侧已经由 KaTeX 统一渲染成 MathML（只留 MathML，不带 HTML），
这里负责把它变成 Word / WPS 认识的原生公式：

    MathML  --(OMML)-->  docx 正文里的 m:oMath     —— WPS 走这条路
    OMML    --(RTF) -->  \\mmath 组               —— Word 走这条路

OMML 这一段的规则是照 WPS 的实际表现调的（见 formula2word 的实测结论）：
WPS 不认 m:nary 的 limLoc，上下限一律跑到右侧，所以求和/连乘一律用
m:limLow / m:limUpp 手工搭出来，积分则用 m:sSubSup。两种结构在 Word 里同样正确。
"""
import re
import xml.etree.ElementTree as ET
from html.entities import name2codepoint

from p2d_escape import rtf_escape

MML_NS = 'http://www.w3.org/1998/Math/MathML'
W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
M_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/math'

# 求和 / 连乘这类大算符：上下限放符号上下；积分放右侧
NARY_UNDOVR = set('∑∏∐⋃⋂⋁⋀⨁⨂⨀⨄⨆⨈')
NARY_SUBSUP = set('∫∬∭∮∯∰∱∲∳')
OPEN_CHARS = set('([{⟨|‖⌈⌊')
CLOSE_CHARS = set(')]}⟩|‖⌉⌋')

ACCENTS = {
    '^': '\u0302', 'ˆ': '\u0302', '~': '\u0303', '˜': '\u0303',
    '¯': '\u0304', '‾': '\u0304', '→': '\u20d7', '˙': '\u0307',
    '¨': '\u0308', 'ˇ': '\u030c', '`': '\u0300', '´': '\u0301',
}

_DISPLAY = False
_SIZE = None      # 正文字号（半磅），用来让公式和正文一样大


def _tag(el):
    t = el.tag
    if isinstance(t, str) and t.startswith('{'):
        return t.split('}', 1)[1]
    return t or ''


def _text(el):
    return ''.join(el.itertext()).strip() if el is not None else ''


def _esc(s):
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def _attr(el, name, default=''):
    return el.get(name, default) if el is not None else default


def _run(text, plain=False, normal_text=False):
    if text == '':
        return ''
    if normal_text:
        rpr = '<m:rPr><m:nor/></m:rPr>'
    elif plain:
        rpr = '<m:rPr><m:sty m:val="p"/></m:rPr>'
    else:
        rpr = ''
    # 显式给字号，否则 WPS / Word 会把公式排得比正文小一号
    wrpr = ''
    if _SIZE:
        wrpr = ('<w:rPr><w:rFonts w:ascii="Cambria Math" w:hAnsi="Cambria Math"'
                ' w:eastAsia="宋体"/><w:sz w:val="%d"/><w:szCs w:val="%d"/></w:rPr>'
                % (_SIZE, _SIZE))
    return '<m:r>%s%s<m:t xml:space="preserve">%s</m:t></m:r>' % (rpr, wrpr, _esc(text))


def _join(parts):
    return ''.join(p for p in parts if p)


def _content(el):
    """把一个节点渲染成可放进 m:e / m:num / m:den 的内容。"""
    if el is None:
        return ''
    t = _tag(el)
    if t in ('mrow', 'semantics', 'math', 'mstyle', 'mpadded', 'merror'):
        return _children(el)
    return _join(_node(el))


def _children(el):
    return _join([_join(_node(n)) for n in el])


def _lim(lower, upper, base, ch):
    """上下限结构。

    WPS 不认 m:nary 的 limLoc —— 无论怎么设，上下限都会跑到符号右侧当角标。
    实测只有显式的 m:limLow / m:limUpp 才能在 WPS 里显示成正上下方，
    而这套结构在 Word 里同样正确。
    """
    if ch in NARY_SUBSUP or (ch in NARY_UNDOVR and not _DISPLAY):
        return ('<m:sSubSup><m:e>%s</m:e><m:sub>%s</m:sub><m:sup>%s</m:sup></m:sSubSup>'
                % (_content(base), lower, upper))
    inner = _content(base)
    if upper:
        inner = '<m:limUpp><m:e>%s</m:e><m:lim>%s</m:lim></m:limUpp>' % (inner, upper)
    if lower:
        return '<m:limLow><m:e>%s</m:e><m:lim>%s</m:lim></m:limLow>' % (inner, lower)
    return inner


def _node(el):
    """渲染单个节点，返回 OMML 片段列表。"""
    t = _tag(el)
    variant = el.get('mathvariant', '')

    if t == 'mi':
        return [_run(_text(el), plain=(variant == 'normal'))]
    if t == 'mn':
        return [_run(_text(el), plain=True)]
    if t == 'mo':
        s = _text(el)
        return [_run(s, plain=True)] if s else []
    if t == 'mtext':
        return [_run(_text(el), normal_text=True)]
    if t == 'mspace':
        return [_run(' ', plain=True)]
    if t in ('mstyle', 'mpadded', 'merror', 'mphantom', 'menclose', 'ms', 'mtd', 'mtr'):
        return [_children(el)]
    if t == 'mrow':
        return [_fenced_or_children(el)]
    if t == 'semantics':
        for c in el:
            if _tag(c) != 'annotation':
                return [_content(c)]
        return []
    if t == 'annotation':
        return []
    if t == 'mfrac':
        kids = list(el)
        return ['<m:f><m:num>%s</m:num><m:den>%s</m:den></m:f>'
                % (_content(kids[0]) if len(kids) > 0 else '',
                   _content(kids[1]) if len(kids) > 1 else '')]
    if t == 'msqrt':
        return ['<m:rad><m:radPr><m:degHide m:val="1"/></m:radPr>'
                '<m:deg/><m:e>%s</m:e></m:rad>' % _children(el)]
    if t == 'mroot':
        kids = list(el)
        return ['<m:rad><m:deg>%s</m:deg><m:e>%s</m:e></m:rad>'
                % (_content(kids[1]) if len(kids) > 1 else '',
                   _content(kids[0]) if len(kids) > 0 else '')]
    if t == 'msup':
        kids = list(el)
        return ['<m:sSup><m:e>%s</m:e><m:sup>%s</m:sup></m:sSup>'
                % (_content(kids[0]) if len(kids) > 0 else '',
                   _content(kids[1]) if len(kids) > 1 else '')]
    if t == 'msub':
        kids = list(el)
        return ['<m:sSub><m:e>%s</m:e><m:sub>%s</m:sub></m:sSub>'
                % (_content(kids[0]) if len(kids) > 0 else '',
                   _content(kids[1]) if len(kids) > 1 else '')]
    if t == 'msubsup':
        kids = list(el)
        return ['<m:sSubSup><m:e>%s</m:e><m:sub>%s</m:sub><m:sup>%s</m:sup></m:sSubSup>'
                % (_content(kids[0]) if len(kids) > 0 else '',
                   _content(kids[1]) if len(kids) > 1 else '',
                   _content(kids[2]) if len(kids) > 2 else '')]
    if t in ('munder', 'mover', 'munderover'):
        kids = list(el)
        if not kids:
            return []
        base = kids[0]
        ch = _text(base) if _tag(base) == 'mo' else ''
        lower = upper = ''
        if t in ('munder', 'munderover') and len(kids) > 1:
            lower = _content(kids[1])
        if t == 'mover' and len(kids) > 1:
            upper = _content(kids[1])
            if _tag(kids[1]) == 'mo' and _text(kids[1]) in ACCENTS:
                return ['<m:acc><m:accPr><m:chr m:val="%s"/></m:accPr>'
                        '<m:e>%s</m:e></m:acc>' % (ACCENTS[_text(kids[1])], _content(base))]
        if t == 'munderover' and len(kids) > 2:
            upper = _content(kids[2])
        return [_lim(lower, upper, base, ch)]
    if t == 'mtable':
        return [_table(el)]
    if t == 'mfenced':
        beg = el.get('open', '(')
        end = el.get('close', ')')
        sep = el.get('separators', ',')
        items = [_content(c) for c in el]
        inner = _join(items)
        if sep and len(items) > 1:
            inner = (_run(sep[0], plain=True)).join(items)
        return ['<m:d><m:dPr><m:begChr m:val="%s"/><m:endChr m:val="%s"/>'
                '<m:grow m:val="1"/></m:dPr><m:e>%s</m:e></m:d>'
                % (_esc(beg), _esc(end), inner)]
    return [_children(el)]


def _fenced_or_children(el):
    """mrow 若形如 ( ...matrix... )，转成 OMML 的分隔符结构 m:d。"""
    kids = [k for k in el if _tag(k) != 'annotation']
    if len(kids) >= 3:
        first, last = kids[0], kids[-1]
        mid = kids[1:-1]
        if (_tag(first) == 'mo' and _tag(last) == 'mo'
                and len(mid) == 1 and _tag(mid[0]) == 'mtable'):
            beg, end = _text(first), _text(last)
            if beg in OPEN_CHARS and end in CLOSE_CHARS:
                return ('<m:d><m:dPr><m:begChr m:val="%s"/><m:endChr m:val="%s"/>'
                        '<m:grow m:val="1"/></m:dPr><m:e>%s</m:e></m:d>'
                        % (_esc(beg), _esc(end), _content(mid[0])))
    return _children(el)


def _table(el):
    rows = [r for r in el if _tag(r) == 'mtr']
    ncol = 1
    for r in rows:
        ncol = max(ncol, len([c for c in r if _tag(c) == 'mtd']))
    mcpr = ('<m:mPr><m:mcs><m:mc><m:mcPr><m:count m:val="%d"/>'
            '<m:mcJc m:val="center"/></m:mcPr></m:mc></m:mcs></m:mPr>' % ncol)
    parts = ['<m:m>' + mcpr]
    for r in rows:
        cells = [c for c in r if _tag(c) == 'mtd']
        parts.append('<m:mr>')
        for c in cells:
            parts.append('<m:e>' + _content(c) + '</m:e>')
        parts.append('</m:mr>')
    parts.append('</m:m>')
    return _join(parts)


_ENT_RE = re.compile(r'&([a-zA-Z][a-zA-Z0-9]{1,31});')
_BARE_AMP = re.compile(r'&(?!#\d+;|#x[0-9a-fA-F]+;|amp;|lt;|gt;|quot;|apos;)')


def fix_entities(s):
    """网页里的 MathML 是「HTML 里的 XML」。

    KaTeX 遇到 \\ 、\\, 这类间距会输出 &nbsp;，而 XML 解析器不认这个实体，
    一句 &nbsp; 就让整条公式解析失败 —— 表现就是「公式凭空消失」。
    这里把所有 HTML 具名实体换成数字引用，顺便把落单的 & 转义掉。
    """
    def rep(m):
        cp = name2codepoint.get(m.group(1))
        return '&#%d;' % cp if cp else ''

    s = _ENT_RE.sub(rep, s)
    return _BARE_AMP.sub('&amp;', s)


def mathml_to_omml(mathml, size=None):
    """返回 (omml, is_display)。omml 不含最外层的 m:oMath 包装。"""
    global _DISPLAY, _SIZE
    _SIZE = size
    root = ET.fromstring(fix_entities(mathml.strip()))
    display = (root.get('display') == 'block')
    _DISPLAY = display
    body = _content(root)
    return body, display


# --------------------------------------------------------------- OMML -> RTF
#
# Word 2007+ 的 RTF 有一整套 \m* 控制字，写法照 Word 自己导出的 RTF 抄：
#   {\mmath{\*\moMathPara {\moMathParaPr\mjc2}{\*\moMath ...}}}
# 每个数学 run 是 {\mr\mscr0\mstyN 文字}，\msty 0=正体 2=斜体。
# 有了它，粘到 Word 里的才是能双击编辑的原生公式，而不是一张图或者一串 LaTeX。

RFONT = '\\f4'


def _rf_escape(s):
    """数学 run 里的文字一律走 \\uN?。

    实测：Word 的 RTF 数学解析器只认 Unicode 转义，写 GBK 的 \\'hh
    会被当成 Latin-1 渲染成乱码（Δ -> ¦¤）。正文那边相反，GBK 才正常。
    """
    out = []
    for ch in s:
        if ch in '\\{}':
            out.append('\\' + ch)
        elif ch == '\n':
            out.append(' ')
        elif ord(ch) < 128:
            out.append(ch)
        else:
            out.append('\\u%d?' % (ord(ch) & 0xFFFF))
    return ''.join(out)


def _rpr_of(el):
    """m:rPr 里有没有 m:sty m:val='p' / m:nor。"""
    rpr = None
    for c in el:
        if _tag(c) == 'rPr':
            rpr = c
            break
    if rpr is None:
        return 2, False
    nor = False
    plain = False
    for c in rpr:
        tg = _tag(c)
        if tg == 'nor':
            nor = True
        if tg == 'sty' and c.get('{%s}val' % M_NS, c.get('m:val', '')) == 'p':
            plain = True
    return (0 if (nor or plain) else 2), nor


def _mrun(el):
    txt = ''
    for c in el:
        if _tag(c) == 't':
            txt += c.text or ''
    if txt == '':
        return ''
    sty, nor = _rpr_of(el)
    style = '\\msty0' if sty == 0 else '\\msty2'
    italic = '\\i' if sty == 2 and not nor else ''
    # \mr 不能省：没有它 Word 的数学解析器把这个组当成普通文字 run，
    # 里面的 \uN? 会把替换字符 ? 直接显示出来（Δ -> ?）。带上 \mr 才是数学 run。
    return '{%s\\mr\\mscr0%s%s %s}' % (italic, style, RFONT, _rf_escape(txt))


def _mtree(el):
    t = _tag(el)
    if t == 'r':
        return _mrun(el)
    if t in ('oMath', 'e', 'num', 'den', 'lim', 'deg', 'sub', 'sup', 'fName'):
        return ''.join(_mtree(c) for c in el)
    if t == 'f':
        return ('{\\mf{\\mfPr{\\mctrlPr%s }}{\\mnum{%s}}{\\mden{%s}}}'
                % (RFONT, _child(el, 'num'), _child(el, 'den')))
    if t == 'sSup':
        return ('{\\msSup{\\msSupPr{\\mctrlPr%s }}{\\me{%s}}{\\msup{%s}}}'
                % (RFONT, _child(el, 'e'), _child(el, 'sup')))
    if t == 'sSub':
        return ('{\\msSub{\\msSubPr{\\mctrlPr%s }}{\\me{%s}}{\\msub{%s}}}'
                % (RFONT, _child(el, 'e'), _child(el, 'sub')))
    if t == 'sSubSup':
        return ('{\\msSubSup{\\msSubSupPr{\\mctrlPr%s }}{\\me{%s}}{\\msub{%s}}{\\msup{%s}}}'
                % (RFONT, _child(el, 'e'), _child(el, 'sub'), _child(el, 'sup')))
    if t == 'rad':
        return ('{\\mrad{\\mradPr{\\mctrlPr%s }}{\\mdeg{%s}}{\\me{%s}}}'
                % (RFONT, _child(el, 'deg'), _child(el, 'e')))
    if t == 'acc':
        chr_ = _chr_of(el, 'accPr')
        chr_part = '{\\mchr %s}' % _rf_escape(chr_) if chr_ else ''
        return ('{\\macc{\\maccPr{%s\\mctrlPr%s }}{\\me{%s}}}'
                % (chr_part, RFONT, _child(el, 'e')))
    if t == 'd':
        beg = _chr_of(el, 'dPr', 'begChr')
        end = _chr_of(el, 'dPr', 'endChr')
        extra = ''
        if beg:
            extra += '{\\mbegChr %s}' % _rf_escape(beg)
        if end:
            extra += '{\\mendChr %s}' % _rf_escape(end)
        return ('{\\md{\\mdPr{%s\\mctrlPr%s }}{\\me{%s}}}'
                % (extra, RFONT, _child(el, 'e')))
    if t == 'limLow':
        return ('{\\mlimLow{\\mlimLowPr{\\mctrlPr%s }}{\\me{%s}}{\\mlim{%s}}}'
                % (RFONT, _child(el, 'e'), _child(el, 'lim')))
    if t == 'limUpp':
        return ('{\\mlimUpp{\\mlimUppPr{\\mctrlPr%s }}{\\me{%s}}{\\mlim{%s}}}'
                % (RFONT, _child(el, 'e'), _child(el, 'lim')))
    if t == 'm':
        rows = []
        ncol = 1
        for c in el:
            if _tag(c) == 'mr':
                cells = [_mtree(x) for x in c if _tag(x) == 'e']
                ncol = max(ncol, len(cells))
                rows.append('{\\mmr' + ''.join('{\\me{%s}}' % x for x in cells) + '}')
        mcpr = ('{\\mmPr{\\mmcs{\\mmc{\\mmcPr{\\mcount %d}{\\mmcJc center}}}}{\\mctrlPr%s }}'
                % (ncol, RFONT))
        return '{\\mm%s%s}' % (mcpr, ''.join(rows))
    if t == 'bar':
        return '{\\mbar{\\mbarPr{\\mctrlPr%s }}{\\me{%s}}}' % (RFONT, _child(el, 'e'))
    # 兜底：展开
    return ''.join(_mtree(c) for c in el)


def _child(el, name):
    for c in el:
        if _tag(c) == name:
            return _mtree(c)
    return ''


def _has_flag(el, prname, childname):
    for c in el:
        if _tag(c) == prname:
            for x in c:
                if _tag(x) == childname:
                    v = x.get('{%s}val' % M_NS, x.get('m:val', ''))
                    return v in ('1', 'on', 'true')
    return False


def _chr_of(el, prname, childname='chr'):
    for c in el:
        if _tag(c) == prname:
            for x in c:
                if _tag(x) == childname:
                    return x.get('{%s}val' % M_NS, x.get('m:val', ''))
    return ''


def omml_to_rtf(omml, display):
    """把一段 OMML（不含 m:oMath 包装）变成 RTF 公式组。"""
    body = _mtree(ET.fromstring(
        '<m:oMath xmlns:m="%s">%s</m:oMath>' % (M_NS, omml)))
    if display:
        return ('{\\mmath{\\*\\moMathPara {\\moMathParaPr\\mjc2}'
                '{\\*\\moMath %s}}}' % body)
    return '{\\mmath{\\*\\moMath %s}}' % body
