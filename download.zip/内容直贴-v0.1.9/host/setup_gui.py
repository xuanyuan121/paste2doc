# -*- coding: utf-8 -*-
"""内容直贴 · 本地组件 —— 安装向导 / 卸载界面。

同一个 exe 的两种界面：

    Paste2DocSetup.exe                 安装向导
    Paste2DocSetup.exe --uninstall     卸载确认
    ... --install --dir <路径> --silent --log <文件>    静默安装（给自动化测试用）
    ... --uninstall --silent            静默卸载

界面只用 tkinter（标准库），打包成单文件 exe 后不依赖本机 Python。
真正的活都在 p2d_setup.py 里，这里只管长相和进度。
"""
import os
import queue
import sys
import threading
import tkinter as tk
from tkinter import filedialog

import p2d_setup as core

BG = '#ffffff'
BAND = '#f5f7fb'
TEXT = '#1b1f24'
MUTED = '#6b7280'
LINE = '#e6e9ef'
ACCENT = '#2563eb'
ACCENT_D = '#1d4ed8'
OKC = '#15803d'
DANGER = '#b42318'
W, H = 660, 476


def resource(name):
    return os.path.join(core.base_dir(), name)


def value_of(flag, argv):
    for i, a in enumerate(argv):
        if a == flag and i + 1 < len(argv):
            return argv[i + 1]
        if a.startswith(flag + '='):
            return a.split('=', 1)[1]
    return None


class App:
    def __init__(self, uninstall=False, dest=None):
        self.uninstall_mode = uninstall
        self.dest = dest or core.default_dir()
        self.q = queue.Queue()
        self.busy = False

        self.root = tk.Tk()
        self.root.title('%s  %s' % (core.APP_NAME, core.version()))
        self.root.configure(bg=BG)
        self.root.resizable(False, False)
        try:
            self.root.iconbitmap(resource('app.ico'))
        except tk.TclError:
            pass

        self._dpi()
        self._fonts()
        self.root.protocol('WM_DELETE_WINDOW', self._close)
        self._center()

        self.band = tk.Frame(self.root, bg=BAND, height=104)
        self.band.pack(side='top', fill='x')
        self.band.pack_propagate(False)
        self._band()

        self.foot = tk.Frame(self.root, bg=BG, height=76)
        self.foot.pack(side='bottom', fill='x')
        self.foot.pack_propagate(False)

        self.body = tk.Frame(self.root, bg=BG)
        self.body.pack(side='top', fill='both', expand=True)

        self._foot()

        if self.uninstall_mode:
            self.page_uninstall()
        elif core.state()['installed']:
            self.page_installed()
        else:
            self.page_install()

        self.root.after(70, self._drain)
        self.root.mainloop()

    # ------------------------------------------------------------ 基础

    def _dpi(self):
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:                                    # noqa: BLE001
            pass
        try:
            dpi = self.root.winfo_fpixels('1i')
            self.root.tk.call('tk', 'scaling', dpi / 72.0)
        except tk.TclError:
            pass

    def _fonts(self):
        fam = 'Microsoft YaHei UI'
        self.f_h1 = (fam, 15, 'bold')
        self.f_h2 = (fam, 12, 'bold')
        self.f_body = (fam, 9)
        self.f_small = (fam, 8)
        self.f_btn = (fam, 9)

    def _center(self, h=None):
        h = h or H
        self.h = h
        self.root.update_idletasks()
        x = max(0, (self.root.winfo_screenwidth() - W) // 2)
        y = max(0, (self.root.winfo_screenheight() - h) // 3)
        self.root.geometry('%dx%d+%d+%d' % (W, h, x, y))
        self.root.minsize(W, h)
        self.root.maxsize(W, h)

    def _resize(self, h):
        """换页时顺手换个高度：内容少的页没必要留一大片白。"""
        if h == getattr(self, 'h', None):
            return
        x = max(0, (self.root.winfo_screenwidth() - W) // 2)
        y = max(0, (self.root.winfo_screenheight() - h) // 3)
        self.root.minsize(W, h)
        self.root.maxsize(W, h)
        self.root.geometry('%dx%d+%d+%d' % (W, h, x, y))
        self.h = h

    def _band(self):
        for w in self.band.winfo_children():
            w.destroy()
        wrap = tk.Frame(self.band, bg=BAND)
        wrap.pack(fill='both', expand=True, padx=28, pady=(18, 14))
        try:
            self.icon = tk.PhotoImage(file=resource('icon48.png'))
            tk.Label(wrap, image=self.icon, bg=BAND).pack(side='left', padx=(0, 14))
        except tk.TclError:
            pass
        text = tk.Frame(wrap, bg=BAND)
        text.pack(side='left', fill='both')
        title = '卸载 内容直贴 · 本地组件' if self.uninstall_mode else '内容直贴 · 本地组件'
        tk.Label(text, text=title, bg=BAND, fg=TEXT, font=self.f_h1,
                 anchor='w').pack(anchor='w')
        sub = ('装一个很小的本地程序，让 WPS 文字也能接收排好版的剪贴板内容'
               if not self.uninstall_mode else '把登记和文件都清干净，不动浏览器里的扩展')
        tk.Label(text, text=sub, bg=BAND, fg=MUTED, font=self.f_body,
                 anchor='w').pack(anchor='w', pady=(4, 0))

    def _foot(self):
        for w in self.foot.winfo_children():
            w.destroy()
        self.bar = tk.Canvas(self.foot, height=3, bg=LINE, highlightthickness=0)
        self.bar.place(x=0, y=0, relwidth=1)
        self.fill = self.bar.create_rectangle(0, 0, 0, 3, fill=ACCENT, width=0)

        row = tk.Frame(self.foot, bg=BG)
        row.pack(fill='x', padx=28, pady=(16, 0))
        self.status = tk.Label(row, text='', bg=BG, fg=MUTED, font=self.f_small, anchor='w')
        self.status.pack(side='left')
        self.btn_box = tk.Frame(row, bg=BG)
        self.btn_box.pack(side='right')

    def btn(self, parent, text, cmd, kind='sec', width=None):
        if kind == 'pri':
            bg, fg, hov, bd = ACCENT, '#ffffff', ACCENT_D, 0
        elif kind == 'danger':
            bg, fg, hov, bd = DANGER, '#ffffff', '#8f1d14', 0
        else:
            bg, fg, hov, bd = '#eef1f6', TEXT, '#e2e7ef', 0
        b = tk.Button(parent, text=text, command=cmd, font=self.f_btn,
                      bg=bg, fg=fg, activebackground=hov, activeforeground=fg,
                      relief='flat', bd=bd, padx=20, pady=7, cursor='hand2',
                      highlightthickness=0)
        if width:
            b.configure(width=width)
        b.bind('<Enter>', lambda _e: b.configure(bg=hov) if b['state'] != 'disabled' else None)
        b.bind('<Leave>', lambda _e: b.configure(bg=bg) if b['state'] != 'disabled' else None)
        return b

    def clear(self):
        for w in self.body.winfo_children():
            w.destroy()
        for w in self.btn_box.winfo_children():
            w.destroy()
        self.status.configure(text='')
        self.progress(0)

    def progress(self, pct):
        self.bar.coords(self.fill, 0, 0, max(0, min(100, pct)) / 100.0 * self.foot.winfo_width(), 3)

    def say(self, text):
        self.status.configure(text=text)

    def _close(self):
        if self.busy:
            return
        self.root.destroy()

    # -------------------------------------------------------- 安装页

    def page_install(self):
        self.clear()
        self._resize(470)
        pad = {'padx': 28}
        tk.Label(self.body, text='安装位置', bg=BG, fg=TEXT, font=self.f_h2,
                 anchor='w').pack(fill='x', **pad, pady=(22, 8))

        row = tk.Frame(self.body, bg=BG)
        row.pack(fill='x', **pad)
        self.path_var = tk.StringVar(value=self.dest)
        ent = tk.Entry(row, textvariable=self.path_var, font=self.f_body, fg=TEXT,
                       bg='#fbfcfe', relief='flat', bd=0, insertbackground=TEXT,
                       highlightthickness=1, highlightbackground=LINE,
                       highlightcolor=ACCENT)
        ent.pack(side='left', fill='x', expand=True, ipady=6, padx=(0, 8))
        self.btn(row, '浏览…', self._pick_dir, 'sec').pack(side='left')

        tk.Label(self.body,
                 text='装在你自己的账户下，不需要管理员权限，也不会开机自启。',
                 bg=BG, fg=MUTED, font=self.f_small, anchor='w').pack(fill='x', **pad,
                                                                      pady=(8, 0))

        box = tk.Frame(self.body, bg=BG)
        box.pack(fill='x', **pad, pady=(18, 0))
        for line in ('自带运行环境 —— 不需要先装 Python',
                     '注册到 Chrome / Edge / Chromium，扩展点一下就能连上',
                     '在「设置 → 应用」里可以像普通软件一样卸载'):
            r = tk.Frame(box, bg=BG)
            r.pack(fill='x', pady=(0, 7))
            tk.Label(r, text='·', bg=BG, fg=ACCENT, font=self.f_body).pack(side='left')
            tk.Label(r, text=line, bg=BG, fg=MUTED, font=self.f_body,
                     anchor='w').pack(side='left', padx=(8, 0))

        self.btn(self.btn_box, '安装', self.do_install, 'pri').pack(side='right')
        self.btn(self.btn_box, '取消', self._close, 'sec').pack(side='right', padx=(0, 8))
        self.say('装完大约占 31 MB')

    def page_installed(self):
        self.clear()
        self._resize(376)
        st = core.state()
        pad = {'padx': 28}
        tk.Label(self.body, text='已经装好了', bg=BG, fg=OKC, font=self.h2(),
                 anchor='w').pack(fill='x', **pad, pady=(26, 6))
        tk.Label(self.body,
                 text='装在 %s\n版本 %s · 已注册到 %s' % (
                     st['dir'], st['version'], '、'.join(st['registered']) or '（无）'),
                 bg=BG, fg=MUTED, font=self.f_body, anchor='w', justify='left',
                 wraplength=W - 70).pack(fill='x', **pad)
        tk.Label(self.body,
                 text='回到浏览器侧边栏，点一下右上角的「未安装／重新检测」，'
                      '变成「已连接」就能用了。',
                 bg=BG, fg=TEXT, font=self.f_body, anchor='w', justify='left',
                 wraplength=W - 70).pack(fill='x', **pad, pady=(16, 0))

        self.btn(self.btn_box, '重新安装', lambda: self._reinstall(st['dir']),
                 'pri').pack(side='right')
        self.btn(self.btn_box, '卸载', lambda: self._to_uninstall(), 'sec').pack(
            side='right', padx=(0, 8))
        self.btn(self.btn_box, '关闭', self._close, 'sec').pack(side='right', padx=(0, 8))

    def h2(self):
        return (self.f_h1[0], 13, 'bold')

    def _reinstall(self, d):
        self.dest = d
        self.page_install()

    def _to_uninstall(self):
        self.uninstall_mode = True
        self._band()
        self.page_uninstall()

    def _pick_dir(self):
        d = filedialog.askdirectory(parent=self.root, title='选择安装位置',
                                    initialdir=self.path_var.get() or core.default_dir())
        if d:
            self.path_var.set(os.path.normpath(d))

    # -------------------------------------------------------- 卸载页

    def page_uninstall(self):
        self.clear()
        self._resize(404)
        pad = {'padx': 28}
        st = core.state()
        tk.Label(self.body,
                 text='会删掉这些：' if st['installed'] else '没找到安装记录，仍然可以清理残留：',
                 bg=BG, fg=TEXT, font=self.h2(), anchor='w').pack(fill='x', **pad,
                                                                  pady=(24, 10))
        items = [
            ('浏览器登记', 'Chrome / Edge / Chromium 各一条，删完扩展就连不上本地组件了'),
            ('「设置 → 应用」里的条目', '删掉后不会再出现在应用列表里'),
            ('程序文件', st['dir'] or core.default_dir()),
        ]
        for name, desc in items:
            r = tk.Frame(self.body, bg=BG)
            r.pack(fill='x', **pad, pady=(0, 10))
            tk.Label(r, text=name, bg=BG, fg=TEXT, font=self.f_body,
                     anchor='w', width=22).pack(side='left')
            tk.Label(r, text=desc, bg=BG, fg=MUTED, font=self.f_small,
                     anchor='w').pack(side='left')
        tk.Label(self.body,
                 text='不会动浏览器里的扩展本体，也不会碰你的任何文档。'
                      '卸载后扩展还能用，只是粘到 WPS 里是纯文本。',
                 bg=BG, fg=MUTED, font=self.f_small, anchor='w', justify='left',
                 wraplength=W - 70).pack(fill='x', **pad, pady=(8, 0))

        self.btn(self.btn_box, '卸载', self.do_uninstall, 'danger').pack(side='right')
        self.btn(self.btn_box, '取消', self._close, 'sec').pack(side='right', padx=(0, 8))
        self.say('')

    # -------------------------------------------------------- 执行

    def _lock(self, on):
        self.busy = on
        for b in self.btn_box.winfo_children():
            b.configure(state='disabled' if on else 'normal')

    def _run(self, fn, done):
        self._lock(True)
        self.progress(1)

        def worker():
            try:
                info = fn(lambda pct, text: self.q.put(('p', pct, text)))
                self.q.put(('ok', info, done))
            except Exception as e:                           # noqa: BLE001
                self.q.put(('err', str(e), None))

        threading.Thread(target=worker, daemon=True).start()

    def _drain(self):
        try:
            while True:
                item = self.q.get_nowait()
                if item[0] == 'p':
                    self.progress(item[1])
                    self.say(item[2])
                elif item[0] == 'ok':
                    self.progress(100)
                    self._lock(False)
                    item[2](item[1])
                else:
                    self._lock(False)
                    self.say('出错了：' + item[1][:80])
        except queue.Empty:
            pass
        self.root.after(70, self._drain)

    def do_install(self):
        dest = self.path_var.get().strip() or core.default_dir()
        self._run(lambda cb: core.install(dest, cb), self.page_done)

    def do_uninstall(self):
        self._run(lambda cb: core.uninstall(cb), self.page_uninstalled)

    # -------------------------------------------------------- 完成页

    def page_done(self, info):
        self.clear()
        self._resize(352)
        self._band()
        pad = {'padx': 28}
        tk.Label(self.body, text='装好了', bg=BG, fg=OKC, font=self.h2(),
                 anchor='w').pack(fill='x', **pad, pady=(30, 10))
        tk.Label(self.body,
                 text='回到浏览器侧边栏，点一下「重新检测」，等状态变成「已连接」。',
                 bg=BG, fg=TEXT, font=self.f_body, anchor='w', justify='left',
                 wraplength=W - 70).pack(fill='x', **pad)
        tk.Label(self.body,
                 text='位置：%s\n已注册：%s' % (info['dir'], '、'.join(info['browsers'])),
                 bg=BG, fg=MUTED, font=self.f_small, anchor='w', justify='left',
                 wraplength=W - 70).pack(fill='x', **pad, pady=(12, 0))
        self.btn(self.btn_box, '完成', self._close, 'pri').pack(side='right')
        self.btn(self.btn_box, '打开安装目录', lambda: core.open_folder(info['dir']),
                 'sec').pack(side='right', padx=(0, 8))
        self.progress(100)
        self.say('')

    def page_uninstalled(self, info):
        self.clear()
        self._resize(300)
        tk.Label(self.body, text='已经卸载了', bg=BG, fg=OKC, font=self.h2(),
                 anchor='w').pack(fill='x', padx=28, pady=(30, 10))
        tk.Label(self.body,
                 text='浏览器登记和程序文件都清掉了。扩展本身还在，'
                      '只是粘到 WPS 里会是纯文本。',
                 bg=BG, fg=MUTED, font=self.f_body, anchor='w', justify='left',
                 wraplength=W - 70).pack(fill='x', padx=28)
        self.btn(self.btn_box, '关闭', self._close, 'pri').pack(side='right')
        self.progress(100)


# ------------------------------------------------------------------ 入口

def main():
    argv = sys.argv[1:]
    silent = '--silent' in argv
    uninst = '--uninstall' in argv
    dest = value_of('--dir', argv) or core.default_dir()
    log = value_of('--log', argv)
    lines = []

    def report(pct, text):
        lines.append('%3d%% %s' % (pct, text))

    if silent:
        code = 0
        try:
            if uninst:
                core.uninstall(report)
            else:
                core.install(dest, report)
        except Exception as e:                                # noqa: BLE001
            lines.append('错误：%s' % e)
            code = 1
        if log:
            with open(log, 'w', encoding='utf-8') as f:
                f.write('\n'.join(lines))
        return code

    App(uninstall=uninst, dest=dest)
    return 0


if __name__ == '__main__':
    sys.exit(main())
