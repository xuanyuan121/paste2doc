# -*- coding: utf-8 -*-
"""文档模型 -> .docx（OOXML）。

设计上只做一件事：把结构写成「真结构」，把格式全部放进样式里。

  * 标题 -> 内置 Heading 1..6（导航窗格里能看到大纲，后期换标题样式一键生效）
  * 列表 -> numbering.xml 里的自动编号（回车能接续，不是手打的“1.”）
  * 表格 -> 真表格（能选行列、拖列宽）
  * 公式 -> m:oMath 原生公式（双击能编辑）
  * 正文 -> 一个 Normal 样式：宋体 / Times New Roman、五号、单倍行距、首行缩进两字

正文段落里没有字号、行距、缩进这类直接格式，改样式能全局生效。
"""
import io
import zipfile

from p2d_math import mathml_to_omml

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
M = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'

PAGE_W = 11906
MARGIN_LR = 1800
TEXT_W = PAGE_W - MARGIN_LR * 2      # 8306 twips

HEADING_SIZES = [32, 28, 24, 21, 21, 21]   # 半磅：16 / 14 / 12 / 10.5


def esc(s):
    return (str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            .replace('"', '&quot;'))


def _xml_text(s):
    """正文文字：去掉 XML 不接受的运行控制符。"""
    return esc(''.join(ch for ch in str(s) if ch >= ' ' or ch in '\t\n'))


class DocxBuilder:
    def __init__(self, model):
        self.model = model or {}
        self.opt = self.model.get('opt') or {}
        self.size = int(self.opt.get('size') or 21)
        self.line = int(self.opt.get('line') or 240)
        self.indent = bool(self.opt.get('indent', True))
        # 见 p2d_rtf.py：统一排版时只留结构，丢掉网页的行内装饰
        self.unify = bool(self.opt.get('unify', True))
        self.blocks = self.model.get('blocks') or []
        self.rels = []          # [(rid, url)]
        self.nums = []          # [(num_id, abstract_id, start)]
        self._rid = 10

    # ------------------------------------------------------------- 样式

    def _first_line(self):
        return 'w:firstLineChars="200" w:firstLine="%d"' % (2 * self.size * 10) \
            if self.indent else 'w:firstLineChars="0" w:firstLine="0"'

    def styles_xml(self):
        s = self.size
        parts = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
                 '<w:styles xmlns:w="%s">' % W,
                 '<w:docDefaults><w:rPrDefault><w:rPr>',
                 '<w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman"'
                 ' w:eastAsia="宋体" w:cs="Times New Roman"/>',
                 '<w:sz w:val="%d"/><w:szCs w:val="%d"/>' % (s, s),
                 '<w:lang w:val="en-US" w:eastAsia="zh-CN" w:bidi="ar-SA"/>',
                 '</w:rPr></w:rPrDefault><w:pPrDefault><w:pPr>',
                 '<w:spacing w:before="0" w:after="0" w:line="%d" w:lineRule="auto"/>' % self.line,
                 '</w:pPr></w:pPrDefault></w:docDefaults>',
                 # 正文
                 '<w:style w:type="paragraph" w:default="1" w:styleId="Normal">',
                 '<w:name w:val="Normal"/><w:qFormat/>',
                 '<w:pPr><w:widowControl w:val="0"/><w:jc w:val="both"/>',
                 '<w:ind %s/></w:pPr>' % self._first_line(),
                 '</w:style>']

        # 标题：朴素、不加额外间距，靠 Word 自带的那套标题样式
        for lvl in range(1, 7):
            hs = max(HEADING_SIZES[lvl - 1], s)
            parts.append(
                '<w:style w:type="paragraph" w:styleId="Heading%d">'
                '<w:name w:val="heading %d"/><w:basedOn w:val="Normal"/>'
                '<w:next w:val="Normal"/><w:qFormat/><w:uiPriority w:val="9"/>'
                '<w:pPr><w:keepNext/><w:keepLines/>'
                '<w:spacing w:before="0" w:after="0" w:line="%d" w:lineRule="auto"/>'
                '<w:ind w:firstLineChars="0" w:firstLine="0"/><w:jc w:val="left"/>'
                '<w:outlineLvl w:val="%d"/></w:pPr>'
                '<w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman"'
                ' w:eastAsia="%s"/><w:b/><w:sz w:val="%d"/><w:szCs w:val="%d"/></w:rPr>'
                '</w:style>' % (lvl, lvl, self.line, lvl - 1,
                                '宋体' if self.unify else '黑体', hs, hs))

        # 代码：等宽、小一号、不缩进、浅灰底（不然和正文糊成一片）
        # pPr 的子元素顺序是 schema 规定的：keepLines -> pBdr -> shd -> ind -> jc
        parts.append(
            '<w:style w:type="paragraph" w:styleId="Code">'
            '<w:name w:val="Code"/><w:basedOn w:val="Normal"/><w:qFormat/>'
            '<w:pPr><w:keepLines/>'
            '<w:shd w:val="clear" w:color="auto" w:fill="F7F7F8"/>'
            '<w:ind w:left="210" w:right="210" w:firstLineChars="0" w:firstLine="0"/>'
            '<w:jc w:val="left"/></w:pPr>'
            '<w:rPr><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:eastAsia="宋体"/>'
            '<w:sz w:val="%d"/><w:szCs w:val="%d"/></w:rPr></w:style>'
            % (max(18, s - 3), max(18, s - 3)))

        # 引用：左缩进 + 左侧竖线，和网页上的 blockquote 一致
        parts.append(
            '<w:style w:type="paragraph" w:styleId="Quote">'
            '<w:name w:val="Quote"/><w:basedOn w:val="Normal"/><w:qFormat/>'
            '<w:pPr>'
            '<w:pBdr><w:left w:val="single" w:sz="12" w:space="10" w:color="D8D8DE"/></w:pBdr>'
            '<w:ind w:left="420" w:right="420" w:firstLineChars="0" '
            'w:firstLine="0"/></w:pPr></w:style>')

        # 表格里的文字
        parts.append(
            '<w:style w:type="paragraph" w:styleId="TableText">'
            '<w:name w:val="Table Text"/><w:basedOn w:val="Normal"/>'
            '<w:pPr><w:spacing w:before="20" w:after="20" w:line="%d" w:lineRule="auto"/>'
            '<w:ind w:firstLineChars="0" w:firstLine="0"/><w:jc w:val="left"/></w:pPr>'
            '</w:style>' % self.line)

        # 独立公式段落
        parts.append(
            '<w:style w:type="paragraph" w:styleId="MathPara">'
            '<w:name w:val="Math Para"/><w:basedOn w:val="Normal"/>'
            '<w:pPr><w:ind w:firstLineChars="0" w:firstLine="0"/><w:jc w:val="center"/>'
            '</w:pPr></w:style>')

        # 行内代码
        parts.append(
            '<w:style w:type="character" w:styleId="CodeChar">'
            '<w:name w:val="Code Char"/><w:basedOn w:val="DefaultParagraphFont"/>'
            '<w:rPr><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:eastAsia="宋体"/>'
            '<w:sz w:val="%d"/><w:szCs w:val="%d"/></w:rPr></w:style>'
            % (max(18, s - 1), max(18, s - 1)))

        # 表格边框：给用户一个能直接改的表格样式
        parts.append(
            '<w:style w:type="table" w:styleId="TableGrid">'
            '<w:name w:val="Table Grid"/><w:basedOn w:val="TableNormal"/>'
            '<w:uiPriority w:val="59"/><w:pPr><w:spacing w:before="0" w:after="0" '
            'w:line="240" w:lineRule="auto"/></w:pPr>'
            '<w:tblPr><w:tblBorders>'
            '<w:top w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
            '<w:left w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
            '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
            '<w:right w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
            '<w:insideH w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
            '<w:insideV w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
            '</w:tblBorders><w:tblCellMar>'
            '<w:top w:w="28" w:type="dxa"/><w:left w:w="108" w:type="dxa"/>'
            '<w:bottom w:w="28" w:type="dxa"/><w:right w:w="108" w:type="dxa"/>'
            '</w:tblCellMar></w:tblPr></w:style>')

        parts.append('</w:styles>')
        return ''.join(parts)

    # ----------------------------------------------------------- 编号

    def numbering_xml(self):
        parts = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
                 '<w:numbering xmlns:w="%s">' % W]

        parts.append('<w:abstractNum w:abstractNumId="0">'
                     '<w:multiLevelType w:val="hybridMultilevel"/>')
        for lvl in range(9):
            # 一级 1.  二级 (1)  三级 1) ，再往下循环 —— 不让两级都出现"1."造成误读
            fmt = (['%%%d.', '(%%%d)', '%%%d)'])[lvl % 3] % (lvl + 1)
            parts.append(
                '<w:lvl w:ilvl="%d"><w:start w:val="1"/><w:numFmt w:val="decimal"/>'
                '<w:lvlText w:val="%s"/><w:lvlJc w:val="left"/>'
                '<w:pPr><w:ind w:left="%d" w:hanging="420"/></w:pPr>'
                '<w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman"'
                ' w:hint="default"/></w:rPr></w:lvl>'
                % (lvl, fmt, 420 * (lvl + 1)))
        parts.append('</w:abstractNum>')

        bullets = ['•', '◦', '▪']
        parts.append('<w:abstractNum w:abstractNumId="1">'
                     '<w:multiLevelType w:val="hybridMultilevel"/>')
        for lvl in range(9):
            parts.append(
                '<w:lvl w:ilvl="%d"><w:start w:val="1"/><w:numFmt w:val="bullet"/>'
                '<w:lvlText w:val="%s"/><w:lvlJc w:val="left"/>'
                '<w:pPr><w:ind w:left="%d" w:hanging="420"/></w:pPr>'
                '<w:rPr><w:rFonts w:ascii="宋体" w:hAnsi="宋体" w:hint="default"/></w:rPr>'
                '</w:lvl>' % (lvl, bullets[lvl % 3], 420 * (lvl + 1)))
        parts.append('</w:abstractNum>')

        for num_id, abstract_id, start in self.nums:
            parts.append('<w:num w:numId="%d"><w:abstractNumId w:val="%d"/>'
                         % (num_id, abstract_id))
            if start and start != 1:
                parts.append('<w:lvlOverride w:ilvl="0"><w:startOverride w:val="%d"/>'
                             '</w:lvlOverride>' % start)
            parts.append('</w:num>')

        parts.append('</w:numbering>')
        return ''.join(parts)

    # --------------------------------------------------------- 行内内容

    def _runs(self, inl, bold=None):
        out = []
        for node in (inl or []):
            t = node.get('t')
            if t == 'math':
                try:
                    omml, _ = mathml_to_omml(node.get('mathml') or '', size=self.size)
                    out.append('<m:oMath>%s</m:oMath>' % omml)
                except Exception:
                    # 公式转不动也不能让这一段凭空消失：把 LaTeX 当斜体文字留下
                    fb = (node.get('latex') or '').strip()
                    if fb:
                        out.append('<w:r><w:rPr><w:i/></w:rPr>'
                                   '<w:t xml:space="preserve">%s</w:t></w:r>' % _xml_text(fb))
                continue
            if t == 'br':
                out.append('<w:r><w:br/></w:r>')
                continue
            if t != 'text':
                continue
            text = node.get('v') or ''
            if not text:
                continue
            rpr = ''
            if node.get('code'):
                rpr += '<w:rStyle w:val="CodeChar"/>'
            # 表头 / 标题的加粗来自结构，一定保留；网页给的加粗斜体删除线，
            # 统一排版时丢掉（否则正文会一段粗一段细，看着像原样搬过来的）
            if bold or (not self.unify and node.get('b')):
                rpr += '<w:b/>'
            if not self.unify:
                if node.get('i'):
                    rpr += '<w:i/>'
                if node.get('st'):
                    rpr += '<w:strike/>'
            if node.get('sup'):
                rpr += '<w:vertAlign w:val="superscript"/>'
            elif node.get('sub'):
                rpr += '<w:vertAlign w:val="subscript"/>'
            run = '<w:r>%s<w:t xml:space="preserve">%s</w:t></w:r>' % (
                ('<w:rPr>%s</w:rPr>' % rpr) if rpr else '', _xml_text(text))
            link = node.get('link')
            if link:
                rid = self._add_link(link)
                out.append('<w:hyperlink r:id="%s" w:history="1">%s</w:hyperlink>'
                           % (rid, run))
            else:
                out.append(run)
        return ''.join(out)

    def _add_link(self, url):
        for rid, u in self.rels:
            if u == url:
                return rid
        rid = 'rId%d' % self._rid
        self._rid += 1
        self.rels.append((rid, url))
        return rid

    # ------------------------------------------------------------ 段落

    def _para(self, inl, style=None, num=None, lvl=0, bold=None, keep_empty=False):
        ppr = ''
        if style or num is not None:
            ppr = '<w:pPr>'
            if style:
                ppr += '<w:pStyle w:val="%s"/>' % style
            if num is not None:
                ppr += '<w:numPr><w:ilvl w:val="%d"/><w:numId w:val="%d"/></w:numPr>' % (lvl, num)
            ppr += '</w:pPr>'
        body = self._runs(inl, bold=bold)
        if not body and not keep_empty:
            return ''
        return '<w:p>%s%s</w:p>' % (ppr, body)

    def _table(self, block):
        rows = block.get('rows') or []
        if not rows:
            return ''
        ncol = max(len(r) for r in rows) or 1
        colw = TEXT_W // ncol
        parts = ['<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/>'
                 '<w:tblW w:w="%d" w:type="dxa"/><w:tblLayout w:type="fixed"/>'
                 '</w:tblPr><w:tblGrid>' % TEXT_W]
        parts.append(''.join('<w:gridCol w:w="%d"/>' % colw for _ in range(ncol)))
        parts.append('</w:tblGrid>')
        header = block.get('header', True)
        for i, row in enumerate(rows):
            is_head = header and i == 0
            parts.append('<w:tr>')
            if is_head:
                parts.append('<w:trPr><w:tblHeader/><w:cantSplit/></w:trPr>')
            for c in range(ncol):
                cell = row[c] if c < len(row) else []
                parts.append('<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa"/>'
                             '%s<w:vAlign w:val="center"/></w:tcPr>'
                             % (colw, '<w:shd w:val="clear" w:color="auto" w:fill="F2F2F2"/>'
                                if is_head else ''))
                parts.append(self._para(cell, style='TableText', bold=is_head,
                                        keep_empty=True))
                parts.append('</w:tc>')
            parts.append('</w:tr>')
        parts.append('</w:tbl>')
        return ''.join(parts)

    def _code(self, block):
        text = (block.get('text') or '').replace('\r\n', '\n').replace('\r', '\n')
        lines = text.strip('\n').split('\n')
        out = []
        for line in lines:
            if line == '':
                out.append('<w:p><w:pPr><w:pStyle w:val="Code"/></w:pPr></w:p>')
            else:
                out.append('<w:p><w:pPr><w:pStyle w:val="Code"/></w:pPr>'
                           '<w:r><w:t xml:space="preserve">%s</w:t></w:r></w:p>'
                           % _xml_text(line.replace('\t', '    ')))
        return ''.join(out)

    def document_xml(self):
        out = []
        for b in self.blocks:
            t = b.get('t')
            if t == 'h':
                lvl = min(6, max(1, int(b.get('level') or 2)))
                out.append(self._para(b.get('inl'), style='Heading%d' % lvl))
            elif t == 'p':
                style = 'Quote' if b.get('q') else None
                out.append(self._para(b.get('inl'), style=style))
            elif t == 'list':
                ordered = bool(b.get('ordered'))
                num_id = len(self.nums) + 1
                self.nums.append((num_id, 0 if ordered else 1, int(b.get('start') or 1)))
                for item in (b.get('items') or []):
                    lvl = min(8, max(0, int(item.get('lvl') or 0)))
                    out.append(self._para(item.get('inl'), num=num_id, lvl=lvl))
            elif t == 'code':
                out.append(self._code(b))
            elif t == 'table':
                out.append(self._table(b))
            elif t == 'math':
                try:
                    omml, _ = mathml_to_omml(b.get('mathml') or '', size=self.size)
                except Exception:
                    fb = (b.get('latex') or '').strip()
                    if fb:
                        out.append('<w:p><w:pPr><w:pStyle w:val="MathPara"/></w:pPr>'
                                   '<w:r><w:rPr><w:i/></w:rPr>'
                                   '<w:t xml:space="preserve">%s</w:t></w:r></w:p>'
                                   % _xml_text(fb))
                    continue
                out.append('<w:p><w:pPr><w:pStyle w:val="MathPara"/></w:pPr>'
                           '<m:oMathPara><m:oMathParaPr><m:jc m:val="center"/>'
                           '</m:oMathParaPr><m:oMath>%s</m:oMath></m:oMathPara></w:p>'
                           % omml)

        body = ''.join(out)
        if not body:
            return ''
        return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<w:document xmlns:w="%s" xmlns:m="%s" xmlns:r="%s"><w:body>%s'
                '<w:sectPr><w:pgSz w:w="%d" w:h="16838"/>'
                '<w:pgMar w:top="1440" w:right="%d" w:bottom="1440" w:left="%d"'
                ' w:header="851" w:footer="992" w:gutter="0"/></w:sectPr>'
                '</w:body></w:document>'
                % (W, M, R, body, PAGE_W, MARGIN_LR, MARGIN_LR))

    # ------------------------------------------------------------ 打包

    def build(self):
        doc = self.document_xml()
        if not doc:
            return None
        ct = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
              '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
              '<Default Extension="xml" ContentType="application/xml"/>'
              '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
              '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
              '<Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/>'
              '</Types>')
        root_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                     '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                     '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
                     '</Relationships>')
        rels = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
                '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">',
                '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>',
                '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/>']
        for rid, url in self.rels:
            rels.append('<Relationship Id="%s" Type="http://schemas.openxmlformats.org/'
                        'officeDocument/2006/relationships/hyperlink" Target="%s" '
                        'TargetMode="External"/>' % (rid, esc(url)))
        rels.append('</Relationships>')

        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
            z.writestr('[Content_Types].xml', ct)
            z.writestr('_rels/.rels', root_rels)
            z.writestr('word/_rels/document.xml.rels', ''.join(rels))
            z.writestr('word/document.xml', doc)
            z.writestr('word/styles.xml', self.styles_xml())
            z.writestr('word/numbering.xml', self.numbering_xml())
        return buf.getvalue()
