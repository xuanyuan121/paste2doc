# -*- coding: utf-8 -*-
"""RTF 文本转义（正文和公式共用）。

RTF 是字节格式：中文按 GBK（\\ansicpg936）写成 \\'hh，GBK 里没有的字符
（比如部分数学符号）退回 \\uN?。字体名同样走这里。
"""


def rtf_escape(text):
    out = []
    for ch in text:
        o = ord(ch)
        if ch in '\\{}':
            out.append('\\' + ch)
        elif ch == '\t':
            out.append(r'\tab ')
        elif ch == '\n':
            out.append(r'\line ')
        elif o < 128:
            out.append(ch)
        elif 0xA0 <= o <= 0xFF or 0x2070 <= o <= 0x209F:
            # 拉丁补充区（° × ± · é）和上下标区（² ⁻ ₇）要显式切到西文字体再写 \uN?，
            # 否则 Word 按中文全角排：出现「(° C)」「10 ⁻ ⁶」这种空隙。
            # 写成 GBK 的 \'hh 也一样是全角，实测只有 {\f0 \uN?} 排得紧。
            out.append('{\\f0 \\u%d?}' % o)
        else:
            try:
                raw = ch.encode('gbk')
            except UnicodeEncodeError:
                out.append('\\u%d?' % o)
            else:
                out.append(''.join("\\'%02x" % b for b in raw))
    return ''.join(out)
